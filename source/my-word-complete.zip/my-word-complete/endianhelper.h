/* -*- mode: c++; tab-width: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*- */

#ifndef _ENDIANHELPER_H_
#define _ENDIANHELPER_H_

#ifndef DECL_UINT64_TYPE
#define DECL_UINT64_TYPE 1
typedef unsigned long long Uint64;
#endif

extern bool endian_is_le();

extern void endian_itom_le(unsigned int i, void *p);

extern int  endian_mtoi_le(void *p);

extern void endian_lltom_le(Uint64 i, void *p);

extern Uint64 endian_mtoll_le(void *p);

extern void endian_stom_le(unsigned short i, void *p);

extern short endian_mtos_le(void *p);

#endif /* _ENDIANHELPER_H_ */
