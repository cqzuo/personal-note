/* -*- mode: c++; tab-width: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*- */

#ifndef _COMMON_H_
#define _COMMON_H_

#define MAX_WORD_LENGTH         32

#define DICT_IDENT              0x19841109

#define DICT_VERSION            1

#endif /* _COMMON_H_ */
