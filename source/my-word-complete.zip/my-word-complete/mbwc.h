/* -*- mode: c++; tab-width: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*- */

#ifndef _MBWC_H_
#define _MBWC_H_

// <multiple bytes> and <wide char> conversation
// because the conversation is difference between platforms
// in windows, use MultiByteToWideChar and WideCharToMultiByte
// in unix like; use mbstowcs and wcstombs
//
// the program support the uniform interface
//

#include <stdlib.h>

// NOTE:
// the parameter <int n> is in unit of destination character
// it mean the memory size of <desc> must larger than or equal with
// <n * sizeof(desc-type)>

// behaviour like wcstombs
extern int mbwc_to_mbs(char *desc, const wchar_t *src, int n);

// like mbstowcs
extern int mbwc_to_wcs(wchar_t *desc, const char *src, int n);

extern int mbwc_to_mbs(char **desc, const wchar_t *src);

extern int mbwc_to_wcs(wchar_t **desc, const char *src);

#endif /* _MBWC_H_ */
