/**
		* �ļ�����BankServiceBean.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-24
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.bank.service.bean;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.bank.Bank;
import com.decg.bank.BankFile;
import com.decg.bank.BankFilePK;
import com.decg.bank.service.BankService;
import com.decg.base.DaoSupport;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�BankServiceBean
 * ���������������ҵ���߼��ӿ�BankService��ʵ��
 * �����ˣ�������
 * ����ʱ�䣺2011-3-24 ����09:04:52
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-24 ����09:04:52
 * �޸ı�ע��
 * @version
 *
 */

@Service
public class BankServiceBean extends DaoSupport<Bank> implements BankService {
	
	@SuppressWarnings("unchecked")
	public String getBankId() {
		String id = "";
		Query query = em.createQuery("select o.bankId from Bank o order by o.bankId desc");
		query.setFirstResult(0);
		query.setMaxResults(1);
		List<String> ids = query.getResultList();
		if(ids.size() == 0) {
			id = "01";
		} else {
			id = String.valueOf(Integer.parseInt(ids.get(0)) + 1);
			if(id.length()<2) {
				id = "0" + id;
			}
		}
		return id;
	}

	@Transactional
	public void save(Bank bank, List<String> arrayChecks, List<String> businessTypes, List<String> fileTypes, List<String> fileNames) {
		em.persist(bank);
		int j = 1;
		for(int i=0;i<fileNames.size();i++) {
			if(!"".equals(fileNames.get(i).trim())){
				BankFile bf = new BankFile();
				bf.setBankFilePK(new BankFilePK(bank.getBankId(), j++));
				bf.setBusinessType(businessTypes.get(i));
				bf.setFileName(fileNames.get(i));
				bf.setFileType(fileTypes.get(i));
				em.persist(bf);
			}
		}
	}

	@Transactional
	public void update(Bank bank, List<String> arrayChecks,
			List<String> businessTypes, List<String> fileTypes,
			List<String> fileNames) {
		em.merge(bank);
		Query query = em.createQuery("delete from BankFile o where o.bankFilePK.bank_id = ?1");
		query.setParameter(1, bank.getBankId());
		query.executeUpdate();
		int j = 1;
		for(int i=0;i<fileNames.size();i++) {
			if(!"".equals(fileNames.get(i).trim())){
				BankFile bf = new BankFile();
				bf.setBankFilePK(new BankFilePK(bank.getBankId(), j++));
				bf.setBusinessType(businessTypes.get(i));
				bf.setFileName(fileNames.get(i));
				bf.setFileType(fileTypes.get(i));
				em.persist(bf);
			}
		}
	}
	
	
	
}
