/**
		* �ļ�����BankCDPK.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-24
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.bank;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�BankCDPK
 * ��������
 * �����ˣ�������
 * ����ʱ�䣺2011-3-24 ����11:49:58
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-24 ����11:49:58
 * �޸ı�ע��
 * @version
 *
 */

@Embeddable
public class BankCDPK implements Serializable {
	private static final long serialVersionUID = -2332931878893886682L;
	
	/**
	 * ID
	 * @Id
	 * @Column(length = 10, nullable = false, unique = true)
	 */
	@Column(length = 10, nullable = false)
	private String consCD = null;
	
	/**
	 * �Ա�ֵ
	 * 
	 */
	@Column(length = 1, nullable = false)
	private String consValue = null;

	/**
	 * ID
	 * @Id
	 * @Column(length = 10, nullable = false, unique = true)
	 */
	public String getConsCD() {
		return consCD;
	}

	/**
	 * ID
	 * @Id
	 * @Column(length = 10, nullable = false, unique = true)
	 */
	public void setConsCD(String consCD) {
		this.consCD = consCD;
	}

	/**
	 * �Ա�ֵ
	 * 
	 */
	public String getConsValue() {
		return consValue;
	}

	/**
	 * �Ա�ֵ
	 * 
	 */
	public void setConsValue(String consValue) {
		this.consValue = consValue;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((consCD == null) ? 0 : consCD.hashCode());
		result = prime * result
				+ ((consValue == null) ? 0 : consValue.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankCDPK other = (BankCDPK) obj;
		if (consCD == null) {
			if (other.consCD != null)
				return false;
		} else if (!consCD.equals(other.consCD))
			return false;
		if (consValue == null) {
			if (other.consValue != null)
				return false;
		} else if (!consValue.equals(other.consValue))
			return false;
		return true;
	}
	
}
