/**
		* �ļ�����BankCD.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-24
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.bank;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.decg.base.common.Choose;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�BankCD
 * ��������
 * �����ˣ�������
 * ����ʱ�䣺2011-3-24 ����10:06:10
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-24 ����10:06:10
 * �޸ı�ע��
 * @version
 *
 */

@IdClass(BankCDPK.class)
@Entity
@Table(name = "BankCD")
public class BankCD implements Serializable{
	private static final long serialVersionUID = 8121167183782783705L;
	
	/**
	 * id
	 */
	@Transient
	@EmbeddedId
	private BankCDPK bankCDPK;
	

	/**
	 * ID
	 * @Id
	 * @Column(length = 10, nullable = false, unique = true)
	 */
	@Id
	@Column(length = 10, nullable = false)
	private String consCD = null;
	
	/**
	 * �Ա�ֵ
	 * 
	 */
	@Id
	@Column(length = 1, nullable = false)
	private String consValue = null;
	
	/**
	 * ����
	 * @Id
	 * @Column(length = 32, nullable = false, unique = true)
	 */
	@Id
	@Column(length = 32, nullable = false, unique = true)
	private String name = null;
	
	/**
	 * ��ע
	 */
	@Column(length=255)
	private String demo;
	
	@Column(length = 3, nullable = true, updatable = false)
	@Enumerated(EnumType.STRING)
	 private Choose visiable = Choose.YES;
	/**
	 * ��ע
	 */
	public String getDemo() {
		return demo;
	}

	/**
	 * ��ע
	 */
	public void setDemo(String demo) {
		this.demo = demo;
	}

	/**
	 * ����
	 * @Id
	 * @Column(length = 32, nullable = false, unique = true)
	 */
	public String getName() {
		return name;
	}

	/**
	 * ����
	 * @Id
	 * @Column(length = 32, nullable = false, unique = true)
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * id
	 */
	public BankCDPK getBankCDPK() {
		return bankCDPK;
	}

	/**
	 * id
	 */
	public void setBankCDPK(BankCDPK bankCDPK) {
		this.bankCDPK = bankCDPK;
	}

	/**
	 * ID
	 * @Id
	 * @Column(length = 10, nullable = false, unique = true)
	 */
	public String getConsCD() {
		return consCD;
	}

	/**
	 * ID
	 * @Id
	 * @Column(length = 10, nullable = false, unique = true)
	 */
	public void setConsCD(String consCD) {
		this.consCD = consCD;
	}

	/**
	 * �Ա�ֵ
	 * 
	 */
	public String getConsValue() {
		return consValue;
	}

	/**
	 * �Ա�ֵ
	 * 
	 */
	public void setConsValue(String consValue) {
		this.consValue = consValue;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((bankCDPK == null) ? 0 : bankCDPK.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankCD other = (BankCD) obj;
		if (bankCDPK == null) {
			if (other.bankCDPK != null)
				return false;
		} else if (!bankCDPK.equals(other.bankCDPK))
			return false;
		return true;
	}

	/**
	 * visiable
	 *
	 * @return the visiable
	 */
	
	public Choose getVisiable() {
		return visiable;
	}

	/**
	 * @param visiable the visiable to set
	 */
	public void setVisiable(Choose visiable) {
		this.visiable = visiable;
	}
	
}
