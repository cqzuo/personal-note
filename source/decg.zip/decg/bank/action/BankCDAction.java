/**
		* �ļ�����BankCDAction.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-25
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.bank.action;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.bank.BankCD;
import com.decg.bank.service.BankCDService;
import com.decg.base.common.Choose;
import com.decg.base.common.DECG_cons;
import com.opensymphony.xwork2.ActionContext;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�BankCDAction
 * ��������
 * �����ˣ�������
 * ����ʱ�䣺2011-3-25 ����11:19:15
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-25 ����11:19:15
 * �޸ı�ע��
 * @version
 *
 */

@Controller
@Scope("prototype")
public class BankCDAction {
	@Resource(name = "bankCDServiceBean")
	private BankCDService bankCDService;
	
	private BankCD bankCD = new BankCD();
	
	/**
	 * ��ѯ�б�
	 * return	
	 */
	public String execute() {
		String whereStatement = "o.visiable=?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		ActionContext.getContext().put("bankCDList", bankCDService.getScrollData(whereStatement, whereParam, null).getResultList());
		ActionContext.getContext().put("codeName", DECG_cons.BANK);
		return "bankCDList_success";
	}
	/**
	 * 
	 */
	public String addCDUI()
	{
		ActionContext.getContext().put("codeName", DECG_cons.BANK);
		return "addCDUI_success";
	}
	
	/**
	 * ת������code����
	 * ת��BankCDAction.action
	 */
	public String addCD() {
		bankCDService.save(this.bankCD);
		return "addCD_success";
	}
	
	/**
	 * ɾ��cd
	 * ת��BankCDAction.action
	 */
	public String deleteCD(){
		String setStatement = "o.visiable='" + Choose.NO +"'";
		String whereStatement = "o.consCD=?1 and o.consValue=?2";
		List<Object> param = new ArrayList<Object>();
		param.add(this.bankCD.getConsCD());
		param.add(this.bankCD.getConsValue());
		bankCDService.update(setStatement, whereStatement, param);
		return "deleteCD_success";
	}
	/**
	 * ת������cd ҳ��
	 */
	public String updateCDUI(){
		String whereStatement = "o.consCD=?1 and o.consValue=?2";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(this.bankCD.getConsCD());
		whereParam.add(this.bankCD.getConsValue());
		ActionContext.getContext().put("codeName", DECG_cons.BANK);
		ActionContext.getContext().put("updateOrNot", true);
		ActionContext.getContext().put("bankCDEntity", bankCDService.getScrollData(whereStatement, whereParam, null).getResultList().get(0));
		return "updateCDUI_success";
	}
	/**
	 * ����cd
	 * ת��BankCDAction.action
	 */
	public String updateCD(){
		bankCDService.update(bankCD);
		return "updateCD_success";
	}
	public BankCD getBankCD() {
		return bankCD;
	}

	public void setBankCD(BankCD bankCD) {
		this.bankCD = bankCD;
	}
	
	
}
