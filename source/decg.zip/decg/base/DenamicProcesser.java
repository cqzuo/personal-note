package com.decg.base;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * ��̬���账���ˣ���Ҫ���ڴ洢AB��ɫ�͸�����������������
 */
@Entity
public class DenamicProcesser implements Serializable {
	private static final long serialVersionUID = 7118768457037871620L;
	/** id **/
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;

	/** Ա����ϵ **/
	@Column(nullable=false)
	private String relation_id;

	/** ���� **/
	@Column(nullable=false)
	private String step_id;

	/** ���� **/
	@Column(nullable=false)
	private String task_id;

	/** ������ **/
	@Column(nullable=false)
	private String user_id;

	/** id **/
	public Integer getId() {
		return id;
	}

	/** id **/
	public void setId(Integer id) {
		this.id = id;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DenamicProcesser other = (DenamicProcesser) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	/** Ա����ϵ **/
	public String getRelation_id() {
		return relation_id;
	}

	/** Ա����ϵ **/
	public void setRelation_id(String relation_id) {
		this.relation_id = relation_id;
	}

	/** ���� **/
	public String getStep_id() {
		return step_id;
	}

	/** ���� **/
	public void setStep_id(String step_id) {
		this.step_id = step_id;
	}

	/** ���� **/
	public String getTask_id() {
		return task_id;
	}

	/** ���� **/
	public void setTask_id(String task_id) {
		this.task_id = task_id;
	}

	/** ������ **/
	public String getUser_id() {
		return user_id;
	}

	/** ������ **/
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
}
