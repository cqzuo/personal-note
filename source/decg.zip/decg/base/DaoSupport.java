package com.decg.base;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * ʵ��DAO�ӿ�
 * 
 * @param <T>
 *            ָ����������
 */

@SuppressWarnings("unchecked")
@Service
@Transactional
public abstract class DaoSupport<T> implements DAO<T> {
	// ע��EntityManager��
	@PersistenceContext
	protected EntityManager em;
	// ͨ�������ȡ��������
	private Class<T> entityClass = GenericsUtils.getSuperClassGenricType(this
			.getClass());

	public void delete(Serializable... entityIds) {
		for (Serializable entityId : entityIds) {
			em.remove(em.getReference(entityClass, entityId));
		}
	}
	
	public void delete(String whereStatement, List<Object> whereParam) {
		String entityName = getEntityName(this.entityClass);
		Query query = em.createQuery("delete from " + entityName + " o " + (whereStatement == null ? "" : " where " + whereStatement
				+ " "));
		setWhereParam(query, whereParam);
		query.executeUpdate();
	}

	public void delete(String whereStatement, Serializable entityId) {
		String entityName = getEntityName(this.entityClass);
		Query query = em.createQuery("delete from " + entityName + " o " + (whereStatement == null ? "" : " where " + whereStatement
				+ " "));
		query.setParameter(1, entityId);
		query.executeUpdate();
	}

	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public T find(Serializable entityId) {
		return em.find(entityClass, entityId);
	}

	public void save(T entity) {
		em.persist(entity);
	}

	public void update(T entity) {
		em.merge(entity);
		
	}
	
	public void update(String setStatement, String whereStatement,
			List<Object> param) {
		String entityName = getEntityName(this.entityClass);
		Query query = em.createQuery(" update " + entityName + " o set " + setStatement + (whereStatement == null ? "" : " where " + whereStatement));
		setWhereParam(query, param);
		query.executeUpdate();
	}

	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public QueryResult<T> getScrollData(int firstResult, int maxResult,
			String whereStatement, List<Object> whereParam,
			LinkedHashMap<String, String> orderBy, boolean isCount) {
		QueryResult<T> qr = new QueryResult<T>();
		String entityName = getEntityName(this.entityClass);
		Query query = em.createQuery("select o from "
				+ entityName
				+ " o "
				+ (whereStatement == null ? "" : " where " + whereStatement
						+ " ") + setOrderBy(orderBy));
		setWhereParam(query, whereParam);
		if (firstResult != -1 && maxResult != -1) {
			query.setFirstResult(firstResult).setMaxResults(maxResult);
		}
		qr.setResultList(query.getResultList());
		if (isCount) {
			query = em
					.createQuery("select count(o) from "
							+ entityName
							+ " o "
							+ (whereStatement == null ? "" : " where "
									+ whereStatement));
			setWhereParam(query, whereParam);
			qr.setTotalRecords((Long) query.getSingleResult());
		}
		return qr;
	}

	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public QueryResult<T> getScrollData(String whereStatement,
			List<Object> whereParam, LinkedHashMap<String, String> orderBy) {
		return this.getScrollData(-1, -1, whereStatement, whereParam, orderBy,
				false);
	}

	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public QueryResult<T> getScrollData(LinkedHashMap<String, String> orderBy) {
		return this.getScrollData(-1, -1, null, null, orderBy, false);
	}

	@Transactional(readOnly = true, propagation = Propagation.NOT_SUPPORTED)
	public boolean exist(String whereStatement, List<Object> whereParam) {
		String entityName = getEntityName(this.entityClass);
		Query query = em.createQuery("select count(o) from "
				+ entityName
				+ " o "
				+ (whereStatement == null ? "" : " where " + whereStatement
						+ " "));
		setWhereParam(query, whereParam);
		return (Long) query.getSingleResult() > 0;
	}

	/**
	 * ͨ�������ȥʵ��bean������
	 * 
	 * @param <E>
	 *            ʵ������
	 * @param entityClass
	 *            ʵ���Class����
	 * @return ����ʵ���������
	 */
	protected static <E> String getEntityName(Class<E> entityClass) {
		String entityName = entityClass.getSimpleName();
		Entity entity = entityClass.getAnnotation(Entity.class);
		if (entity.name() != null && !"".equals(entity.name())) {
			entityName = entity.name();
		}
		return entityName;
	}

	/**
	 * �����������
	 * 
	 * @param <E>
	 *            ʵ������
	 * @param orderBy
	 *            ��������
	 * @return �������
	 */
	protected static String setOrderBy(LinkedHashMap<String, String> orderBy) {
		StringBuilder orderByStatement = new StringBuilder(50);
		if (orderBy != null && orderBy.size() > 0) {
			orderByStatement.append(" order by ");
			for (String key : orderBy.keySet()) {
					orderByStatement.append(" o.").append(key).append(" ")
					.append(orderBy.get(key)).append(",");
			}
			orderByStatement.deleteCharAt(orderByStatement.length() - 1);
		}
		return orderByStatement.toString();
	}

	/**
	 * ���ò�ѯ����
	 * 
	 * @param query
	 *            ��ѯ�ӿ�
	 * @param whereParam
	 *            ��ѯ����
	 */
	protected static void setWhereParam(Query query, List<Object> whereParam) {
		if (whereParam != null && whereParam.size() > 0) {
			for (int i = 0; i < whereParam.size(); i++) {
				query.setParameter(i + 1, whereParam.get(i));
			}
		}
	}

}
