//package com.decg.base.common;
//
//import java.io.IOException;
//import java.lang.reflect.Field;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.ResultSetMetaData;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Properties;
//
//import javax.servlet.ServletContextEvent;
//import javax.servlet.ServletContextListener;
//
//import com.mysql.jdbc.PreparedStatement;
//
//public class RelationListener implements ServletContextListener {
//
//	public void contextDestroyed(ServletContextEvent servletContextEvent) {
//	}
//
//	public void contextInitialized(ServletContextEvent servletContextEvent) {
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		//Map<Integer, Relation> relations = null;
//		Properties p = new Properties();
//		try {
//			p.load(this.getClass().getClassLoader().getResourceAsStream("jdbc.properties"));
//			Class.forName(p.getProperty("driverClass"));
//		} catch (IOException e) {
//			throw new RuntimeException("jdbc.properties�ļ�δ�ҵ�.", e);
//		} catch (ClassNotFoundException e) {
//			throw new RuntimeException("�Ҳ������ݿ�������.", e);
//		}
//		try {
//			conn = DriverManager.getConnection(p.getProperty("url"), p.getProperty("username"), p.getProperty("password"));
//			pstmt = (PreparedStatement) conn.prepareStatement("select * from relation");
//			//rs = pstmt.executeQuery();
////			List<Relation> relationList = getRelationList(rs, Relation.class);
////			if(relationList != null && relationList.size() > 0) {
////				for(Relation relation : relationList) {
////					relations = new HashMap<Integer, Relation>();
////					relations.put(relation.getProjectManagerId(), relation);
////				}
////				servletContextEvent.getServletContext().setAttribute(DECG_cons.RELATIONS, relations);
////				System.out.println("��Ϣ��" + relations.size() + "����Ա��ϵ�ɹ�����application��Χ.");
////			} else {
////				System.out.println("��Ϣ��û����Ա��ϵ����.");
////			}
////		} catch (SQLException e) {
////			throw new RuntimeException(e.getMessage(), e);
////		} catch (InstantiationException e) {
////			throw new RuntimeException(e.getMessage(), e);
////		} catch (IllegalAccessException e) {
////			throw new RuntimeException(e.getMessage(), e);
////		} finally {
////			try {
////				if(rs != null) {
////					rs.close();
////					rs = null;
////					System.out.println("��Ϣ��ResultSet�ɹ��ر�");
////				}
////			} catch (SQLException e) {
////				e.printStackTrace();
////			} finally {
////				try {
////					if(pstmt != null) {
////						pstmt.close();
////						pstmt = null;
////						System.out.println("��Ϣ��Statement�ɹ��ر�");
////					}
////				} catch (SQLException e) {
////					e.printStackTrace();
////				} finally {
////					try {
////						if(conn != null) {
////							conn.close();
////							conn = null;
////							System.out.println("��Ϣ��Connection�ɹ��ر�");
////						}
////					} catch (SQLException e) {
////						e.printStackTrace();
////					} finally {
////						conn = null;
////					}
////				}
////			}
////		}
//	}
//	
//	/**
//	 * ����¼ת��ΪList����
//	 * @param <T>
//	 * @param rs			�����
//	 * @param entityClass	ʵ������
//	 * @return				List<T>
//	 */
//	private <T> List<T> getRelationList(ResultSet rs, Class<T> entityClass) throws SQLException, InstantiationException, IllegalAccessException {
//		List<T> ts = new ArrayList<T>();
//		ResultSetMetaData rsmd = rs.getMetaData();
//		int rsCount = rsmd.getColumnCount();
//		Field[] fields = entityClass.getDeclaredFields();
//		while (rs.next()) {
//			T t = entityClass.newInstance();
//			for(int i=1; i<=rsCount; i++) {
//				Object value = rs.getObject(i);
//				String columnName = rsmd.getColumnName(i);
//				for(int j=0; j<fields.length; j++) {
//					Field f = fields[j];
//					String fieldName = f.getName();
//					if(fieldName.equalsIgnoreCase(columnName)) {
//						boolean flag = f.isAccessible();
//						f.setAccessible(true);
//						f.set(t, value);
//						f.setAccessible(flag);
//					}
//				}
//			}
//			ts.add(t);
//		}
//		return ts;
//	}
//	
//}
