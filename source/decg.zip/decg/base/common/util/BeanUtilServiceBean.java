/**
		* �ļ�����BeanUtilServiceBean.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-31
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.base.common.util;

import java.lang.reflect.Field;

import com.decg.base.common.annotation.Ignore;
import com.decg.base.common.annotation.Mapping;


/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�BeanUtilServiceBean
 * ����������ʵ��bean�еĸ�������ֵcopy��viewBean��
 * �����ˣ�Administrator
 * ����ʱ�䣺2011-3-31 ����09:20:55
 * �޸��ˣ�Administrator
 * �޸�ʱ�䣺2011-3-31 ����09:20:55
 * �޸ı�ע��
 * @version
 *
 */
public class BeanUtilServiceBean implements BeanUtilService {

	public <T> T copy(Class<T> veiwClazz, Object... objects) {
		T t = null;
		try {
			if(objects == null) {
				throw new RuntimeException("No parameter!");
			}
			
			t = veiwClazz.newInstance();
			
			for (int i = 0; i < objects.length; i++) {
				Object obj = objects[i];
				Class<?> clazzs = obj.getClass();
				Field[] fields = clazzs.getDeclaredFields();
				for (int j = 0; j < fields.length; j++) {
					Field field = fields[i];
					Ignore ignore = field.getAnnotation(Ignore.class);
					if(ignore == null) {
						Mapping mapping = field.getAnnotation(Mapping.class);
						String fieldName = null;
						if(mapping != null) {
							fieldName = mapping.name();
						} else {
							fieldName = field.getName();
						}
						if(fieldName == null) {
							throw new RuntimeException("The field named '" + fieldName + "' is not exist!");
						}
						Object value = field.get(obj);
						Field viewField = veiwClazz.getDeclaredField(fieldName);
						boolean flag = viewField.isAccessible();
						viewField.setAccessible(true);
						viewField.set(t, value);
						viewField.setAccessible(flag);
					}
				}
			}
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		
		return t;
		
	}

}
