package com.decg.base.common;

import java.io.IOException;
import java.util.Properties;

public final class PropertiesUtil {
	private PropertiesUtil(){}
	private static Properties p = null;
	static {
		p = new Properties();
		try {
			p.load(PropertiesUtil.class.getClassLoader().getResourceAsStream("config.properties"));
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("�޷���ȡconfig.properties�ļ�.", e);
		}
	}
	
	public static final String get(String key) {
		return (String) p.get(key);
	}
}
