package com.decg.base.common.init;

import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EmbeddedId;
import javax.persistence.Id;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.base.DaoSupport;
import com.decg.base.common.Choose;
import com.decg.projectnostrategy.Prefix;

@SuppressWarnings("rawtypes")
@Service
public class InitialImpl extends DaoSupport implements Initial {
/**
 * ��ʼ���ӿ�ʵ����
 */
	@SuppressWarnings("unchecked")
	@Transactional
	public boolean parse() {
		try {
			// ��ȡ��ʼ��xml�ļ�
			Document doc = InitialImpl.read("initial.xml");

			// �洢����map
			Map<String, Object> m = new HashMap<String, Object>();
			// �������ļ��л�ȡ����bean
			Element rootElm = doc.getRootElement();   
			List<Element> listRoleNodes = rootElm.elements("bean");    
			Iterator<Element> IteratorRoleNodes = listRoleNodes.iterator();
			while (IteratorRoleNodes.hasNext()) {
				Element e = (Element) IteratorRoleNodes.next();
				// �����ڵ�,��ȡ�������ƺ�ֵ
				Iterator<Attribute> attrIter = e.attributeIterator();
				String systemId = "";
				String className = "";
				Object o = null;

				while (attrIter.hasNext()) {
					Object obj = null;
					Attribute attr = (Attribute) attrIter.next();
					String attrName = attr.getName();
					String attrValue = attr.getValue();
					// ����type����ȡ����
					if (attrName.equals("type")) {
						className = attrValue;
						Class c = Class.forName(attrValue);
						o = c.newInstance();

					}else if (attrName.equals("systemId")) {
						systemId = attrValue;
					} else {
						
						//�������type����systemId��ֱ��Ϊ���Ը�ֵ
						Class clazz = Class.forName(className);
						Field field = clazz.getDeclaredField(attrName);
						Choose cc = null;
						Prefix pr = null;
						obj = attrValue;
						boolean flag = field.isAccessible();
						field.setAccessible(true);
						//�����ö������,ת��ΪString����
						if(field.getType().getSimpleName().equalsIgnoreCase("choose")) {
							cc = Choose.valueOf(Choose.class, obj.toString());
							obj = cc;
						} else if(field.getType().getSimpleName().equalsIgnoreCase("prefix")) {
							pr = Prefix.valueOf(Prefix.class, obj.toString());
							obj = pr;
						}
						field.set(o, obj);
						field.setAccessible(flag);
					}
				}
				
				
				if(e.hasContent()) {
					Object oo = null;
					String classNameo = "";
					// ����ýڵ��»��нڵ�,��ִ�е�������Զ�Ӧ�Ķ���
					List listChildrenNodesOfPK = e.elements("pk");
					//�������pk�ڵ�
					if(listChildrenNodesOfPK != null && listChildrenNodesOfPK.size()>0) {
						if(listChildrenNodesOfPK.size()>1) {
							throw new RuntimeException( "Bean node has more then one 'pk'.");
						}
						Element ePK = (Element) listChildrenNodesOfPK.get(0);
						Iterator<Attribute> attrPKIter = ePK.attributeIterator();
						while(attrPKIter.hasNext()) {
							Attribute attr = (Attribute) attrPKIter.next();
							String attrName = attr.getName();
							String attrValue = attr.getValue();
							// ����type����ȡ����
							if (attrName.equals("type")) {
								classNameo = attrValue;
								Class c = Class.forName(attrValue);
								oo = c.newInstance();
							}
						}
						
						
						List listChildNodes = ePK.elements("ref");
						if(listChildNodes == null || listChildNodes.size()<=0) {
							throw new RuntimeException("The 'pk' node must contain one or more 'ref' nodes.");
						}
						
						Field field = null;
						Class fieldType = null;
						Object value = null;
						
						
						Iterator iteratorChildNodes = listChildNodes.iterator();
						while (iteratorChildNodes.hasNext()) {
							Element ec = (Element) iteratorChildNodes.next();
							Iterator attrIterChild = ec.attributeIterator();
							while (attrIterChild.hasNext()) {
								Attribute ac = (Attribute) attrIterChild.next();
								String attrName = ac.getName();
								String attrValue = ac.getValue();
								
								
								if(!"classType".equals(attrName)) {
									Class clazz = Class.forName(classNameo);
									field = clazz.getDeclaredField(attrName);
									value = attrValue;
								} else {
									fieldType = Class.forName(attrValue);
								}
								
								
								//��oo����ֵ��o������
								Field executeField = null;
								Class clazz = Class.forName(className);
								Field[] fields = clazz.getDeclaredFields();
								for (int i = 0; i < fields.length; i++) {
									Field fieldo = fields[i];
									EmbeddedId embeddedId = fieldo.getAnnotation(EmbeddedId.class);
									if(embeddedId != null) {
										executeField = fieldo;
										break;
									}
								}
								
								if(executeField != null) {
									Object returnValue = null;
									Object obj = m.get(value);
									Field[] fieldso = obj.getClass().getDeclaredFields();
									for (int i = 0; i < fieldso.length; i++) {
										Field fieldo = fieldso[i];
										Id id = fieldo.getAnnotation(Id.class);
										if(id != null) {
											boolean flag = fieldo.isAccessible();
											fieldo.setAccessible(true);
											returnValue = fieldo.get(obj);
											fieldo.setAccessible(flag);
										}
									}
									
									if(field != null) {
										if(fieldType != null) {
											if(fieldType.getSimpleName().equals("Integer")) {
												returnValue = Integer.parseInt("" + returnValue);
											} 
										}
										boolean flag = field.isAccessible();
										field.setAccessible(true);
										field.set(oo, returnValue);
										field.setAccessible(flag);
										fieldType = null;
									}
									boolean flag = executeField.isAccessible();
									executeField.setAccessible(true);
									executeField.set(o, oo);
									executeField.setAccessible(flag);
								}
								
							}
							
						}
						
						
						
					} else {
						List listChildNodes = e.elements("ref");
						Iterator iteratorChildNodes = listChildNodes.iterator();
						while (iteratorChildNodes.hasNext()) {
							Element ec = (Element) iteratorChildNodes.next();
							Iterator attrIterChild = ec.attributeIterator();
							while (attrIterChild.hasNext()) {
								Attribute ac = (Attribute) attrIterChild.next();
								String attrName = ac.getName();
								String attrValue = ac.getValue();
								Object obj = m.get(attrValue);
								Field[] fields = obj.getClass().getDeclaredFields();
								Field executeField = null;
								for (int i = 0; i < fields.length; i++) {
									Field field = fields[i];
									Id id = field.getAnnotation(Id.class);
									if(id != null) {
										executeField = field;
										break;
									}
								}
								if(executeField != null) {
									boolean flag = executeField.isAccessible();
									executeField.setAccessible(true);
									Object returnValue = executeField.get(obj);
									executeField.setAccessible(flag);
									Class clazz = Class.forName(className);
									Field feild = clazz.getDeclaredField(attrName);
									boolean flags = feild.isAccessible();
									feild.setAccessible(true);
									feild.set(o, returnValue);
									feild.setAccessible(flags);
								}
							}
						}
					}
				}
				// ���ö�����map��
				m.put(systemId, o);
				em.persist(o);
				em.flush();
				em.clear();
			}
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}

		return true;
	}

	// ��ָ���ļ�����ȡDocument����
	public static Document read(String fileName) throws MalformedURLException,
			DocumentException {
		SAXReader reader = new SAXReader();
		Document doc = reader.read(InitialImpl.class.getClassLoader().getResourceAsStream(fileName));
		return doc;
	}

}