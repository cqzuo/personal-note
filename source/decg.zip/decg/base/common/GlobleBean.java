package com.decg.base.common;

public abstract class GlobleBean implements Globle {
}
