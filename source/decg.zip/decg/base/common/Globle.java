package com.decg.base.common;

import java.util.Date;

import com.decg.bank.Bank;
import com.decg.enterprise.Enterprise;
import com.decg.enterprise.EnterpriseType;
import com.decg.enterprise.RegistType;
import com.decg.loantype.LoanType;
import com.decg.project.Project;
import com.decg.project.Source;
import com.decg.project.Suggestion;
import com.decg.step.Step;
import com.decg.task.Task;
import com.decg.user.User;

public interface Globle {
	public LoanType getLoanType() ;

	public void setLoanType(LoanType loanType) ;

	public User getUser() ;
	
	public void setUser(User user) ;

	public Enterprise getEnterprise()  ;

	public void setEnterprise(Enterprise enterprise) ;

	public Project getProject() ;

	public void setProject(Project project) ;

	public Suggestion getSuggestion() ;

	public void setSuggestion(Suggestion suggestion) ;

	public EnterpriseType getEnterpriseType() ;

	public void setEnterpriseType(EnterpriseType enterpriseType) ;

	public RegistType getRegistType()  ;

	public void setRegistType(RegistType registType) ;

	public Source getSource() ;

	public void setSource(Source source) ;

	public LoanType getLoanTypeChildren() ;

	public void setLoanTypeChildren(LoanType loanTypeChildren) ;

	public Bank getBank1() ;

	public void setBank1(Bank bank1) ;

	public Bank getBankChildren1() ;

	public void setBankChildren1(Bank bankChildren1) ;

	public Bank getBank2() ;

	public void setBank2(Bank bank2) ;

	public Bank getBankChildren2() ;

	public void setBankChildren2(Bank bankChildren2) ;
	
	public Task getTask() ;

	public void setTask(Task task) ;

	public Step getStep() ;

	public void setStep(Step step) ;
	
	public Integer getTask_id() ;

	public void setTask_id(Integer task_id) ;

	public Date getTask_submitTime() ;

	public void setTask_submitTime(Date task_submitTime) ;

	public String getUser_realName() ;

	public void setUser_realName(String user_realName) ;

	public String getEnterprise_name() ;

	public void setEnterprise_name(String enterprise_name) ;

	public Integer getProject_id() ;

	public void setProject_id(Integer project_id) ;

	public Integer getStep_id() ;

	public void setStep_id(Integer step_id) ;
}
