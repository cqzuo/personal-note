package com.decg.base.common;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EmbeddedId;
import javax.persistence.Id;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.base.DaoSupport;


@SuppressWarnings("rawtypes")
@Service
@Transactional
public class StartupOrShutdownImpl extends DaoSupport implements
		StartupOrShutdown {

	public <T> void startup(Class<T> entityClass, String filed, List<Object> ids) {
		List<String> idFields = getIdFields(entityClass);
		Query q = em.createQuery("update " + getEntityName(entityClass) + " o set o." + filed + " = '" + Choose.YES.toString() + "' where " + getWhereStatement(idFields, ids));
		setWhereParam(q, ids);
		q.executeUpdate();
	}

	public <T> void shutdown(Class<T> entityClass, String filed, List<Object> ids) {
		List<String> idFields = getIdFields(entityClass);
		Query q = em.createQuery("update " + getEntityName(entityClass) + " o set o." + filed + " = '" + Choose.NO.toString() + "' where " + getWhereStatement(idFields, ids));
		setWhereParam(q, ids);
		q.executeUpdate();
	}
	
	/**
	 * ��ȡID�ֶ���,�������������,���ȡ�����������ֶ���,�����ȡ@Id��Ӧ���ֶ���
	 */
	private <T> List<String> getIdFields(Class<T> entityClass) {
		List<String> idFieldNames = new ArrayList<String>();
		Field[] fields = entityClass.getDeclaredFields();
		for (int i = 0; i < fields.length; i++) {
			Field field = fields[i];
			EmbeddedId embeddedId = field.getAnnotation(EmbeddedId.class);
			if(embeddedId == null) {
				Id id = field.getAnnotation(Id.class);
				if(id != null) {
					idFieldNames.add(field.getName());
				}
			} else {
				idFieldNames.clear();
				idFieldNames.add(field.getName());
				break;
			}
		}
		return idFieldNames;
	}
	
	/**
	 * ����������
	 */
	private String getWhereStatement(List<String> idFields, List<Object> ids) {
		if(idFields.size() > 1 || idFields.size() == 0) {
			throw new RuntimeException("IdFields' size is more than one or equals zero!");
		}
		StringBuilder sb1 = new StringBuilder(50);
		for (int i = 0; i < ids.size(); i++) {
			sb1.append("?").append(i + 1).append(",");
		}
		sb1.deleteCharAt(sb1.length()-1);
		StringBuilder sb = new StringBuilder(30);
		for (int j = 0; j < idFields.size(); j++) {
			sb.append(" o.").append(idFields.get(j)).append(" in (").append(sb1.toString()).append(")");
		}
		return sb.toString();
	}
	

}
