package com.decg.base;

import java.util.List;

/**
 * ��ѯ�����װ��
 * @param <T> ʵ����
 */
public class QueryResult<T> {
	/** ��ѯ�����¼ **/
	private List<T> resultList;
	/** �ܼ�¼�� **/
	private long totalRecords;
	
	public List<T> getResultList() {
		return resultList;
	}
	public void setResultList(List<T> resultList) {
		this.resultList = resultList;
	}
	public long getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}
	
}
