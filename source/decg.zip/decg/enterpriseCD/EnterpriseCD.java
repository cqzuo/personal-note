package com.decg.enterpriseCD;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;
import com.decg.base.common.Choose;


/**
 * 
 */
@IdClass(EnterpriseCDPK.class)
@Entity
@Table(name="enterpriseCD")
public class EnterpriseCD implements Serializable {
	private static final long serialVersionUID = 9164572575251048650L;
	
	/**
	 * Id
	 */
	 @Transient
	 @EmbeddedId
	private EnterpriseCDPK enterpriseCDPK;
	/**
	 * �Ա�code
	 */
	 @Id
	 @Column(length=10,nullable=false)
	private String consCD = null;
	/**
	 * codeֵ
	 */
	@Id
	@Column(length=1,nullable=false)
	private String consValue = null;
	/**
	 * ����
	 */
	 @Column(length=32,nullable=false,unique=true)
	private String name = null;
	/**
	 * ��ע
	 */
	 @Column(length=255)
	private String demo = null;
	/**
	 * �ɼ���
	 */
	 @Column(length = 3, nullable = true, updatable = false)
	 @Enumerated(EnumType.STRING)
	private Choose visiable = Choose.YES;
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((enterpriseCDPK == null) ? 0 : enterpriseCDPK.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EnterpriseCD other = (EnterpriseCD) obj;
		if (enterpriseCDPK == null) {
			if (other.enterpriseCDPK != null)
				return false;
		} else if (!enterpriseCDPK.equals(other.enterpriseCDPK))
			return false;
		return true;
	}

	/**
	 * Id
	 */
	public EnterpriseCDPK getEnterpriseCDPK() {
		return enterpriseCDPK;
	}

	/**
	 * Id
	 */
	public void setEnterpriseCDPK(EnterpriseCDPK enterpriseCDPK) {
		this.enterpriseCDPK = enterpriseCDPK;
	}

	/**
	 * �Ա�code
	 */
	public String getConsCD() {
		return consCD;
	}

	/**
	 * �Ա�code
	 */
	public void setConsCD(String consCD) {
		this.consCD = consCD;
	}

	/**
	 * codeֵ
	 */
	public String getConsValue() {
		return consValue;
	}

	/**
	 * codeֵ
	 */
	public void setConsValue(String consValue) {
		this.consValue = consValue;
	}

	/**
	 * ����
	 */
	public String getName() {
		return name;
	}

	/**
	 * ����
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * ��ע
	 */
	public String getDemo() {
		return demo;
	}

	/**
	 * ��ע
	 */
	public void setDemo(String demo) {
		this.demo = demo;
	}

	/**
	 * �ɼ���
	 */
	public Choose getVisiable() {
		return visiable;
	}

	/**
	 * �ɼ���
	 */
	public void setVisiable(Choose visiable) {
		this.visiable = visiable;
	}
}
