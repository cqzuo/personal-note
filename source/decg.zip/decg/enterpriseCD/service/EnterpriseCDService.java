package com.decg.enterpriseCD.service;

import com.decg.base.DAO;
import com.decg.enterpriseCD.EnterpriseCD;

public interface EnterpriseCDService extends DAO<EnterpriseCD> {
}
