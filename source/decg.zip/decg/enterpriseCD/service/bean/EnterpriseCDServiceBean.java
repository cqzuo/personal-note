package com.decg.enterpriseCD.service.bean;

import org.springframework.stereotype.Service;

import com.decg.base.DaoSupport;
import com.decg.enterpriseCD.EnterpriseCD;
import com.decg.enterpriseCD.service.EnterpriseCDService;

@Service
public class EnterpriseCDServiceBean extends DaoSupport<EnterpriseCD> implements EnterpriseCDService{

}
