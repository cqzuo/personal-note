package com.decg.enterpriseCD;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class EnterpriseCDPK implements Serializable {
	
	private static final long serialVersionUID = -7827470631737184543L;
	/**
	 * �Ա�����
	 */
	@Column(length=10,nullable=false)
	private String consCD;
	/**
	 * �Ա�ֵ
	 */
	@Column(length=1,nullable=false)
	private String consValue;
	/**
	 * �Ա�����
	 */
	public String getConsCD() {
		return consCD;
	}
	/**
	 * �Ա�����
	 */
	public void setConsCD(String consCD) {
		this.consCD = consCD;
	}
	/**
	 * �Ա�ֵ
	 */
	public String getConsValue() {
		return consValue;
	}
	/**
	 * �Ա�ֵ
	 */
	public void setConsValue(String consValue) {
		this.consValue = consValue;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((consCD == null) ? 0 : consCD.hashCode());
		result = prime * result
				+ ((consValue == null) ? 0 : consValue.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EnterpriseCDPK other = (EnterpriseCDPK) obj;
		if (consCD == null) {
			if (other.consCD != null)
				return false;
		} else if (!consCD.equals(other.consCD))
			return false;
		if (consValue == null) {
			if (other.consValue != null)
				return false;
		} else if (!consValue.equals(other.consValue))
			return false;
		return true;
	}
}
