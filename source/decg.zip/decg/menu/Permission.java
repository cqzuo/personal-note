/**
		* �ļ�����Permission.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-20
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.menu;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * ��Ŀ���ƣ�DECG_NEW
 * �����ƣ�Permission
 * ��������Ȩ��ʵ��
 * �����ˣ�������
 * ����ʱ�䣺2011-3-20 ����01:34:54
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-20 ����01:34:54
 * �޸ı�ע��
 * @version
 *
 */

@Entity
@Table(name = "Permission")
public class Permission implements Serializable {
	private static final long serialVersionUID = 5961832928269601099L;
	/**
	 * id
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer permission_Id;
	
	/**
	 * ��ɫid
	 * @Column(length = 11, nullable = false)
	 */
	@Column(length = 11, nullable = false)
	private String role_id = null;
	
	/**
	 * �˵�id
	 * @Column(length = 11, nullable = false)
	 */
	@Column(length = 11, nullable = false)
	private Integer menu_id = null;

	/**
	 * ��ɫid
	 * @Column(length = 11, nullable = false)
	 */
	public String getRole_id() {
		return role_id;
	}
	/**
	 * ��ɫid
	 * @Column(length = 11, nullable = false)
	 */
	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}
	/**
	 * �˵�id
	 * @Column(length = 11, nullable = false)
	 */
	public Integer getMenu_id() {
		return menu_id;
	}
	/**
	 * �˵�id
	 * @Column(length = 11, nullable = false)
	 */
	public void setMenu_id(Integer menu_id) {
		this.menu_id = menu_id;
	}
	/**
	 * id
	 */
	public Integer getPermission_Id() {
		return permission_Id;
	}
	/**
	 * id
	 */
	public void setPermission_Id(Integer permission_Id) {
		this.permission_Id = permission_Id;
	}
	/*
			(non-Javadoc)
			* @see java.lang.Object#hashCode()
			*/
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((permission_Id == null) ? 0 : permission_Id.hashCode());
		return result;
	}
	/*
			(non-Javadoc)
			* @see java.lang.Object#equals(java.lang.Object)
			*/
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Permission other = (Permission) obj;
		if (permission_Id == null) {
			if (other.permission_Id != null)
				return false;
		} else if (!permission_Id.equals(other.permission_Id))
			return false;
		return true;
	}
	
}
