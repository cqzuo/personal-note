/**
		* �ļ�����PermissionAction.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-20
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.menu.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import com.decg.menu.Permission;
import com.decg.menu.service.PermissionService;

/**
 *
 * ��Ŀ���ƣ�DECG_NEW
 * �����ƣ�PermissionAction
 * ��������Ȩ�޵Ĳ���
 * �����ˣ�������
 * ����ʱ�䣺2011-3-20 ����01:50:39
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-20 ����01:50:39
 * �޸ı�ע��
 * @version
 *
 */

@Controller
@Scope("prototype")
public class PermissionAction  implements ServletResponseAware {
	private HttpServletResponse response;
	@Resource(name = "permissionServiceBean")
	private PermissionService permissionService;
	private Permission permission = new Permission();
	
	/**
	 * ��Ȩ
	 */
	public String givePermission() {
		try {
			String whereStatement = "o.menu_id=?1 and o.role_id=?2";
			List<Object> whereParam = new ArrayList<Object>();
			whereParam.add(this.permission.getMenu_id());
			whereParam.add(this.permission.getRole_id());
			List<Permission> permissionList = permissionService.getScrollData(whereStatement, whereParam, null).getResultList();
			if(permissionList.isEmpty()) {
				permission.setMenu_id(this.permission.getMenu_id());
				permission.setRole_id(this.permission.getRole_id());
				permissionService.save(permission);
			}
			response.getWriter().write("1");
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		return null;
	}
	
	/**
	 * ȡ����Ȩ
	 */
	public String deletePermission() {
		try {
			String whereStatement = "o.menu_id=?1 and o.role_id=?2";
			List<Object> whereParam = new ArrayList<Object>();
			whereParam.add(this.permission.getMenu_id());
			whereParam.add(this.permission.getRole_id());
			permissionService.delete(whereStatement, whereParam);
			response.getWriter().write("1");
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		return null;
	}

	
	public Permission getPermission() {
		return permission;
	}

	public void setPermission(Permission permission) {
		this.permission = permission;
	}

	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}
}
