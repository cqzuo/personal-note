/**
		* �ļ�����MenuAction.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-19
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.menu.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletResponseAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.QueryResult;
import com.decg.menu.Menu;
import com.decg.menu.service.MenuService;
import com.decg.user.Role;
import com.opensymphony.xwork2.ActionContext;

/**
 *
 * ��Ŀ���ƣ�DECG_NEW
 * �����ƣ�MenuAction
 * ���������˵��Ĳ���
 * �����ˣ�������
 * ����ʱ�䣺2011-3-19 ����07:36:23
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-19 ����07:36:23
 * �޸ı�ע��
 * @version
 *
 */

@Controller
@Scope("prototype")
public class MenuAction implements ServletResponseAware {
	private HttpServletResponse response;

	@Resource(name = "menuServiceBean")
	private MenuService menuService;
	
	private Menu menu = new Menu();
	private Role role = new Role();
	
	/**
	 * execute(���parentIdΪ�գ����ѯ���ж����˵�������id�������� �����ѯmenu.parentId = parentId�Ĳ˵�)
	 * return  /WEB-INF/page/menu/menuList.jsp
	 */
	public String execute() {
		Integer parentId = menu.getParentId();
		
		QueryResult<Menu> qr = null;
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("menuId", "asc");
		String whereStatement = "o.parentId is null";
		if(parentId == null) {
			qr= menuService.getScrollData(whereStatement, null, orderBy);
		} else {
			ActionContext.getContext().put("pMenu", menuService.find(parentId));
			//�����id��Ϊ�գ����ѯ�Ӳ˵�
			whereStatement = "o.parentId = ?1";
			List<Object> whereParam = new ArrayList<Object>();
			whereParam.add(parentId);
			qr = menuService.getScrollData(whereStatement, whereParam, orderBy);
		}
		ActionContext.getContext().put("menuList", qr.getResultList());
		return "menuList_success";
	}
	
	/**
	 * addMenuUI(ת�����Ӹ��˵�����)
	 * return	/WEB-INF/page/menu/addMenuUI.jsp
	 */
	public String addMenuUI() {
		return "addMenuUI_success";
	}
	
	/**
	 * addMenu(���Ӳ˵�)
	 * return	MenuAction.action
	 */
	public String addMenu() {
		menuService.save(menu);
		return "goList_success";
	}

	/**
	 * deleteMenu(ɾ���˵�)
	 * return	
	 */
	public String deleteMenu() {
		menuService.delete(menu.getMenuId());
		return "goList_success";
	}
	
	/**
	 * ajax��֤�Ƿ����Ӳ˵�
	 * return	/WEB-INF/page/share/ajax_message.jsp
	 */
	public String hasChildren() {
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(menu.getMenuId());
		boolean flag = menuService.exist("o.parentId = ?1", whereParam);
		if(flag) {
			try {
				response.getWriter().write("1");
			} catch (IOException e) {
				throw new RuntimeException(e.getMessage(), e);
			}
		} 
		return null;
	}
	
	/**
	 * ת����½���
	 * return	/WEB-INF/page/menu/updateMenuUI.jsp
	 */
	public String updateMenuUI() {
		ActionContext.getContext().put("entity", menuService.find(menu.getMenuId()));
		ActionContext.getContext().put("updateOrNot", true);
		return "updateMenuUI_success";
	}
	
	/**
	 * ���²˵���Ϣ
	 * return	MenuAction.action?menu.parentId=${menu.parentId}
	 */
	public String updateMenu() {
		menuService.update(menu);
		return "goList_success";
	}
	
	/**
	 * ���ж����˵�
	 * return	/WEB-INF/page/menu/allMenu.jsp
	 */
	public String allMenu() {
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("menuId", "asc");
		QueryResult<Menu> qr = menuService.getScrollData("o.parentId is null", null, orderBy);
		ActionContext.getContext().put("menuList", qr.getResultList());
		
		/** ���ݽ�ɫ��ѯ�ý�ɫ�������Ĳ˵� **/
		List<Menu> menuList = menuService.getPermitMenus(this.role.getRoleId());
		ActionContext.getContext().getSession().put("permitMenuList", menuList);
		return "allMenu_success";
	}
	
	/**
	 * ajax��ѯ���˵������������Ӳ˵�
	 */
	public String findChildrenMenu() {
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("menuId", "asc");
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(menu.getParentId());
		QueryResult<Menu> qr = menuService.getScrollData("o.parentId = ?1", whereParam, orderBy);
		ActionContext.getContext().put("menuList", qr.getResultList());
		/** ���ݽ�ɫ��ѯ�ý�ɫ�������Ĳ˵� **/
		List<Menu> menuList = menuService.getPermitMenus(this.role.getRoleId());
		ActionContext.getContext().getSession().put("permitMenuList", menuList);
		return "findChildrenMenu_success";
	}
	
	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	
	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}
	
}
