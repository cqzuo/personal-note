/**
		* �ļ�����LoanTypeAction.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-23
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.loantype.action;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.QueryResult;
import com.decg.loantype.LoanType;
import com.decg.loantype.service.LoanTypeService;
import com.opensymphony.xwork2.ActionContext;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�LoanTypeAction
 * ��������
 * �����ˣ�������
 * ����ʱ�䣺2011-3-23 ����04:43:26
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-23 ����04:43:26
 * �޸ı�ע��
 * @version
 *
 */

@Controller
@Scope("prototype")
public class LoanTypeAction {
	@Resource(name = "loanTypeServiceBean")
	private LoanTypeService loanTypeService;
	
	private LoanType loanType = new LoanType();
	private String filed = null;
	private List<Integer> ids = new ArrayList<Integer>();
	//������ر�ĳ���ܵı��,"true"Ϊ����, "false"Ϊ�ر�
	private Boolean flag = null;
	
	/**
	 * ������������Ʒ��
	 * return	/WEB-INF/page/loanType/loanTypeList.jsp
	 */
	public String execute() {
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(loanType.getParentId());
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("loanTypeId", "asc");
		QueryResult<LoanType> qr = null;
		if(loanType.getParentId() == null) {
			qr = loanTypeService.getScrollData("o.parentId is null and o.visible = true", null, orderBy);
		} else {
			qr = loanTypeService.getScrollData("o.parentId = ?1 and o.visible = true", whereParam, orderBy);
		}
		ActionContext.getContext().put("loantypeList", qr.getResultList());
		return "loanTypeList_success";
	}
	
	/**
	 * ת����������Ʒ�ֽ���
	 * return	/WEB-INF/page/loanType/addLoanTypeUI.jsp
	 */
	public String addUI() {
		return "addUI_success";
	}
	
	/**
	 * ��������Ʒ��
	 * return	LoanTypeAction.action?loanType.parentId=${loanType.parentId}
	 */
	public String addLoanType() {
		loanTypeService.save(loanType);
		return "goList_success";
	}
	
	/**
	 * ɾ������Ʒ��
	 * return	LoanTypeAction.action?loanType.parentId=${loanType.parentId}
	 */
	public String delLoanType() {
		loanTypeService.delete("o.loanTypeId = ?1", loanType.getLoanTypeId());
		return "goList_success";
	}
	
	/**
	 * ת�����½���
	 * return	/WEB-INF/page/loanType/updateLoanType.jsp
	 */
	public String updateUI() {
		ActionContext.getContext().put("loanTypeEntity", loanTypeService.find(loanType.getLoanTypeId()));
		ActionContext.getContext().put("updateOrNot",true);
		return "updateUI_success";
	}
	
	/**
	 * ��������Ʒ����Ϣ
	 * return	LoanTypeAction.action?loanType.parentId=${loanType.parentId}
	 */
	public String updateLoanType() {
		loanTypeService.update(loanType);
		return "goList_success";
	}
	
	/**
	 * ����ĳ����
	 * return	LoanTypeAction.action?loanType.parentId=${loanType.parentId}
	 */
	public String startUpOrShutDown() {
		if(ids.size() == 0) {
			return "goList_success";
		}
		List<Object> param = new ArrayList<Object>();
		param.add(flag);
		String setStatement = "o." + filed + " = ?1";
		StringBuilder sb = new StringBuilder(50);
		sb.append("o.loanTypeId in (");
		for (int i = 0; i < ids.size(); i++) {
			sb.append("?").append(i+2).append(",");
			param.add(ids.get(i));
		}
		sb.deleteCharAt(sb.length() - 1);
		sb.append(")");
		loanTypeService.update(setStatement, sb.toString(), param);
		return "goList_success";
	}
	
	
	public LoanType getLoanType() {
		return loanType;
	}

	public void setLoanType(LoanType loanType) {
		this.loanType = loanType;
	}

	public String getFiled() {
		return filed;
	}

	public void setFiled(String filed) {
		this.filed = filed;
	}

	public List<Integer> getIds() {
		return ids;
	}

	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}

	public Boolean getFlag() {
		return flag;
	}
	public void setFlag(Boolean flag) {
		this.flag = flag;
	}
	
}
