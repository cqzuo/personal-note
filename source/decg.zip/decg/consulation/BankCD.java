/**
		* �ļ�����BankCD.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-24
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.consulation;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.decg.base.common.Choose;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�BankCD
 * ��������
 * �����ˣ�������
 * ����ʱ�䣺2011-3-24 ����10:06:10
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-24 ����10:06:10
 * �޸ı�ע��
 * @version
 *
 */

@Entity
@Table(name = "BankCD")
public class BankCD implements Serializable{
	private static final long serialVersionUID = 8121167183782783705L;
	
	/**
	 * id
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id = null;
	
	/**
	 * ID
	 * @Column(length = 10, nullable = false, unique = true)
	 */
	@Column(length = 32, nullable = false)
	private String consCD = null;
	
	/**
	 * �Ա�ֵ
	 * 
	 */
	@Column(length = 1, nullable = false)
	private String consValue = null;
	
	/**
	 * ����
	 * @Column(length = 32, nullable = false, unique = true)
	 */
	@Column(length = 32, nullable = false, unique = true)
	private String name = null;
	
	/**
	 * ��ע
	 */
	@Column(length=255)
	private String demo;
	
	@Column(length = 3, nullable = true, updatable = false)
	@Enumerated(EnumType.STRING)
	 private Choose visiable = Choose.YES;
	/**
	 * ��ע
	 */
	public String getDemo() {
		return demo;
	}

	/**
	 * ��ע
	 */
	public void setDemo(String demo) {
		this.demo = demo;
	}

	/**
	 * ����
	 * @Id
	 * @Column(length = 32, nullable = false, unique = true)
	 */
	public String getName() {
		return name;
	}

	/**
	 * ����
	 * @Id
	 * @Column(length = 32, nullable = false, unique = true)
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * ID
	 * @Id
	 * @Column(length = 10, nullable = false, unique = true)
	 */
	public String getConsCD() {
		return consCD;
	}

	/**
	 * ID
	 * @Id
	 * @Column(length = 10, nullable = false, unique = true)
	 */
	public void setConsCD(String consCD) {
		this.consCD = consCD;
	}

	/**
	 * �Ա�ֵ
	 * 
	 */
	public String getConsValue() {
		return consValue;
	}

	/**
	 * �Ա�ֵ
	 * 
	 */
	public void setConsValue(String consValue) {
		this.consValue = consValue;
	}


	/**
	 * visiable
	 *
	 * @return the visiable
	 */
	
	public Choose getVisiable() {
		return visiable;
	}

	/**
	 * @param visiable the visiable to set
	 */
	public void setVisiable(Choose visiable) {
		this.visiable = visiable;
	}

	/**
	 * id
	 *
	 * @return the id
	 */
	
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/*
			(non-Javadoc)
			* @see java.lang.Object#hashCode()
			*/
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/*
			(non-Javadoc)
			* @see java.lang.Object#equals(java.lang.Object)
			*/
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankCD other = (BankCD) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	
}
