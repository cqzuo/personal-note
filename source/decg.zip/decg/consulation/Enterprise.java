package com.decg.consulation;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.decg.base.common.annotation.Ignore;

/**
 * ��ҵ��Ϣʵ��
 */
@Entity
@Table(name = "Enterprise")
public class Enterprise implements Serializable {
	@Ignore
	private static final long serialVersionUID = 2408984761217775963L;
	/** id **/
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	/** ��ҵ��� **/
	@Column(length = 10)
	private String enterpriseNo;
	/** ��ҵȫ�� **/
	@Column(length = 60)
	private String name;
	/** ������ҵ����id **/
	private Integer enterpriseType_id;
	/** ������ҵ������� **/
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
	@JoinColumn(name = "enterpriseType_id", insertable = false, updatable = false)
	private EnterpriseCD enterpriseType;
	
	/** ע������id **/
	private Integer registType_id;
	/** ע��������� **/
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
	@JoinColumn(name = "registType_id", insertable = false, updatable = false)
	private EnterpriseCD registType;
	
	/** ע���ַ **/
	@Column
	private String registAddress;
	/** ע��ʱ�� **/
	@Column(length = 20)
	private String registTime;
	/** �������� **/
	@Column
	private String legalPersonName;
	/** ��ϵ�� **/
	@Column
	private String contacterName;
	/** ��ϵ�绰 **/
	@Column
	private String contactPhone;
	/** ע���ʱ� **/
	@Column
	private Double registrationCapital;

	/** id **/
	public Integer getId() {
		return id;
	}

	/** id **/
	public void setId(Integer id) {
		this.id = id;
	}

	/** ��ҵ��� **/
	public String getEnterpriseNo() {
		return enterpriseNo;
	}

	/** ��ҵ��� **/
	public void setEnterpriseNo(String enterpriseNo) {
		this.enterpriseNo = enterpriseNo;
	}

	/** ��ҵȫ�� **/
	public String getName() {
		return name;
	}

	/** ��ҵȫ�� **/
	public void setName(String name) {
		this.name = name;
	}

	/** ע���ַ **/
	public String getRegistAddress() {
		return registAddress;
	}

	/** ע���ַ **/
	public void setRegistAddress(String registAddress) {
		this.registAddress = registAddress;
	}

	/** ע��ʱ�� **/
	public String getRegistTime() {
		return registTime;
	}

	/** ע��ʱ�� **/
	public void setRegistTime(String registTime) {
		this.registTime = registTime;
	}

	/** �������� **/
	public String getLegalPersonName() {
		return legalPersonName;
	}

	/** �������� **/
	public void setLegalPersonName(String legalPersonName) {
		this.legalPersonName = legalPersonName;
	}

	/** ��ϵ�� **/
	public String getContacterName() {
		return contacterName;
	}

	/** ��ϵ�� **/
	public void setContacterName(String contacterName) {
		this.contacterName = contacterName;
	}

	/** ��ϵ�绰 **/
	public String getContactPhone() {
		return contactPhone;
	}

	/** ��ϵ�绰 **/
	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	/** ע���ʱ� **/
	public Double getRegistrationCapital() {
		return registrationCapital;
	}

	/** ע���ʱ� **/
	public void setRegistrationCapital(Double registrationCapital) {
		this.registrationCapital = registrationCapital;
	}
	
	/** ������ҵ����id **/
	public Integer getEnterpriseType_id() {
		return enterpriseType_id;
	}

	/** ������ҵ����id **/
	public void setEnterpriseType_id(Integer enterpriseType_id) {
		this.enterpriseType_id = enterpriseType_id;
	}

	/** ������ҵ������� **/
	public EnterpriseCD getEnterpriseType() {
		return enterpriseType;
	}

	/** ������ҵ������� **/
	public void setEnterpriseType(EnterpriseCD enterpriseType) {
		this.enterpriseType = enterpriseType;
	}

	/** ע������id **/
	public Integer getRegistType_id() {
		return registType_id;
	}

	/** ע������id **/
	public void setRegistType_id(Integer registType_id) {
		this.registType_id = registType_id;
	}

	/** ע��������� **/
	public EnterpriseCD getRegistType() {
		return registType;
	}

	/** ע��������� **/
	public void setRegistType(EnterpriseCD registType) {
		this.registType = registType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Enterprise other = (Enterprise) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
