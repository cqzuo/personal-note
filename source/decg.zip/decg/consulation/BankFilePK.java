/**
		* �ļ�����BankFilePK.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-24
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.consulation;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�BankFilePK
 * ��������
 * �����ˣ�������
 * ����ʱ�䣺2011-3-24 ����02:35:07
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-24 ����02:35:07
 * �޸ı�ע��
 * @version
 *
 */

@Embeddable
public class BankFilePK implements Serializable {
	private static final long serialVersionUID = -6719632090396622450L;
	/**
	 * ����ID
	 * @Column(length = 11)
	 */
	@Column(length = 11)
	private String bank_id = null;
	/**
	 * �ļ����
	 * @Column(length = 3)
	 */
	@Column(length = 3)
	private Integer file_id = null;
	
	
	
	public BankFilePK() {
	}
	
	public BankFilePK(String bank_id, Integer file_id) {
		this.bank_id = bank_id;
		this.file_id = file_id;
	}



	/**
	 * ����ID
	 * @Column(length = 11)
	 */
	public String getBank_id() {
		return bank_id;
	}

	/**
	 * ����ID
	 * @Column(length = 11)
	 */
	public void setBank_id(String bank_id) {
		this.bank_id = bank_id;
	}

	/**
	 * �ļ����
	 * @Column(length = 3)
	 */
	public Integer getFile_id() {
		return file_id;
	}
	/**
	 * �ļ����
	 */
	public void setFile_id(Integer file_id) {
		this.file_id = file_id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bank_id == null) ? 0 : bank_id.hashCode());
		result = prime * result + ((file_id == null) ? 0 : file_id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankFilePK other = (BankFilePK) obj;
		if (bank_id == null) {
			if (other.bank_id != null)
				return false;
		} else if (!bank_id.equals(other.bank_id))
			return false;
		if (file_id == null) {
			if (other.file_id != null)
				return false;
		} else if (!file_id.equals(other.file_id))
			return false;
		return true;
	}
	
}
