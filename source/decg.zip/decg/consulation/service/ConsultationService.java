package com.decg.consulation.service;

import com.decg.base.DAO;
import com.decg.consulation.view.ProjectView;

public interface ConsultationService extends DAO<ProjectView> {
}
