package com.decg.consulation.service;

import com.decg.base.DAO;
import com.decg.consulation.Source;

/**
 *	��Ŀ��Դ�߼��ӿ�
 */
public interface SourceService extends DAO<Source>{
}
