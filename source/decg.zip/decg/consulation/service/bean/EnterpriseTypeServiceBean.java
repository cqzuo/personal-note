package com.decg.consulation.service.bean;

import org.springframework.stereotype.Service;

import com.decg.base.DaoSupport;
import com.decg.consulation.EnterpriseType;
import com.decg.consulation.service.EnterpriseTypeService;

@Service
public class EnterpriseTypeServiceBean extends DaoSupport<EnterpriseType> implements
		EnterpriseTypeService {

}
