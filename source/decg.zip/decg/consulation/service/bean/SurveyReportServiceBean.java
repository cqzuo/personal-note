/**
		* �ļ�����SurveyReportServiceBean.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-5-17
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.consulation.service.bean;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.base.DaoSupport;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.DynamicUpdate;
import com.decg.base.common.util.ViewToObjectService;
import com.decg.consulation.Project;
import com.decg.consulation.Suggestion;
import com.decg.consulation.service.SurveyReportService;
import com.decg.consulation.view.ProjectView;
import com.decg.step.Step;
import com.decg.step.service.FlowsStepsService;
import com.decg.task.Task;
import com.decg.user.User;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�SurveyReportServiceBean
 * ����������Ŀ���鱨��ӿ�ʵ����
 * �����ˣ�������
 * ����ʱ�䣺2011-5-17 ����03:24:01
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-5-17 ����03:24:01
 * �޸ı�ע��
 * @version
 *
 */
@SuppressWarnings("rawtypes")
@Service
public class SurveyReportServiceBean extends DaoSupport implements SurveyReportService {

	@Resource(name = "viewToObjectServiceBean")
	private ViewToObjectService viewToObjectService;
	@Resource(name = "dynamicUpdateImpl")
	private DynamicUpdate dynamicUpdate;
	@Resource(name = "flowsStepsServiceBean")
	private FlowsStepsService flowsStepsService;
	
	/*
			(non-Javadoc)
	 * @see com.decg.consulation.service.SurveyReportService#getSurveyReportViewByProjectNo(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public List<Object> getSurveyReportViewByProjectNo(String projectNo) {
		StringBuilder sb = new StringBuilder(500);
		sb.append(" select task, project, enterprise, suggestion, aRole, bRole ");
		sb.append(" from Project project, Task task, Enterprise enterprise, User aRole, User bRole, Suggestion suggestion ");
		sb.append(" where task.project_id = project.id ");
		sb.append("       and enterprise.id = project.enterprise_id ");
		sb.append("       and project.projectARoleId = aRole.userId ");
		sb.append("       and project.projectBRoleId = bRole.userId ");
		sb.append("       and project.id = suggestion.project_id ");
		sb.append("       and project.projectNo = ?1 ");
		String jpql = sb.toString();
		Query query = em.createQuery(jpql);
		query.setParameter(1, projectNo);
		List<Object> resultList = query.getResultList();
		resultList.add(jpql);
		return resultList;
	}

	//A��ɫ�ύ
	@Transactional
	public void submit(ProjectView projectView, Suggestion suggestion, User user) {
		Map<String, Object> objMap = viewToObjectService.parse(projectView);
		Project project = (Project) objMap.get(Project.class.getName());
		dynamicUpdate.update(project);
		suggestion.setAroleDateTime(new Date());
		dynamicUpdate.update(suggestion);
		
		Task task = em.find(Task.class, projectView.getTask_id());
		Step nextStep = flowsStepsService.nextStep(projectView.getFlow_id(), task.getStep_id());
		task.setContent("��Ŀ[" + projectView.getEnterpriseName() + "]A��ɫ���鱨����д��ɣ�����" + nextStep.getStepName());
		task.setFromWho(user.getRealName());
		String surveyBReportURL = DECG_cons.SurveyBReportURL.replace("#1", projectView.getProjectNo());
		task.setProcessURL(surveyBReportURL);
		task.setStep_id(nextStep.getStepId());
		task.setSubmitTime(new Date());
	}

	//B��ɫ�ύ
	@Transactional
	public void broleSubmit(ProjectView projectView, Suggestion suggestion, User user) {
		suggestion.setBroleDateTime(new Date());
		dynamicUpdate.update(suggestion);
		
		Task task = em.find(Task.class, projectView.getTask_id());
		Step nextStep = flowsStepsService.nextStep(projectView.getFlow_id(), task.getStep_id());
		task.setContent("��Ŀ[" + projectView.getEnterpriseName() + "]B��ɫ���鱨����д��ɣ�����" + nextStep.getStepName());
		task.setFromWho(user.getRealName());
		String surveyDepartManagerURL = DECG_cons.SurveyDepartManagerURL.replace("#1", projectView.getProjectNo());
		task.setProcessURL(surveyDepartManagerURL);
		task.setStep_id(nextStep.getStepId());
		task.setSubmitTime(new Date());
	}

}
