/**
		* �ļ�����LeaderCheckService.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-5-19
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.consulation.service.bean;

import java.util.Date;
import java.util.UUID;

import javax.annotation.Resource;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.base.DaoSupport;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.DynamicUpdate;
import com.decg.base.common.StepEnum;
import com.decg.consulation.Suggestion;
import com.decg.consulation.service.ReviewAndLawerCheckService;
import com.decg.consulation.view.ProjectView;
import com.decg.step.Step;
import com.decg.step.service.FlowsStepsService;
import com.decg.task.Task;
import com.decg.user.User;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�ReviewAndLawerCheckServiceBean
 * ������������������ύ�ӿ�ʵ����
 * �����ˣ�������
 * ����ʱ�䣺2011-5-19 ����02:01:48
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-5-19 ����02:01:48
 * �޸ı�ע��
 * @version
 *
 */

@Service
public class ReviewAndLawerCheckServiceBean extends DaoSupport<ProjectView>implements
ReviewAndLawerCheckService {
	@Resource(name = "dynamicUpdateImpl")
	private DynamicUpdate dynamicUpdate;
	@Resource(name = "flowsStepsServiceBean")
	private FlowsStepsService flowsStepsService;
	
	@Transactional
	public void submit(ProjectView projectView, Suggestion suggestion,
			User user) {
		if(user.getUserId().equals(projectView.getReviewId())){
			updateReviewSuggestion(suggestion);
		}else if(user.getUserId().equals(projectView.getLawerId())){
			updateLawerSuggestion(suggestion);
		}
		String status = this.processorStatus(projectView.getRelation_id(),projectView.getStep_id());
		if(status.equals("isLast")){
			Task task = em.find(Task.class, projectView.getTask_id());
			Step nextStep = flowsStepsService.nextStep(projectView.getFlow_id(), task.getStep_id());
			task.setContent("��Ŀ[" + projectView.getProjectNo() + " " + projectView.getEnterpriseName() + "]�ķ���/���������ɣ���������" + nextStep.getStepName());
			task.setFromWho(user.getRealName());
			String leaderCheckAction = DECG_cons.WindControlManagerCheckAction.replace("#1", projectView.getProjectNo());
			task.setProcessURL(leaderCheckAction);
			task.setSubmitTime(new Date());
			task.setStep_id(nextStep.getStepId());
			//����Ա��Ϣ��д���뵽���˴�����Manyprocesser��
			addManyProecessor(projectView.getProjectNo(),StepEnum.fwfssh.getValue(),projectView.getReviewId());
			addManyProecessor(projectView.getProjectNo(),StepEnum.join.getValue(),projectView.getReviewId());
			addManyProecessor(projectView.getProjectNo(),StepEnum.fwfssh.getValue(),projectView.getLawerId());
			addManyProecessor(projectView.getProjectNo(),StepEnum.join.getValue(),projectView.getLawerId());
		}else if(status.equals("isFirst")){
			Task task = em.find(Task.class, projectView.getTask_id());
			Step nextStep = flowsStepsService.nextStep(projectView.getFlow_id(), task.getStep_id());
			task.setSubmitTime(new Date());
			task.setStep_id(nextStep.getStepId());
			deleteManyProcessor(projectView,user);
		}else{
			deleteManyProcessor(projectView,user);
		}
	}
	
	/**
	 * �Ӷ��˴�������ɾ��������Ϣ
	 */
	private void deleteManyProcessor(ProjectView projectView,User user){
		String sql  ="delete from ManyProcesser o  where o.relationId =?1 and o.userId=?2";
		Query query = em.createQuery(sql);
		query.setParameter(1, projectView.getProjectNo());
		query.setParameter(2,user.getUserId() );
		query.executeUpdate();
	}
	
	/**
	 * �����˴������еĴ�����Ϣ��д����
	 */
	private void addManyProecessor(String  relationId,String stepId,String userId){
		String sql  ="insert into  Manyprocesser(StepsProcessers_id,relationId,stepId,userId) values(?1,?2,?3,?4)";
		Query query = em.createQuery(sql);
		query.setParameter(1, UUID.randomUUID().toString());
		query.setParameter(2, relationId);
		query.setParameter(3, stepId);
		query.setParameter(4, userId);
		query.executeUpdate();
	}
	
	/**
	 * �ڶ����������Ƿ��һ������,�Ƿ����һ������
	 */
	private String processorStatus(String relationId, String stepId) {
		Query query = em.createQuery(" select count(sp) from StepsProcessers sp where sp.relationId = ?1 and sp.stepId = ?2 ");
		query.setParameter(1, relationId);
		query.setParameter(2, stepId);
		//������������Ĵ���������
		Long countNumber = (Long) query.getSingleResult();
		
		Query qr = em.createQuery(" select count(sp) from StepsProcessers sp where sp.relationId = ?1 and sp.stepId = ?2 ");
		qr.setParameter(1, relationId);
		qr.setParameter(2, StepEnum.join.getValue());
		Long result = (Long) qr.getSingleResult();
		if(result == 1) {
			return  "isLast";
		} else if(countNumber.equals(result)) {
			return "isFirst";
		}
		return null;
	}
	
	public Boolean isReviewSubmit(Integer projectId)
	{
		Boolean flag = false;
		Query query = em.createQuery(" select count(s) from Suggestion s where s.reviewDateTime is not null and s.project_id=?1 ");
		query.setParameter(1, projectId);
		Long countNumber = (Long) query.getSingleResult();
		if(countNumber>0){
			flag = true;
		}
		return flag;
	}
	public Boolean isLawerSubmit(Integer projectId){
		Boolean flag = false;
		Query query = em.createQuery(" select count(s) from Suggestion s where s.lawerDateTime is not null and s.project_id=?1 ");
		query.setParameter(1, projectId);
		Long countNumber = (Long) query.getSingleResult();
		if(countNumber>0){
			flag = true;
		}
		return flag;
	}
	
	private void updateReviewSuggestion(Suggestion suggestion){
		suggestion.setReviewDateTime(new Date());
		dynamicUpdate.update(suggestion);
	}
	
	private void updateLawerSuggestion(Suggestion suggestion){
		suggestion.setLawerDateTime(new Date());
		dynamicUpdate.update(suggestion);
	}
}
