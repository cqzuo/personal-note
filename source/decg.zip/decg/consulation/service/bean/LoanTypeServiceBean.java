/**
		* �ļ�����LoanTypeServiceBean.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-23
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.consulation.service.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.base.DaoSupport;
import com.decg.base.common.Choose;
import com.decg.consulation.LoanType;
import com.decg.consulation.service.LoanTypeService;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�LoanTypeServiceBean
 * ���������������ͽӿ�ʵ����
 * �����ˣ�������
 * ����ʱ�䣺2011-3-23 ����04:42:36
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-23 ����04:42:36
 * �޸ı�ע��
 * @version
 *
 */

@Service
public class LoanTypeServiceBean extends DaoSupport<LoanType> implements
		LoanTypeService {

	@Override
	@Transactional
	public void delete(String whereStatement, Serializable entityId) {
		Query query = em.createQuery(" update LoanType o set o.visible = 'NO' " + ((whereStatement == null) ? "" : (" where " + whereStatement)));
		query.setParameter(1, entityId);
		query.executeUpdate();
	}

	@SuppressWarnings("unchecked")
	public LoanType getLoanTypeById(String id){
		LoanType loanType = new LoanType();
		String sql = "select o from LoanType o where o.loanTypeId=?1";
		Query query = em.createQuery(sql);
		query.setParameter(1, id);
		List<Object> loanTypes = query.getResultList();
		if(loanTypes.size()>0){
			loanType = (LoanType)loanTypes.get(0);
		}
		return loanType;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getLoanTypeViews(String parentId) {
		List<Object> whereParam = new ArrayList<Object>();
		StringBuilder sb = new StringBuilder(100);
		sb.append(" select loanType, surveyReportType ");
		sb.append(" from LoanType loanType "); 
		sb.append(" left join loanType.surveyReportType surveyReportType ");
		sb.append(" where ");
		if("".equals(parentId) || parentId == null) {
			sb.append(" (loanType.parentId is null or loanType.parentId = '') and loanType.visible = '");
			sb.append(Choose.YES);
			sb.append("' ");
		} else {
			sb.append(" loanType.parentId = ?1 and loanType.visible = '");
			sb.append(Choose.YES);
			sb.append("' ");
			whereParam.add(parentId);
		}
		sb.append(" order by loanType.loanTypeId asc ");
		String jpql = sb.toString();
		Query qr = em.createQuery(jpql);
		if(whereParam.size() > 0) {
			for(int i=0; i<whereParam.size(); i++) {
				qr.setParameter(i+1, whereParam.get(i));
			}
		}
		List<Object> resultList = qr.getResultList();
		resultList.add(jpql);
		return resultList;
	}
}
