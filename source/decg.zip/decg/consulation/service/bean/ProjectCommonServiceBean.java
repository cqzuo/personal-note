package com.decg.consulation.service.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.base.DaoSupport;
import com.decg.base.common.StepEnum;
import com.decg.consulation.service.ProjectCommonService;
import com.decg.consulation.service.ProjectService;
import com.decg.consulation.view.ProjectView;

/**
 * 
		*
		* ��Ŀ���ƣ�decgnew
		* �����ƣ�ProjectCommonServiceBean
		* ����������������ͨ�ýӿ�ʵ����
		* �����ˣ�Administrator
		* ����ʱ�䣺2011-5-20 ����08:50:49
		* �޸��ˣ�Administrator
		* �޸�ʱ�䣺2011-5-20 ����08:50:49
		* �޸ı�ע��
		* @version
		*
 */
@Service
public class ProjectCommonServiceBean extends DaoSupport<ProjectView> implements ProjectCommonService {
	
	@Resource(name = "projectServiceBean")
	private ProjectService projectService;
	
	private final String sql = "" +
			" select task, project, enterprise, organization, user, loanType, loanTypeChildren, bank1," +
			" bank1Children, bank2, bank2Children, flow, source, relation, enterpriseType, registType, " +
			" aRole, bRole, review, lawer, step " +
			" from Project project  " +
			" left join project.enterprise enterprise  " +
			" left join project.organization organization  " +
			" left join project.user user  " +
			" left join project.loanType loanType  " +
			" left join project.loanTypeChildren loanTypeChildren  " +
			" left join project.bank1 bank1  " +
			" left join project.bank1Children bank1Children " +
			" left join project.bank2 bank2  " +
			" left join project.bank2Children bank2Children  " +
			" left join project.flow flow  " +
			" left join project.source source  " +
			" left join project.relation relation  " +
			" left join enterprise.enterpriseType enterpriseType  " +
			" left join enterprise.registType registType " + 
			" left join project.tasks task, " + 
			" StepsProcessers s, " +
			" User aRole, User bRole, User review, User lawer, Step step " + 
			" where task.step_id = s.stepId " +
			" and relation.projectManagerId = s.relationId " +
			" and (s.taskId = task.id or s.taskId is null) " +
			" and task.project_id = project.id  " +
			" and project.projectARoleId = aRole.userId " +
			" and project.projectBRoleId = bRole.userId " +
			" and relation.reviewId = review.userId " +
			" and relation.lawerId = lawer.userId " +
			" and task.step_id = step.stepId  ";
	
	@SuppressWarnings("unchecked")
	public List<Object> queryByConditions(Map<String, Object> map){
		List<String> keys = new ArrayList<String>();
		List<Object> values = new ArrayList<Object>();
		for(String key :map.keySet()) {
			keys.add(key);
		};
		StringBuilder sb = new StringBuilder(sql);
		int j = 1;
		for(int i=0; i<keys.size(); i++) {
			try {
				String key = keys.get(i);
				Object value = map.get(key);
				if(value != null && (!"".equals(value))){
					values.add(value);
					String sign = " = ";
					if(("project.confirmationDate".equals(key))||("project.id".equals(key))) {
						sign = " >= ";
					}
					if("project.confirmationDate".equals(key)) {
						sign = " <= ";
					}
					if(("enterprise.name".equals(key))||("project.id".equals(key))) {
						sign = " like ";
						values.remove(value);
						values.add("%"+value+"%");
					}
					sb.append(" and ").append(key).append(sign).append("?").append(j++);
				}
				
			} catch(Exception e) {
				throw new RuntimeException("������..");
			}
		}
		
		Query query =  em.createQuery(sb.toString());
		
		setWhereParam(query, values);
		List<Object> objs = query.getResultList();
		objs.add(sb.toString());
		return objs;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getProjectCommons(String userId, String stepId,
			Integer flowId) {
		StringBuilder sb = new StringBuilder(sql);
		
		//��������start
		if(userId != null && !"".equals(userId)) {
			sb.append(" and s.userId =?1 ");
		}
		if(stepId != null && !"".equals(stepId)) {
			sb.append(" and (task.step_id = ?2 or task.step_id = ?4) ");
		}
		if(flowId != null && !"".equals(flowId)) {
			sb.append(" and project.flow_id = ?3 ");
		}
		//��������end
		sb.append(" order by project.id asc ");
		String jpql = sb.toString();
		Query qr = em.createQuery(jpql);
		
		if(userId != null && !"".equals(userId)) {
			qr.setParameter(1, userId);
		}
		if(stepId != null && !"".equals(stepId)) {
			qr.setParameter(2, stepId);
			qr.setParameter(4, StepEnum.join.getValue());
		}
		if(flowId != null && !"".equals(flowId)) {
			qr.setParameter(3, flowId);
		}
		
		List<Object> list = qr.getResultList();
		list.add(jpql);
		return list;
	}
	

	@Transactional
	public void saveABReplace(ProjectView projectView){
		//������Ŀ��¼�е�A B��ɫ
		String setStatement = " o.projectARoleId=?1 , o.projectBRoleId=?2 ";
		String whereStatement = " o.projectNo=?3 ";
		List<Object> param = new ArrayList<Object>();
		param.add(projectView.getProjectARoleId());
		param.add(projectView.getProjectBRoleId());
		param.add(projectView.getProjectNo());
		this.projectService.update(setStatement, whereStatement, param);
	}
	
	public Map<String, Object> getReviewAndLawer(String projectNo){
		
		String sql  = "select r.reviewId ,r.lawerId from Relation r ,Project p where p.relation_id = r.projectManagerId and p.projectNo =?1";
		Query query = em.createQuery(sql);
		query.setParameter(1, projectNo);
		Object[] o = (Object[]) query.getResultList().get(0);
		Map<String, Object> reviewAndLawerIds = new HashMap<String, Object>();
		reviewAndLawerIds.put("review",o[0]);
		reviewAndLawerIds.put("lawer",o[1]);
		return reviewAndLawerIds;
	}

}
