package com.decg.consulation.service.bean;

import org.springframework.stereotype.Service;

import com.decg.base.DaoSupport;
import com.decg.consulation.service.ConsultationService;
import com.decg.consulation.view.ProjectView;

@Service
public class ConsultationServiceBean extends DaoSupport<ProjectView> implements ConsultationService {
}
