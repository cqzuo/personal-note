package com.decg.consulation.service.bean;

import org.springframework.stereotype.Service;
import com.decg.base.DaoSupport;
import com.decg.consulation.Source;
import com.decg.consulation.service.SourceService;

@Service
public class SourceServiceBean extends DaoSupport<Source> implements SourceService {

}
