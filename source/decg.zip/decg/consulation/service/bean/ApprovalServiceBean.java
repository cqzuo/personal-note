package com.decg.consulation.service.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.base.DaoSupport;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.DynamicUpdate;
import com.decg.base.common.util.ViewToObjectService;
import com.decg.consulation.Enterprise;
import com.decg.consulation.Project;
import com.decg.consulation.Suggestion;
import com.decg.consulation.service.ApprovalService;
import com.decg.consulation.view.ProjectView;
import com.decg.projectnostrategy.service.ProjectNoStrategyService;
import com.decg.relation.DynamicProcesser;
import com.decg.step.Step;
import com.decg.step.service.FlowsStepsService;
import com.decg.task.Task;
import com.decg.user.User;
/**
 * 
		*
		* ��Ŀ���ƣ�decgnew
		* �����ƣ�ApprovalServiceBean
		* �������������׼�ӿ�ʵ����
		* �����ˣ�Administrator
		* ����ʱ�䣺2011-5-20 ����08:49:39
		* �޸��ˣ�Administrator
		* �޸�ʱ�䣺2011-5-20 ����08:49:39
		* �޸ı�ע��
		* @version
		*
 */
@Service
public class ApprovalServiceBean extends DaoSupport<ProjectView> implements ApprovalService {
	
	@Resource(name="viewToObjectServiceBean")
	private ViewToObjectService viewToObjectService;
	@Resource(name="projectNoStrategyServiceBean")
	private ProjectNoStrategyService projectNoStrategyService;
	
	private final String sql = "" +
							"select task, project, enterprise, organization, user, loanType, loanTypeChildren, bank1," +
							"bank1Children, bank2, bank2Children, flow, source, relation, enterpriseType, registType " +
							"from Project project  " +
							"left join project.enterprise enterprise  " +
							"left join project.organization organization  " +
							"left join project.user user  " +
							"left join project.loanType loanType  " +
							"left join project.loanTypeChildren loanTypeChildren  " +
							"left join project.bank1 bank1  " +
							"left join project.bank1Children bank1Children " +
							"left join project.bank2 bank2  " +
							"left join project.bank2Children bank2Children  " +
							"left join project.flow flow  " +
							"left join project.source source  " +
							"left join project.source source  join project.relation relation  " +
							"left join enterprise.enterpriseType enterpriseType  " +
							"left join enterprise.registType registType ";

	@Resource(name = "dynamicUpdateImpl")
	private DynamicUpdate dynamicUpdate;
	@Resource(name = "flowsStepsServiceBean")
	private FlowsStepsService flowsStepsService;
	
	@SuppressWarnings("unchecked")
	public List<Object> getApprovals(User user,String stepId) {
		StringBuilder sb = new StringBuilder(sql);
		sb.append("left join project.tasks task, ");
		sb.append("StepsProcessers s ");
		//��������start
		sb.append(" where ");
		sb.append(" task.step_id = s.stepId ");
		sb.append(" and s.relationId = project.relation_id ");
		sb.append(" and task.project_id = project.id ");
		sb.append(" and s.userId =?1 ");
		sb.append(" and task.step_id = ?2 ");
		//��������end
		sb.append(" order by project.id asc ");
		String jpql = sb.toString();
		Query qr = em.createQuery(jpql);
		qr.setParameter(1, user.getUserId());
		qr.setParameter(2, stepId);
		List<Object> list = qr.getResultList();
		list.add(jpql);
		return list;
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> queryByConditions(Map<String, Object> map){
		List<String> keys = new ArrayList<String>();
		List<Object> values = new ArrayList<Object>();
		for(String key :map.keySet()) {
			keys.add(key);
		};
		StringBuilder sb = new StringBuilder(sql);
		sb.append(" where 1 = 1 ");
		int j = 1;
		for(int i=0; i<keys.size(); i++) {
			try {
				String key = keys.get(i);
				Object value = map.get(key);
				if(value != null && (!"".equals(value))){
					values.add(value);
					String sign = " = ";
					if("project.confirmationDate".equals(key)) {
						sign = " >= ";
					}
					if("project.confirmationDate".equals(key)) {
						sign = " <= ";
					}
					if("enterprise.name".equals(key)) {
						sign = " like ";
						values.remove(value);
						values.add("%"+value+"%");
					}
					sb.append(" and ").append(key).append(sign).append("?").append(j++);
				}
				
			} catch(Exception e) {
				throw new RuntimeException("������..");
			}
		}
		
		Query query =  em.createQuery(sb.toString());
		
		setWhereParam(query, values);
		List<Object> objs = query.getResultList();
		objs.add(sb.toString());
		return objs;
	}
	
	@Transactional
	public void submit(ProjectView projectView, Suggestion suggestion,User u) {
		
		Map<String,Object> objMap = viewToObjectService.parse(projectView);
		Project project = (Project) objMap.get(DECG_cons.project);
		Enterprise enterprise = (Enterprise) objMap.get(DECG_cons.enterprise);
		project.setConfirmationDate(new Date());
		project.setProjectARoleId(projectView.getProjectARoleId());
		project.setProjectBRoleId(projectView.getProjectBRoleId());
		project.setStrategyId(projectNoStrategyService.getScrollData(null).getResultList().get(0).getId());
		project.setProjectNo(projectNoStrategyService.getProjectNumber(projectView.getOrgNo()));
		
		//��ȡ��Ӧ������
		Task task = em.find(Task.class, projectView.getTask_id());
		
		// ���ݵ�ǰ����,��ѯ�²���
		Step nextStep = flowsStepsService.nextStep(Integer.parseInt(DECG_cons.zcshlc), task.getStep_id());
		
		//�����������ݺ͸��������赽��һ��
		String content = "��Ŀ [" + enterprise.getName() + "] ������ɣ���������" + nextStep.getStepName();
		task.setContent(content);
		task.setStep_id(nextStep.getStepId());
		task.setFromWho(u.getRealName());
		task.setSubmitTime(new Date());
		String surveyAReportURL = DECG_cons.SurveyAReportURL.replace("#1", project.getProjectNo());
		task.setProcessURL(surveyAReportURL);
		
		//ָ��A,B��ɫ
		DynamicProcesser aRole = new DynamicProcesser();
		aRole.setStepsProcessers_id(UUID.randomUUID().toString().replace("-", ""));
		aRole.setRelationId(projectView.getRelation_id());
		aRole.setStepId(nextStep.getStepId());
		aRole.setUserId(projectView.getProjectARoleId());
		aRole.setTaskId(task.getId());
		
		//����A��ɫ
		em.persist(aRole);
		//������Ŀ����Ա��ϵidΪA��ɫ��Ӧ�Ĺ�ϵ
		project.setRelation_id(projectView.getProjectARoleId());
		
		//B��ɫ��Ӧ��Ҫ�����Ĳ���:A��ɫ�����Ĳ������һ��
		Step bStep = flowsStepsService.nextStep(Integer.parseInt(DECG_cons.zcshlc), nextStep.getStepId());
		DynamicProcesser bRole = new DynamicProcesser();
		bRole.setStepsProcessers_id(UUID.randomUUID().toString().replace("-", ""));
		bRole.setRelationId(projectView.getRelation_id());
		bRole.setStepId(bStep.getStepId());
		bRole.setUserId(projectView.getProjectBRoleId());
		bRole.setTaskId(task.getId());
		//����B��ɫ
		em.persist(bRole);
		
		//������ҵ ��Ŀ ��������Ϣ
		dynamicUpdate.update(project);
		dynamicUpdate.update(enterprise);
		
		suggestion.setDepartDateTime(new Date());
		dynamicUpdate.update(suggestion);
	}

}
