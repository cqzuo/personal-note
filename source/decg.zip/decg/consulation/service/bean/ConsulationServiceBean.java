package com.decg.consulation.service.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.base.DaoSupport;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.DynamicUpdate;
import com.decg.consulation.Enterprise;
import com.decg.consulation.Project;
import com.decg.consulation.Suggestion;
import com.decg.consulation.service.ConsulationService;
import com.decg.consulation.view.ProjectView;
import com.decg.step.Step;
import com.decg.step.service.FlowsStepsService;
import com.decg.task.Task;
import com.decg.user.User;
/**
 * 
		*
		* ��Ŀ���ƣ�decgnew
		* �����ƣ�ConsulationServiceBean
		* ����������ҵ��ѯ�ӿ�ʵ����
		* �����ˣ�Administrator
		* ����ʱ�䣺2011-5-20 ����08:50:12
		* �޸��ˣ�Administrator
		* �޸�ʱ�䣺2011-5-20 ����08:50:12
		* �޸ı�ע��
		* @version
		*
 */
@Service
public class ConsulationServiceBean extends DaoSupport<ProjectView> implements ConsulationService {

	@Resource(name = "dynamicUpdateImpl")
	private DynamicUpdate dynamicUpdate;
	@Resource(name = "flowsStepsServiceBean")
	private FlowsStepsService flowsStepsService;
	
	
	private final String sql = "" +
			"select task, project, enterprise, organization, user, loanType, loanTypeChildren, bank1," +
			"bank1Children, bank2, bank2Children, flow, source, relation, enterpriseType, registType " +
			"from Project project  " +
			"left join project.enterprise enterprise  " +
			"left join project.organization organization  " +
			"left join project.user user  " +
			"left join project.loanType loanType  " +
			"left join project.loanTypeChildren loanTypeChildren  " +
			"left join project.bank1 bank1  " +
			"left join project.bank1Children bank1Children " +
			"left join project.bank2 bank2  " +
			"left join project.bank2Children bank2Children  " +
			"left join project.flow flow  " +
			"left join project.source source  " +
			"left join project.source source  " +
			"join project.relation relation  " +
			"left join enterprise.enterpriseType enterpriseType  " +
			"left join enterprise.registType registType ";
	
	@SuppressWarnings("unchecked")
	public List<Object> getConsulations(User user,String stepId) {
		StringBuilder sb = new StringBuilder(sql);
		sb.append("left join project.tasks task");
		sb.append(" where ");
		sb.append(" project.accepter_id = ?1 ");
		sb.append(" and task is null ");
		//��������end
		sb.append(" order by project.id asc ");
		String jpql = sb.toString();
		Query qr = em.createQuery(jpql);
		qr.setParameter(1, user.getUserId());
		List<Object> list = qr.getResultList();
		list.add(jpql);
		return list;
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> queryByConditions(Map<String, Object> map){
		List<Object> objs = null;
		if(map != null && map.size() > 0) {
			List<String> keys = new ArrayList<String>();
			List<Object> values = new ArrayList<Object>();
			for(String key :map.keySet()) {
				keys.add(key);
			};
			StringBuilder sb = new StringBuilder(sql);
			sb.append("left join project.tasks task");
			sb.append(" where project.accepter_id = ?1 ");
			sb.append(" and task is null ");
			int j = 1;
			for(int i=0; i<keys.size(); i++) {
				try {
					String key = keys.get(i);
					Object value = map.get(key);
					if(value != null && (!"".equals(value))){
						values.add(value);
						String sign = " = ";
						if("project.confirmationDate".equals(key)) {
							sign = " >= ";
						}
						if("project.confirmationDate".equals(key)) {
							sign = " <= ";
						}
						if("enterprise.name".equals(key)) {
							sign = " like ";
							values.remove(value);
							values.add("%"+value+"%");
						}
						sb.append(" and ").append(key).append(sign).append("?").append(j++);
					}
					
				} catch(Exception e) {
					throw new RuntimeException("������..");
				}
			}
			
			Query query =  em.createQuery(sb.toString());
			
			setWhereParam(query, values);
			objs = query.getResultList();
			objs.add(sb.toString());
		}
		return objs;
	}

	@Transactional
	public void save(Enterprise enterprise, Project project, Suggestion suggestion) {
		//������ҵ��Ϣ
		em.persist(enterprise);
		//������ҵ��id����Ŀ��
		project.setEnterprise_id(enterprise.getId());
		//������Ŀ��Ϣ
		em.persist(project);
		//������Ŀid��������
		suggestion.setProject_id(project.getId());
		//����������
		em.persist(suggestion);
	}
	
	@Transactional
	public void submit(Project project, Enterprise enterprise,Suggestion suggestion,User u) {
		if(project.getId() == null || "".equals(project.getId())) {
			if(enterprise.getId() != null) {
				em.merge(enterprise);
			} else {
				em.persist(enterprise);
			}
			project.setEnterprise_id(enterprise.getId());
			em.persist(project);
			suggestion.setProject_id(project.getId());
			em.persist(suggestion);
		} else {
			em.merge(enterprise);
			project.setEnterprise_id(enterprise.getId());
			project.setFlow_id(Integer.parseInt(DECG_cons.zcshlc));
			em.merge(project);
			suggestion.setProject_id(project.getId());
			em.merge(suggestion);
		}
		
		//��ȡĬ�����̵�һ��
		Step step = flowsStepsService.firstStep(project.getFlow_id());
		step = flowsStepsService.nextStep(project.getFlow_id(), step.getStepId());
		//��������
		Task task = new Task();
		String content = "��Ŀ [" + enterprise.getName() + "] �ĵ��鱨����д��ɣ���������" + step.getStepName();
		task.setContent(content);
		task.setStep_id(step.getStepId());
		task.setProject_id(project.getId());
		task.setFromWho(u.getRealName());
		task.setSubmitTime(new Date());
		em.persist(task);
		String precessURL = DECG_cons.ApprovalProcessURL.replace("#1", project.getId().toString()).replace("#2", task.getId().toString());
		task.setProcessURL(precessURL);
	}
	
	
	@Transactional
	public void update(Project project, Enterprise enterprise,Suggestion suggestion){
		dynamicUpdate.update(project);
		dynamicUpdate.update(enterprise);
		dynamicUpdate.update(suggestion);
	}
	@SuppressWarnings("unchecked")
	public List<Object> getProjectViewById(Integer id){
		StringBuilder sb = new StringBuilder(100);
		sb.append(" select project, enterprise ");
		sb.append(" from Project project inner join  project.enterprise enterprise ");
		sb.append(" where project.id = ?1 ");
		
		String jpql = sb.toString();
		Query query = em.createQuery(jpql);
		query.setParameter(1, id);
		List<Object> list = query.getResultList();
		list.add(jpql);
		return list;
	}
	
	@SuppressWarnings("unchecked")
	public Suggestion getSuggestionByProject(Integer projectId){
		String sql ="select o from Suggestion o where o.project_id=?1";
		Query query = em.createQuery(sql);
		query.setParameter(1, projectId);
		List<Suggestion> suggestions = query.getResultList();
		return suggestions.get(0);
	}
	
	public String getAuditorId(Integer projectId){
		String sql = "SELECT s.userId FROM StepsProcessers s,Project p,Task t WHERE p.relation_id = s.relationId AND p.id = t.project_id AND t.step_id = s.stepId AND p.id = ?1";
		Query query = em.createQuery(sql);
		query.setParameter(1, projectId);
		String userId = (String)query.getSingleResult();
		return userId;
	}

	@SuppressWarnings("unchecked")
	public ProjectView getProjectViewByProjectNo(String projectNo){
		StringBuilder sb = new StringBuilder(sql);
		sb.append(" where ");
		sb.append(" project.projectNo=?1");
		Query query = em.createQuery(sb.toString());
		query.setParameter(1, projectNo);
		List<ProjectView> projectViews = query.getResultList();
		if(projectViews.size()>0){
			return projectViews.get(0);
		}else{
			System.out.println("δ��ѯ�����Ϊ"+projectNo+"����Ŀ��Ϣ!");
			return null;
		}
		
	}
}
