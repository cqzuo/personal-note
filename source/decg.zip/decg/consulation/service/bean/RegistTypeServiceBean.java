package com.decg.consulation.service.bean;

import org.springframework.stereotype.Service;
import com.decg.base.DaoSupport;
import com.decg.consulation.RegistType;
import com.decg.consulation.service.RegistTypeService;

/**
 *	ע������ҵ���߼��ӿڵ�ʵ��
 */
@Service
public class RegistTypeServiceBean extends DaoSupport<RegistType> implements
		RegistTypeService {

}
