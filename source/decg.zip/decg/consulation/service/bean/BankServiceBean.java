/**
		* �ļ�����BankServiceBean.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-24
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.consulation.service.bean;

import java.util.List;
import javax.persistence.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.decg.base.DaoSupport;
import com.decg.consulation.Bank;
import com.decg.consulation.BankFile;
import com.decg.consulation.service.BankService;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�BankServiceBean
 * ���������������ҵ���߼��ӿ�BankService��ʵ��
 * �����ˣ�������
 * ����ʱ�䣺2011-3-24 ����09:04:52
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-24 ����09:04:52
 * �޸ı�ע��
 * @version
 *
 */

@Service
public class BankServiceBean extends DaoSupport<Bank> implements BankService {
	
	public String getBankId(String parentId) {
		String id = "";
		//���ɶ�������id
		if(parentId == null || "".equals(parentId)) {
			String Jpql = "select o.bankId from Bank o where o.parentId is null or o.parentId = '' order by o.bankId desc";
			id = this.getId(Jpql, "01", true, parentId);
		} else {	//����������ID
			String Jpql = "select o.bankId from Bank o where o.parentId = ?1 order by o.bankId desc";
			id = this.getId(Jpql, "001", false, parentId);
		}
		return id;
	}
	
	
	/**
	 * ID���ɲ���.
	 * @param Jpql		�������
	 * @param firstId	���ݿ���û�м�¼ʱ���ɵĵ�һ����¼��IDֵ
	 * @param isParent	�Ƿ��Ƕ�������.trueΪ�Ƕ�������,falseΪ�Ƕ�������.���ݲ�ͬ�ļ�����в�ͬ��ID���ɲ���ƥ��
	 */
	@SuppressWarnings("unchecked")
	private String getId(String Jpql, String firstId, boolean isParent, String parentId) {
		String id = "";
		if(isParent) {
			Query query = em.createQuery(Jpql);
			query.setFirstResult(0);
			query.setMaxResults(1);
			List<String> ids = query.getResultList();
			if(ids.size() == 0) {
				id = firstId;
			} else {
				id = String.valueOf(Integer.parseInt(ids.get(0)) + 1);
				if(id.length()<2) {
					id = "0" + id;
				}
			}
		} else {
			if(parentId == null || "".endsWith(parentId)) {
				throw new RuntimeException("parentId is null!");
			}
			Query query = em.createQuery(Jpql);
			query.setParameter(1, parentId);
			query.setFirstResult(0);
			query.setMaxResults(1);
			List<String> ids = query.getResultList();
			if(ids.size() == 0) {
				id = parentId+firstId;
			} else {
				id = String.valueOf(Integer.parseInt(ids.get(0)) + 1);
				String bankId = ids.get(0);
				Integer bankIdLen = bankId.length();
				if(id.length() == bankIdLen-2) {
					id = "00" + id;
				} else if (id.length() == bankIdLen-1) {
					id = "0" + id;
				}
			}
		}
		return id;
	}

	@Transactional
	public void save(Bank bank, List<String> arrayChecks, List<String> businessTypes, List<String> fileTypes, List<String> fileNames) {
		em.persist(bank);
		for(int i=0;i<fileNames.size();i++) {
			if(!"".equals(fileNames.get(i).trim())){
				BankFile bf = new BankFile();
				bf.setBusinessTypeId(businessTypes.get(i));
				bf.setFileName(fileNames.get(i));
				bf.setFileTypeId(fileTypes.get(i));
				bf.setBankId(bank.getBankId());
				em.persist(bf);
			}
		}
	}

	@Transactional
	public void update(Bank bank, List<String> arrayChecks,
			List<String> businessTypes, List<String> fileTypes,
			List<String> fileNames) {
		em.merge(bank);
		Query query = em.createQuery("delete from BankFile o where o.bank_id = ?1");
		query.setParameter(1, bank.getBankId());
		query.executeUpdate();
		for(int i=0;i<fileNames.size();i++) {
			if(!"".equals(fileNames.get(i).trim())){
				BankFile bf = new BankFile();
				bf.setBusinessTypeId(businessTypes.get(i));
				bf.setFileName(fileNames.get(i));
				bf.setFileTypeId(fileTypes.get(i));
				bf.setBankId(bank.getBankId());
				em.persist(bf);
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	public Bank getBankById(String bankId){
		Bank bank = new Bank();
		String sql = "select o from Bank o where o.bankId=?1";
		Query query = em.createQuery(sql);
		query.setParameter(1, bankId);
		List<Object> banks = query.getResultList();
		if(banks.size()>0){
			bank = (Bank)banks.get(0);
		}
		return  bank;
	}
	
}
