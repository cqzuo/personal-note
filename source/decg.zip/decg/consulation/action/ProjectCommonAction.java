package com.decg.consulation.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.common.DECG_cons;
import com.decg.base.common.util.ObjectArrayToViewService;
import com.decg.consulation.Suggestion;
import com.decg.consulation.service.BankService;
import com.decg.consulation.service.ConsulationService;
import com.decg.consulation.service.EnterpriseCDService;
import com.decg.consulation.service.ProjectCommonService;
import com.decg.consulation.view.ProjectView;
import com.decg.consulation.view.QueryConditionView;
import com.decg.user.User;
import com.decg.user.service.OrganizationService;
import com.decg.user.service.UsersRolesService;
import com.opensymphony.xwork2.ActionContext;

@Controller
@Scope("prototype")
public class ProjectCommonAction {
	@Resource(name="projectCommonServiceBean")
	private ProjectCommonService projectCommonService;
	private Suggestion suggestion;
	@Resource(name = "enterpriseCDServiceBean")
	private EnterpriseCDService enterpriseCDService;
	@Resource(name="usersRolesServiceBean")
	private UsersRolesService usersRolesService;
	@Resource(name="organizationServiceBean")
	private OrganizationService organizationService;
	@Resource(name="bankServiceBean")
	private BankService bankService;
	@Resource(name="consulationServiceBean")
	private ConsulationService consulationService;
	@Resource(name="objectArrayToViewServiceBean")
	private ObjectArrayToViewService objectArrayToViewService;

	/** ��������view **/
	private QueryConditionView conditionView = new QueryConditionView();
	
	private ProjectView projectView = new ProjectView();
	/**
	 * ��ǰ���������
	 */
	private Integer stepIndex;
	/**
	 * stepIndex����������
	 */
	private String condition;
	
	
	 /**
     * ��ҵ��ѯ�ۺϼ���
     */
    public String search() {
    	Map<String,Object> map = new HashMap<String,Object>();
    	//����ģ����ѯ������
    	map.put("project.id", conditionView.getProjectId());
    	map.put("enterprise.name", conditionView.getEnterpriseName());
    	//���뾫ȷ��ѯ������
    	map.put("project.ARole", conditionView.getARole());
    	map.put("project.BRole", conditionView.getBRole());
    	map.put("bank1.bankId", conditionView.getBank());
    	map.put("bank2.bankId", conditionView.getBank());
    	map.put("organization.orgNo", conditionView.getOrg());
    	map.put("source.id", conditionView.getSource());
    	map.put("enterpriseType.id", conditionView.getIndustryType());
    	//������ʼ�Ĳ�ѯ����
    	map.put("project.confirmationDate", conditionView.getBeginDate());
    	map.put("project.confirmationDate", conditionView.getEndDate());
    	List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.xmajtj, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("projectSurveyList", polist);
    	ActionContext.getContext().put("projectViews", projectCommonService.queryByConditions(map));
    	ActionContext.getContext().put("projectManagerList", usersRolesService.findProjectManager());
		ActionContext.getContext().put("orgList", organizationService.getScrollData(null).getResultList());
		
		//��ҵ����
		String whereStatement = "o.consCD=?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(DECG_cons.INDUSTRYTYPE);
		ActionContext.getContext().put("industryTypes", enterpriseCDService.getScrollData(whereStatement, whereParam, null).getResultList());
		
		//��Ŀ��Դ
		String whereStatement1 = "o.consCD=?1";
		List<Object> whereParam1 = new ArrayList<Object>();
		whereParam1.add(DECG_cons.SOURCETYPE);
		ActionContext.getContext().put("sources", enterpriseCDService.getScrollData(whereStatement1, whereParam1, null).getResultList());
		
		//��������
		String whereStatement2 = "(o.parentId=null or o.parentId=0)";
		ActionContext.getContext().put("banks", bankService.getScrollData(whereStatement2, null, null).getResultList());
		
		//ҳ�淵������
		ActionContext.getContext().put("projectId", conditionView.getProjectId());
		ActionContext.getContext().put("enterpriseName", conditionView.getEnterpriseName());
		ActionContext.getContext().put("ARole", conditionView.getARole());
		ActionContext.getContext().put("BRole", conditionView.getBRole());
		ActionContext.getContext().put("industryType", conditionView.getIndustryType());
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		ActionContext.getContext().put("beginDate", ((conditionView.getBeginDate()==null)?(""):(format.format(conditionView.getBeginDate()))));
		ActionContext.getContext().put("endDate", ((conditionView.getEndDate()==null)?(""):(format.format(conditionView.getEndDate()))));
		ActionContext.getContext().put("source", conditionView.getSource());
		ActionContext.getContext().put("bank", conditionView.getBank());
		ActionContext.getContext().put("org", conditionView.getOrg());
    	return "projectSurveyList";
    }
	
	/**
	 * ͨ��executeִ�з��� 
	 * @param condition ��������
	 * @return List<PorjectView> ����
	 */
	private List<ProjectView> executeCommon(String userId, String stepId, Integer flowId) {
		List<Object> resultList = projectCommonService.getProjectCommons(userId, stepId, flowId);
		List<ProjectView> projectViews = objectArrayToViewService.parseToList(ProjectView.class, resultList);
		return projectViews;
	}
	
	/**
	 * ������Ŀ����Ϣ������Ŀ��Ϣ
	 * @return	/WEB-INF/page/projectSurvey/projectSurveyDetail.jsp
	 */
	private ProjectView detailCommon(String pNo) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("project.projectNo", pNo);
		List<Object> resultList = projectCommonService.queryByConditions(map);
		return objectArrayToViewService.parseToObject(ProjectView.class, resultList);
	}
	
	/**
	 * �����������󣬸���suggestion��task��
	 * @return
	 * @throws InstantiationException 
	 */
	public void submitCommon()
	{
		
	}
	
	/**
	 * ����ͨ����Ŀһ�� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeFastChanel(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), null, Integer.parseInt(DECG_cons.kstdlc));
		ActionContext.getContext().put("fastChanelList", polist);
		return "fastChanelList";
	}
	/**
	 * �칫����Ŀһ�� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeOffice(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), null, Integer.parseInt(DECG_cons.bghlc));
		ActionContext.getContext().put("officeList", polist);
		return "officeList";
	}
	/**
	 * �󱣻��ճ̰��� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeOverviewSchedule(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.msshrcap, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("overviewScheduleList", polist);
		return "overviewScheduleList";
	}
	/**
	 * �ϻ��ճ̰��� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeOfficeSchedule(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.msshrcap, Integer.parseInt(DECG_cons.bghlc));
		ActionContext.getContext().put("officescheduleList", polist);
		return "officescheduleList";
	}
	/**
	 * ����������Ŀ ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeApprove(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.mstb, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("approveList", polist);
		return "approveList";
	}
	/**
	 * ��Ŀ����ȷ�� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeProjectConfirm(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), null, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("projectConfirmList", polist);
		return "projectConfirmList";
	}
	/**
	 * ������ȷ�� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeSecurityDirectorConfirm(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.sbzrsp, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("securityDirectorConfirmList", polist);
		return "securityDirectorConfirmList";
	}
	/**
	 * ҵ��ֹ��쵼���� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeYWDepartmentLeaderApprove(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.ywfgldsh, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("departmentLeaderApproveList", polist);
		return "YWdepartmentLeaderApproveList";
	}
	/**
	 * ��طֹ��쵼���� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeFKDepartmentLeaderApprove(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.fkfgldsp, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("departmentLeaderApproveList", polist);
		return "FKdepartmentLeaderApproveList";
	}
	/**
	 * �ܾ������� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeGMApprove(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.zjlsp, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("GMApproveList", polist);
		return "GMApproveList";
	}
	/**
	 * ִ�е����� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeZhixindan(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.mssczxd, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("zhixindanList", polist);
		return "zhixindanList";
	}
	
	/**
	 * ���ž������ ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeDepartManagerCheck(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.bmjlsh, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("departManagerCheckList", polist);
		return "departManagerCheckList";
	}

	/**
	 * AB��ɫ��� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeABReplace(){
		return "ABReplaceUI";
	}
	/**
	 * ҵ��ֹ��쵼��� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeLeaderCheck(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.ywfgldsh, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("leaderCheckList", polist);
		return "leaderCheckList";
	}

	/**
	 * ������� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeReviewCheck(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.fwfssh, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("reviewCheckList", polist);
		return "reviewCheckList";
	}
	/**
	 * ������� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeLawerCheck(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.fwfssh, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("lawerCheckList", polist);
		return "lawerCheckList";
	}
	/**
	 * ��ؾ������ ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeWindControlManagerCheck(){
		List<ProjectView> polist = this.executeCommon(this.getUser().getUserId(), DECG_cons.fkjlsh, Integer.parseInt(DECG_cons.zcshlc));
		ActionContext.getContext().put("windControlManagerCheckList", polist);
		return "windControlManagerCheckList";
	}
	
	/**
	 * ��ʾ��Ŀ�󱣻���ϸҳ��
	 * @return
	 */
	public String detailProjectview(){
		this.detailCommon(this.projectView.getProjectNo());
		return "projectOverviewdeTail";
	}
	/**
	 * ��ʾ����ͨ����ϸҳ��
	 * @return
	 */
	public String detailFastChanel(){
		this.detailCommon(this.projectView.getProjectNo());
		return "fastChaneldeTail";
	}
	/**
	 * ��ʾ�칫����ϸҳ��
	 * @return
	 */
	public String detailOffice(){
		this.detailCommon(this.projectView.getProjectNo());
		return "officedeTail";
	}
	
	/**
	 * ��ʾ�󱣻��ճ̰�����ϸҳ��
	 * @return
	 */
	public String detailOverviewSchedule(){
		this.detailCommon(this.projectView.getProjectNo());
		return "overviewScheduledeTail";
	}
	/**
	 * ��ʾ�ϻ��ճ̰�����ϸҳ��
	 * @return
	 */
	public String detailOfficeSchedule(){
		this.detailCommon(this.projectView.getProjectNo());
		return "officeScheduledeTail";
	}
	/**
	 * ��ʾ����������ϸҳ��
	 * @return
	 */
	public String detailApprove(){
		this.detailCommon(this.projectView.getProjectNo());
		return "approvedeTail";
	}
	/**
	 * ��Ŀ����ȷ����ϸҳ��
	 * @return
	 */
	public String detailProjectConfirm(){
		this.detailCommon(this.projectView.getProjectNo());
		return "projectConfirmdeTail";
	}
	/**
	 * ������ȷ����ϸҳ��
	 * @return
	 */
	public String detailSecurityDirectorConfirm(){
		this.detailCommon(this.projectView.getProjectNo());
		return "securityDirectorConfirmdeTail";
	}
	/**
	 * ҵ��ֹ��쵼������ϸҳ��
	 * @return
	 */
	public String detailYWDepartmentLeaderApprove(){
		this.detailCommon(this.projectView.getProjectNo());
		return "YWdepartmentLeaderApprovedeTail";
	}
	/**
	 * ��طֹ��쵼������ϸҳ��
	 * @return
	 */
	public String detailFKDepartmentLeaderApprove(){
		this.detailCommon(this.projectView.getProjectNo());
		return "FKdepartmentLeaderApprovedeTail";
	}
	/**
	 * �ܾ���������ϸҳ��
	 * @return
	 */
	public String detailGMApprove(){
		this.detailCommon(this.projectView.getProjectNo());
		return "GMApprovedeTail";
	}
	/**
	 * ִ�е�������ϸҳ��
	 * @return
	 */
	public String detailZhixindan(){
		this.detailCommon(this.projectView.getProjectNo());
		return "zhixindandeTail";
	}
	
	/**
	 * ���ž��������ϸҳ��
	 * @return
	 */
	public String detailDepartManagerCheck(){
		this.detailCommon(this.projectView.getProjectNo());
		return "departManagerCheckdeTail";
	}
	/**
	 * AB��ɫ��������ϸҳ��
	 * @return
	 */
	public String detailABReplace(){
		List<User> users =  usersRolesService.findProjectManager();
		ActionContext.getContext().put("projectManagerList",users );
		projectView = consulationService.getProjectViewByProjectNo(this.projectView.getProjectNo());
		String returnString = "";
		returnString = projectView==null?"noneData":"ABReplacedeTail";
		return returnString;
	}
	/**
	 * �ֹ��쵼��������ϸҳ��
	 * @return
	 */
	public String detailLeaderCheck(){
		this.detailCommon(this.projectView.getProjectNo());
		return "leaderCheckdeTail";
	}
	/**
	 * ��Ŀ���������������ϸҳ��
	 * @return
	 */
	public String detailReviewCheck(){
		this.detailCommon(this.projectView.getProjectNo());
		return "reviewCheckdeTail";
	}
	/**
	 * ��Ŀ����������������ϸҳ��
	 * @return
	 */
	public String detailLawerCheck(){
		this.detailCommon(this.projectView.getProjectNo());
		return "lawerCheckdeTail";
	}
	/**
	 * ��Ŀ����������������ϸҳ��
	 * @return
	 */
	public String detailWindControlManagerCheck(){
		this.detailCommon(this.projectView.getProjectNo());
		return "windControlManagerCheckdeTail";
	}
	
	/**
	 * ��طֹ��쵼�����ύ
	 * @return
	 */
	public String submitProjectView(){
		submitCommon();
		return "projectViewSubmit";
	}
	/**
	 * ����ͨ�������ύ
	 * @return
	 */
	public String submitFastChanel(){
		submitCommon();
		return "fastChanleSubmit";
	}
	/**
	 * �칫���ύ
	 * @return
	 */
	public String submitOffice(){
		submitCommon();
		return "officeSubmit";
	}
	/**
	 * �󱣻��ճ̰����ύ
	 * @return
	 */
	public String submitOverviewSchedule(){
		submitCommon();
		return "overviewScheduleSubmit";
	}
	/**
	 * �󱣻��ճ̰����ύ
	 * @return
	 */
	public String submitOfficeSchedule(){
		submitCommon();
		return "officeScheduleSubmit";
	}
	/**
	 * ���������ύ
	 * @return
	 */
	public String submitApprove(){
		submitCommon();
		return "approveSubmit";
	}
	/**
	 * ��Ŀ����ȷ���ύ
	 * @return
	 */
	public String submitProjectConfirm(){
		submitCommon();
		return "projectConfirmSubmit";
	}
	/**
	 * ������ȷ���ύ
	 * @return
	 */
	public String submitSecurityDirectorConfirm(){
		submitCommon();
		return "securityDirectorConfirmSubmit";
	}
	/**
	 * ҵ��ֹ��쵼�����ύ
	 * @return
	 */
	public String submitYWDepartmentLeaderApprove(){
		submitCommon();
		return "YWdepartmentLeaderApproveSubmit";
	}
	/**
	 * ��طֹ��쵼�����ύ
	 * @return
	 */
	public String submitFKDepartmentLeaderApprove(){
		submitCommon();
		return "FKdepartmentLeaderApproveSubmit";
	}
	/**
	 * �ܾ��������ύ
	 * @return
	 */
	public String submitGMApprove(){
		submitCommon();
		return "GMApproveSubmit";
	}
	/**
	 * ִ�е������ύ
	 * @return
	 */
	public String submitZhixindan(){
		submitCommon();
		return "ZhixindanSubmit";
	}
	/**
	 * ��ĿA/B���ύ
	 * @return
	 * @throws InstantiationException 
	 */
	public String submitProjectSurvey(){
		submitCommon();
		return "projectSurveySubmit";
	}
	/**
	 * ���ž������
	 * @return
	 * @throws InstantiationException 
	 */
	public String submitDepartManagerCheck(){
		submitCommon();
		return "departManagerCheckSubmit";
	}
	/**
	 * AB��ɫ���
	 * @return
	 * @throws InstantiationException 
	 */
	public String submitABReplace(){
		this.projectCommonService.saveABReplace(this.projectView);
		return "ABReplaceSubmit";
	}
	/**
	 * �ֹ��쵼���
	 * @return
	 * @throws InstantiationException 
	 */
	public String submitLeaderCheck(){
		submitCommon();
		return "leaderCheckSubmit";
	}
	/**
	 * ��Ŀ�������
	 * @return
	 * @throws InstantiationException 
	 */
	public String submitReviewCheck(){
		submitCommon();
		return "reviewCheckSubmit";
	}
	/**
	 * ��Ŀ�������
	 * @return
	 * @throws InstantiationException 
	 */
	public String submitLawerCheck(){
		submitCommon();
		return "lawerCheckSubmit";
	}
	/**
	 * ��ؾ������
	 * @return
	 * @throws InstantiationException 
	 */
	public String submitWindControlManagerCheck(){
		submitCommon();
		return "windControlManagerCheckSubmit";
	}
	
	/**
	 * �ϻ���Ŀһ�� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String executeProjectView(){
		return "projectOverviewList";
	}

	/**
	 * ��ȡsession��Χ�ڵ�User����
	 */
	private User getUser() {
		User user = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		return user;
	}
	
	/**
	 * suggestion
	 *
	 * @return the suggestion
	 */
	
	public Suggestion getSuggestion() {
		return suggestion;
	}


	/**
	 * @param suggestion the suggestion to set
	 */
	public void setSuggestion(Suggestion suggestion) {
		this.suggestion = suggestion;
	}


	/** ��������view **/
	public QueryConditionView getConditionView() {
		return conditionView;
	}


	/** ��������view **/
	public void setConditionView(QueryConditionView conditionView) {
		this.conditionView = conditionView;
	}


	/**
	 * projectView
	 *
	 * @return the projectView
	 */
	
	public ProjectView getProjectView() {
		return projectView;
	}


	/**
	 * @param projectView the projectView to set
	 */
	public void setProjectView(ProjectView projectView) {
		this.projectView = projectView;
	}


	/**
	 * ��ǰ���������
	 */
	public Integer getStepIndex() {
		return stepIndex;
	}


	/**
	 * ��ǰ���������
	 */
	public void setStepIndex(Integer stepIndex) {
		this.stepIndex = stepIndex;
	}


	/**
	 * stepIndex����������
	 */
	public String getCondition() {
		return condition;
	}


	/**
	 * stepIndex����������
	 */
	public void setCondition(String condition) {
		this.condition = condition;
	}
	
}
