/**
		* �ļ�����BankCDAction.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-25
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.consulation.action;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.common.Choose;
import com.decg.base.common.DECG_cons;
import com.decg.consulation.BankCD;
import com.decg.consulation.service.BankCDService;
import com.opensymphony.xwork2.ActionContext;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�BankCDAction
 * ��������
 * �����ˣ�������
 * ����ʱ�䣺2011-3-25 ����11:19:15
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-25 ����11:19:15
 * �޸ı�ע��
 * @version
 *
 */

@Controller
@Scope("prototype")
public class BankCDAction {
	@Resource(name = "bankCDServiceBean")
	private BankCDService bankCDService;
	
	private BankCD bankCD = new BankCD();
	
	/**
	 * ��ѯ�б�
	 * return	
	 */
	public String execute() {
		String whereStatement = "o.visiable=?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		ActionContext.getContext().put("bankCDList", bankCDService.getScrollData(whereStatement, whereParam, null).getResultList());
		ActionContext.getContext().put("codeName", DECG_cons.BANK);
		return "bankCDList_success";
	}
	/**
	 * 
	 */
	public String addCDUI()
	{
		ActionContext.getContext().getSession().put("bankCDEntity", null);
		ActionContext.getContext().put("codeName", DECG_cons.BANK);
		return "addCDUI_success";
	}
	
	public void checkBankCD() {
		try {
			String result = "";
			String whereStatement = "o.consCD=?1 and o.consValue=?2";
			List<Object> param = new ArrayList<Object>();
			String consCD = URLDecoder.decode(this.bankCD.getConsCD(), "utf-8");
			String consValue = URLDecoder.decode(this.bankCD.getConsValue(), "utf-8");
			param.add(consCD);
			param.add(consValue);
			if (bankCDService.exist(whereStatement, param)) {
				result = "�ȶ�CD�ͱȶ�ֵ������Ѵ��ڣ���������д!";
			}
			HttpServletResponse response = ServletActionContext.getResponse();
			response.setCharacterEncoding("utf-8");
			// ʹ��response �����Ӧ��Ϣ ��������Ŀͻ���
			response.getWriter().write(result);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}
	
	public void checkBankCDName(){
		try {
			String result = "";
			String whereStatement = "o.name=?1";
			List<Object> param = new ArrayList<Object>();
			String name = URLDecoder.decode(this.bankCD.getName(), "utf-8");
			param.add(name);
			if(bankCDService.exist(whereStatement, param)){
				result = "CD�����Ѵ���,��������д!";
			}
			HttpServletResponse response = ServletActionContext.getResponse();
			response.setCharacterEncoding("utf-8");
			// ʹ��response �����Ӧ��Ϣ ��������Ŀͻ���
			response.getWriter().write(result);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}
	
	/**
	 * ת������code����
	 * ת��BankCDAction.action
	 */
	public String addCD() {
		String whereStatement = "o.consCD=?1 and o.consValue=?2";
		List<Object> param = new ArrayList<Object>();
		param.add(this.bankCD.getConsCD().trim());
		param.add(this.bankCD.getConsValue().trim());
		if(bankCDService.exist(whereStatement, param)){
			ActionContext.getContext().put("bankCDEntity", bankCD);
			return "addCDUI_success";
		}
		String whereStatement2 = "o.name=?1";
		List<Object> param2 = new ArrayList<Object>();
		param2.add(this.bankCD.getName().trim());
		if(bankCDService.exist(whereStatement2, param2)){
			ActionContext.getContext().put("bankCDEntity", bankCD);
			return "addCDUI_success";
		}
		bankCDService.save(this.bankCD);
		return "addCD_success";
	}
	
	/**
	 * ɾ��cd
	 * ת��BankCDAction.action
	 */
	public String deleteCD(){
		String setStatement = "o.visiable='" + Choose.NO +"'";
		String whereStatement = "o.id=?1";
		List<Object> param = new ArrayList<Object>();
		param.add(this.bankCD.getId());
		bankCDService.update(setStatement, whereStatement, param);
		return "deleteCD_success";
	}
	/**
	 * ת������cd ҳ��
	 */
	public String updateCDUI(){
		String whereStatement = "o.id=?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(this.bankCD.getId());
		ActionContext.getContext().put("codeName", DECG_cons.BANK);
		ActionContext.getContext().put("updateOrNot", true);
		ActionContext.getContext().getSession().put("bankCDEntity", bankCDService.getScrollData(whereStatement, whereParam, null).getResultList().get(0));
		return "updateCDUI_success";
	}
	/**
	 * ����cd
	 * ת��BankCDAction.action
	 */
	public String updateCD(){
		BankCD CDEntity = (BankCD) ActionContext.getContext().getSession().get("bankCDEntity");
		if(! CDEntity.getName().equals(bankCD.getName())){
			String whereStatement = "o.name=?1";
			List<Object> param = new ArrayList<Object>();
			param.add(bankCD.getName().trim());
			if(bankCDService.exist(whereStatement, param)){
				param.remove(0);
				param.add(CDEntity.getName().trim());
				ActionContext.getContext().put("updateOrNot", true);
				ActionContext.getContext().put("bankCDEntity", bankCDService.getScrollData(whereStatement, param, null).getResultList().get(0));
				return "updateCDUI_success";
			}
		}
		bankCDService.update(bankCD);
		return "updateCD_success";
	}
	public BankCD getBankCD() {
		return bankCD;
	}

	public void setBankCD(BankCD bankCD) {
		this.bankCD = bankCD;
	}
	
	
}
