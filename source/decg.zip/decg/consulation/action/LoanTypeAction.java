/**
		* �ļ�����LoanTypeAction.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-23
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.consulation.action;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.QueryResult;
import com.decg.base.common.Choose;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.util.ObjectArrayToViewService;
import com.decg.consulation.EnterpriseCD;
import com.decg.consulation.LoanType;
import com.decg.consulation.service.EnterpriseCDService;
import com.decg.consulation.service.LoanTypeService;
import com.decg.consulation.view.LoanTypeView;
import com.opensymphony.xwork2.ActionContext;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�LoanTypeAction
 * ���������������͹���
 * �����ˣ�������
 * ����ʱ�䣺2011-3-23 ����04:43:26
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-23 ����04:43:26
 * �޸ı�ע��
 * @version
 *
 */

@Controller
@Scope("prototype")
public class LoanTypeAction {
	@Resource(name = "loanTypeServiceBean")
	private LoanTypeService loanTypeService;
	@Resource(name = "enterpriseCDServiceBean")
	private EnterpriseCDService enterpriseCDService;
	@Resource(name = "objectArrayToViewServiceBean")
	private ObjectArrayToViewService objectArrayToViewService;
	
	private LoanType loanType = new LoanType();
	private String filed = null;
	private List<String> ids = new ArrayList<String>();
	//������ر�ĳ���ܵı��,"YES"Ϊ����, "NO"Ϊ�ر�
	private Choose flag = null;
	
	/**
	 * ������������Ʒ��
	 * return	/WEB-INF/page/loanType/loanTypeList.jsp
	 */
	public String execute() {
		List<Object> resultList = loanTypeService.getLoanTypeViews(loanType.getParentId());
		List<LoanTypeView> loanTypeViews = objectArrayToViewService.parseToList(LoanTypeView.class, resultList);
		ActionContext.getContext().put("loantypeList", loanTypeViews);
		return "loanTypeList_success";
	}
	
	/**
	 * ת����������Ʒ�ֽ���
	 * return	/WEB-INF/page/loanType/managerLoanType.jsp
	 */
	public String addUI() {
		String whereStatement = "o.consCD = ?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(DECG_cons.SURVEYREPORTTYPE);
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("consValue", "asc");
		QueryResult<EnterpriseCD> qr = enterpriseCDService.getScrollData(whereStatement, whereParam, orderBy);
		ActionContext.getContext().put("surveyReportTypes", qr.getResultList());
		return "addUI_success";
	}
	
	/**
	 * ��������Ʒ��
	 * return	LoanTypeAction.action?loanType.parentId=${loanType.parentId}
	 */
	public String addLoanType() {
		loanTypeService.save(loanType);
		return "goList_success";
	}
	
	/**
	 * ɾ������Ʒ��
	 * return	LoanTypeAction.action?loanType.parentId=${loanType.parentId}
	 */
	public String delLoanType() {
		loanTypeService.delete("o.loanTypeId = ?1", loanType.getLoanTypeId());
		return "goList_success";
	}
	
	/**
	 * ת�����½���
	 * return	/WEB-INF/page/loanType/managerLoanType.jsp
	 */
	public String updateUI() {
		String whereStatement = "o.consCD = ?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(DECG_cons.SURVEYREPORTTYPE);
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("consValue", "asc");
		QueryResult<EnterpriseCD> qr = enterpriseCDService.getScrollData(whereStatement, whereParam, orderBy);
		ActionContext.getContext().put("surveyReportTypes", qr.getResultList());
		ActionContext.getContext().put("loanTypeEntity", loanTypeService.find(loanType.getLoanTypeId()));
		ActionContext.getContext().put("updateOrNot",true);
		return "updateUI_success";
	}
	
	/**
	 * ��������Ʒ����Ϣ
	 * return	LoanTypeAction.action?loanType.parentId=${loanType.parentId}
	 */
	public String updateLoanType() {
		loanTypeService.update(loanType);
		return "goList_success";
	}
	
	/**
	 * ����ĳ����
	 * return	LoanTypeAction.action?loanType.parentId=${loanType.parentId}
	 */
	public String startUpOrShutDown() {
		if(ids.size() == 0) {
			return "goList_success";
		}
		List<Object> param = new ArrayList<Object>();
		param.add(flag);
		String setStatement = "o." + filed + " = ?1";
		StringBuilder sb = new StringBuilder(50);
		sb.append("o.loanTypeId in (");
		for (int i = 0; i < ids.size(); i++) {
			sb.append("?").append(i+2).append(",");
			param.add(ids.get(i));
		}
		sb.deleteCharAt(sb.length() - 1);
		sb.append(")");
		loanTypeService.update(setStatement, sb.toString(), param);
		return "goList_success";
	}
	
	
	public LoanType getLoanType() {
		return loanType;
	}

	public void setLoanType(LoanType loanType) {
		this.loanType = loanType;
	}

	public String getFiled() {
		return filed;
	}

	public void setFiled(String filed) {
		this.filed = filed;
	}

	public List<String> getIds() {
		return ids;
	}

	public void setIds(List<String> ids) {
		this.ids = ids;
	}

	public Choose getFlag() {
		return flag;
	}
	public void setFlag(Choose flag) {
		this.flag = flag;
	}
	
}
