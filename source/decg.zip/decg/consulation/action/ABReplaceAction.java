package com.decg.consulation.action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.consulation.service.ProjectCommonService;

@Controller
@Scope("prototype")
public class ABReplaceAction {

	@Resource(name="projectCommonServiceBean")
	private ProjectCommonService projectCommonService;
	
	/**
	 * AB��ɫ��� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String execute(){
		return "ABReplaceUI";
	}
	
	/**
	 * AB��ɫ��������ϸҳ��
	 * @return
	 */
	public String detailABReplace(){
		return "ABReplacedeTail";
	}
	
	/**
	 * AB��ɫ���
	 * @return
	 * @throws InstantiationException 
	 */
	public String submitABReplace(){
		this.projectCommonService.saveABReplace(null);
		return "ABReplaceSubmit";
	}
}
