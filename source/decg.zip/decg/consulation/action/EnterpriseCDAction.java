package com.decg.consulation.action;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.common.Choose;
import com.decg.base.common.DECG_cons;
import com.decg.consulation.EnterpriseCD;
import com.decg.consulation.service.EnterpriseCDService;
import com.opensymphony.xwork2.ActionContext;

@Controller
@Scope("prototype")
public class EnterpriseCDAction {
	@Resource(name = "enterpriseCDServiceBean")
	private EnterpriseCDService enterpriseCDService;
	private EnterpriseCD enterpriseCD;
	
	public String execute() {
		String whereStatement = "o.visiable=?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		ActionContext.getContext().put("enterpriseCDList",enterpriseCDService.getScrollData(whereStatement, whereParam, null).getResultList());
		ActionContext.getContext().put("codeName", DECG_cons.enterpriseCD);
		return "enterpriseCD_listSuccess";
	}

	public String addUI() {
		ActionContext.getContext().getSession().put("enterpriseCDView", null);
		return "addUI_success";
	}

	public void checkEnterpriseCD() {
		try {
			String result = "";
			String whereStatement = "o.consCD=?1 and o.consValue=?2";
			List<Object> param = new ArrayList<Object>();
			String consCD = URLDecoder.decode(this.enterpriseCD.getConsCD(), "utf-8");
			String consValue = URLDecoder.decode(this.enterpriseCD.getConsValue(), "utf-8");
			param.add(consCD);
			param.add(consValue);
			if (enterpriseCDService.exist(whereStatement, param)) {
				result = "�ȶ�CD�ͱȶ�ֵ������Ѵ��ڣ���������д!";
			}
			HttpServletResponse response = ServletActionContext.getResponse();
			response.setCharacterEncoding("utf-8");
			// ʹ��response �����Ӧ��Ϣ ��������Ŀͻ���
			response.getWriter().write(result);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}
	
	public void checkEnterpriseCDName(){
		try {
			String result = "";
			String whereStatement = "o.name=?1";
			List<Object> param = new ArrayList<Object>();
			String name = URLDecoder.decode(this.enterpriseCD.getName(), "utf-8");
			param.add(name);
			if(enterpriseCDService.exist(whereStatement, param)){
				result = "CD�����Ѵ���,��������д!";
			}
			HttpServletResponse response = ServletActionContext.getResponse();
			response.setCharacterEncoding("utf-8");
			// ʹ��response �����Ӧ��Ϣ ��������Ŀͻ���
			response.getWriter().write(result);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}
	
	public String add(){
		String whereStatement = "o.consCD=?1 and o.consValue=?2";
		List<Object> param = new ArrayList<Object>();
		param.add(this.enterpriseCD.getConsCD().trim());
		param.add(this.enterpriseCD.getConsValue().trim());
		if(enterpriseCDService.exist(whereStatement, param)){
			ActionContext.getContext().put("enterpriseCDView", enterpriseCD);
			return "addUI_success";
		}
		String whereStatement2 = "o.name=?1";
		List<Object> param2 = new ArrayList<Object>();
		param2.add(this.enterpriseCD.getName().trim());
		if(enterpriseCDService.exist(whereStatement2, param2)){
			ActionContext.getContext().put("enterpriseCDView", enterpriseCD);
			return "addUI_success";
		}
		enterpriseCDService.save(this.enterpriseCD);
		return "add_success";
	}
	
	public String delete() {
		String setStatement = "o.visiable='" + Choose.NO +"'";
		String whereStatement = "o.id=?1";
		List<Object> param = new ArrayList<Object>();
		param.add(this.enterpriseCD.getId());
		enterpriseCDService.update(setStatement, whereStatement, param);
		return "delete_success";
	}

	public String updateUI() {
		String whereStatement = "o.id=?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(this.enterpriseCD.getId());
		ActionContext.getContext().getSession().put("enterpriseCDView", enterpriseCDService.getScrollData(whereStatement, whereParam, null).getResultList().get(0));
		ActionContext.getContext().put("updateOrNot", true);
		return "updateUI_success";
	}

	public String update() {
		EnterpriseCD CDView = (EnterpriseCD) ActionContext.getContext().getSession().get("enterpriseCDView");
		if(! CDView.getName().equals(this.enterpriseCD.getName())){
			String whereStatement = "o.name=?1";
			List<Object> param = new ArrayList<Object>();
			param.add(enterpriseCD.getName().trim());
			if(enterpriseCDService.exist(whereStatement, param)){
				param.remove(0);
				param.add(CDView.getName());
				ActionContext.getContext().put("enterpriseCDView", enterpriseCDService.getScrollData(whereStatement, param, null).getResultList().get(0));
				ActionContext.getContext().put("updateOrNot", true);
				return "updateUI_success";
			}
		}
		enterpriseCDService.update(this.enterpriseCD);
		return "update_success";
	}

	/**
	 * enterpriseCD
	 *
	 * @return the enterpriseCD
	 */
	
	public EnterpriseCD getEnterpriseCD() {
		return enterpriseCD;
	}

	/**
	 * @param enterpriseCD the enterpriseCD to set
	 */
	public void setEnterpriseCD(EnterpriseCD enterpriseCD) {
		this.enterpriseCD = enterpriseCD;
	}
}
