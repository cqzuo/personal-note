package com.decg.consulation.action;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletResponseAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.QueryResult;
import com.decg.base.common.Choose;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.util.EmptyStringFilterService;
import com.decg.base.common.util.ObjectArrayToViewService;
import com.decg.base.common.util.ViewToObjectService;
import com.decg.consulation.Enterprise;
import com.decg.consulation.EnterpriseCD;
import com.decg.consulation.Project;
import com.decg.consulation.Suggestion;
import com.decg.consulation.service.BankService;
import com.decg.consulation.service.ConsulationService;
import com.decg.consulation.service.EnterpriseCDService;
import com.decg.consulation.service.EnterpriseService;
import com.decg.consulation.service.LoanTypeService;
import com.decg.consulation.view.ProjectView;
import com.decg.consulation.view.QueryConditionView;
import com.decg.user.Organization;
import com.decg.user.User;
import com.decg.user.service.OrganizationService;
import com.decg.user.service.UsersRolesService;
import com.opensymphony.xwork2.ActionContext;

@Controller
@Scope("prototype")
public class ConsulationAction implements ServletResponseAware {
	@Resource(name="usersRolesServiceBean")
	private UsersRolesService usersRolesService;
	@Resource(name="organizationServiceBean")
	private OrganizationService organizationService;
	@Resource(name="loanTypeServiceBean")
	private LoanTypeService loanTypeService;
	@Resource(name="bankServiceBean")
	private BankService bankService;
	@Resource(name = "enterpriseServiceBean")
	private EnterpriseService enterpriseService;
	@Resource(name = "consulationServiceBean")
	private ConsulationService consulationService;
	@Resource(name = "objectArrayToViewServiceBean")
	private ObjectArrayToViewService objectArrayToViewService;
	@Resource(name = "enterpriseCDServiceBean")
	private EnterpriseCDService enterpriseCDService;
	@Resource(name="viewToObjectServiceBean")
	private ViewToObjectService viewToObjectService;
	@Resource(name = "emptyStringFilterServiceBean")
	private EmptyStringFilterService<ProjectView> emptyStringFilterService;
	
	//��ҵ��ѯview
	private ProjectView projectView = new ProjectView();
	//��ҵ��ѯ��������ʵ��
	private QueryConditionView queryConditionView = new QueryConditionView();
	//session
	private HttpServletResponse response;
	//��Ŀ�����Ϣ
	private Suggestion suggestion = new Suggestion();
	
	
	/**
	 * ��ҵ��ѯ��ʼ��--һ������
	 * @return	/WEB-INF/page/consulation/consulationList.jsp
	 */
	public String execute(){
		//��ȡsession�е��û���Ϣ���û�����,������Ϣ
		User u = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		Organization organization = (Organization)ActionContext.getContext().getSession().get(DECG_cons.ORG);
		
		//��ҵ��ѯ�б�
		List<Object> resultList = consulationService.getConsulations(u,null);
		List<ProjectView> projectViews = objectArrayToViewService.parseToList(ProjectView.class, resultList);
		ActionContext.getContext().put("projectViews", projectViews);
		
		//�����ҵ����,ע������,��Ŀ��Դ������
		List<EnterpriseCD> enterpriseTypes = new ArrayList<EnterpriseCD>();
		List<EnterpriseCD> sources = new ArrayList<EnterpriseCD>();
		List<EnterpriseCD> registTypes = new ArrayList<EnterpriseCD>();
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("id", "asc");
		QueryResult<EnterpriseCD> qr = enterpriseCDService.getScrollData(orderBy);
		List<EnterpriseCD> enterpriseCDs = qr.getResultList();
		for (EnterpriseCD enterpriseCD : enterpriseCDs) {
			String type = enterpriseCD.getConsCD();
			//�����ҵ����������
			if(DECG_cons.INDUSTRYTYPE.equals(type)) {
				enterpriseTypes.add(enterpriseCD);
			}
			//���ע������������
			if(DECG_cons.REGISTRATIONTYPE.equals(type)) {
				registTypes.add(enterpriseCD);
			}
			//�����Ŀ��Դ������
			if(DECG_cons.SOURCETYPE.equals(type)) {
				sources.add(enterpriseCD);
			}
		}
		
		//��ҵ����������
		ActionContext.getContext().put("industryTypes", enterpriseTypes);
		//��Ŀ��Դ������
		ActionContext.getContext().put("sources", sources);
		//ע������������
		ActionContext.getContext().put("registTypes", registTypes);
		//���е���Ŀ����---������������
		ActionContext.getContext().put("projectManagerList", usersRolesService.findProjectManager());
		//���еĲ���----����������
		ActionContext.getContext().put("orgList", organizationService.getScrollData(null).getResultList());
		//��ǰ��½��----����������������ѡ���ж�
		ActionContext.getContext().put("accepter", u.getUserId());
		//��ǰ��½�����ڲ���----���ڲ���������ѡ���ж�
		ActionContext.getContext().put("Org", organization.getOrgNo());
		//��ǰ��ҵ��ѯ�������Ϣ
		return "consulation_success";
	}
	
	/**
	 * ������ҵ��ѯ����
	 * @return /WEB-INF/page/consulation/consulationUI.jsp
	 */
	public String addUI(){
		ActionContext.getContext().put("projectManagerList", usersRolesService.findProjectManager());
		//�����ҵ����,ע������,��Ŀ��Դ������
		List<EnterpriseCD> enterpriseTypes = new ArrayList<EnterpriseCD>();
		List<EnterpriseCD> sources = new ArrayList<EnterpriseCD>();
		List<EnterpriseCD> registTypes = new ArrayList<EnterpriseCD>();
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("id", "asc");
		QueryResult<EnterpriseCD> qr = enterpriseCDService.getScrollData(orderBy);
		List<EnterpriseCD> enterpriseCDs = qr.getResultList();
		for (EnterpriseCD enterpriseCD : enterpriseCDs) {
			String type = enterpriseCD.getConsCD();
			//�����ҵ����������
			if(DECG_cons.INDUSTRYTYPE.equals(type)) {
				enterpriseTypes.add(enterpriseCD);
			}
			//���ע������������
			if(DECG_cons.REGISTRATIONTYPE.equals(type)) {
				registTypes.add(enterpriseCD);
			}
			//�����Ŀ��Դ������
			if(DECG_cons.SOURCETYPE.equals(type)) {
				sources.add(enterpriseCD);
			}
		}
		//��ҵ����������
		ActionContext.getContext().put("professionTypeList", enterpriseTypes);
		//ע������������
		ActionContext.getContext().put("companyTypeList", registTypes);
		//��Ŀ��Դ������
		ActionContext.getContext().put("sourceProjectTypeList", sources);
		
		//ҳ���ʼ����Ϣ
		projectView = new ProjectView();
		User u = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		projectView.setAccepter_id(u.getUserId());
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		
		ActionContext.getContext().put("projectView", projectView);
		ActionContext.getContext().put("nowDate", format.format(new Date()));
		// ��������
		String whereStatement = "o.visible=?1 and (o.parentId is null or o.parentId = '')";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		ActionContext.getContext().put("loanTypelist", loanTypeService.getScrollData(whereStatement, whereParam, null).getResultList());
		//����
		String whereStatement2 = "o.visible=?1 and (o.parentId is null or o.parentId = '')";
		List<Object> whereParam2 = new ArrayList<Object>();
		whereParam2.add(Choose.YES);
		bankService.getScrollData(whereStatement2, whereParam2, null);
		ActionContext.getContext().put("banklist",bankService.getScrollData(whereStatement2, whereParam2, null).getResultList());
		//�����Ϣ
		return "addUI_success";
	}
	
	/**
	 * ������ҵ��ѯ
	 * @return	consulationAction.action
	 */
	public String save() {
		this.projectView = emptyStringFilterService.process(projectView);
		Map<String,Object> objMap = viewToObjectService.parse(projectView);
		Project project = (Project) objMap.get(DECG_cons.project);
		Enterprise enterprise = (Enterprise) objMap.get(DECG_cons.enterprise);
		// ������Ա��ϵ
		User u = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		project.setRelation_id(u.getUserId());
		// ������Ŀ�Ĳ���
		Organization organization = (Organization)ActionContext.getContext().getSession().get(DECG_cons.ORG);
		project.setOrgNo(organization.getOrgNo());
		
		consulationService.save(enterprise, project, this.suggestion);
    	return "save_success";
    }
    
	/**
	 * ������ҵ��ѯ��Ϣ
	 */
	public String update(){
		this.projectView = emptyStringFilterService.process(projectView);
		Map<String,Object> objMap = viewToObjectService.parse(this.projectView);
		Project project = (Project) objMap.get(DECG_cons.project);
		Enterprise enterprise = (Enterprise) objMap.get(DECG_cons.enterprise);
		consulationService.update(project,enterprise,this.suggestion);
		return "update_success";
	}
	/**
	 * ����ҵ��ѯ��Ϣ�ύ���������
	 */
	public String submit(){
		this.projectView = emptyStringFilterService.process(projectView);
		Map<String,Object> objMap = viewToObjectService.parse(this.projectView);
		Project project = (Project) objMap.get(DECG_cons.project);
		Enterprise enterprise = (Enterprise) objMap.get(DECG_cons.enterprise);
		project.setFlow_id(Integer.parseInt(DECG_cons.zcshlc));
		// ������Ա��ϵ
		User u = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		project.setRelation_id(u.getUserId());
		// ������Ŀ�Ĳ���
		Organization organization = (Organization)ActionContext.getContext().getSession().get(DECG_cons.ORG);
		project.setOrgNo(organization.getOrgNo());
		consulationService.submit(project, enterprise,this.suggestion,u);
		return "submit_success";
	}
	/**
	 * ������Ŀ�Ų�ѯ����ҵ ��Ŀ ������ ��Ϣ,����װ��projectView���ݵ�ǰ̨
	 * �����¼�߷�������,��ת��ֻ��ҳ�� consulationUIReadOnly.jsp
	 * @return	/WEB-INF/page/consulation/consulationUI.jsp
	 */
	public String view() {
		// ҳ�����ݳ�ʼ��
		ActionContext.getContext().put("projectManagerList", usersRolesService.findProjectManager());
		//�����ҵ����,ע������,��Ŀ��Դ������
		List<EnterpriseCD> enterpriseTypes = new ArrayList<EnterpriseCD>();
		List<EnterpriseCD> sources = new ArrayList<EnterpriseCD>();
		List<EnterpriseCD> registTypes = new ArrayList<EnterpriseCD>();
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("id", "asc");
		QueryResult<EnterpriseCD> qr = enterpriseCDService.getScrollData(orderBy);
		List<EnterpriseCD> enterpriseCDs = qr.getResultList();
		for (EnterpriseCD enterpriseCD : enterpriseCDs) {
			String type = enterpriseCD.getConsCD();
			//�����ҵ����������
			if(DECG_cons.INDUSTRYTYPE.equals(type)) {
				enterpriseTypes.add(enterpriseCD);
			}
			//���ע������������
			if(DECG_cons.REGISTRATIONTYPE.equals(type)) {
				registTypes.add(enterpriseCD);
			}
			//�����Ŀ��Դ������
			if(DECG_cons.SOURCETYPE.equals(type)) {
				sources.add(enterpriseCD);
			}
		}
		//��ҵ����������
		ActionContext.getContext().put("professionTypeList", enterpriseTypes);
		//ע������������
		ActionContext.getContext().put("companyTypeList", registTypes);
		//��Ŀ��Դ������
		ActionContext.getContext().put("sourceProjectTypeList", sources);
		
		
		
		// ��������
		String whereStatement = "o.visible=?1 and (o.parentId is null or o.parentId = '')";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		ActionContext.getContext().put("loanTypelist", loanTypeService.getScrollData(whereStatement, whereParam, null).getResultList());
		//����
		String whereStatement2 = "o.visible=?1 and (o.parentId is null or o.parentId = '')";
		List<Object> whereParam2 = new ArrayList<Object>();
		whereParam2.add(Choose.YES);
		bankService.getScrollData(whereStatement2, whereParam2, null);
		ActionContext.getContext().put("banklist",bankService.getScrollData(whereStatement2, whereParam2, null).getResultList());
		
		//�����Ϣ
		Suggestion sug = consulationService.getSuggestionByProject(this.projectView.getId());
		this.setSuggestion(sug);
		
		List<Object> objList = consulationService.getProjectViewById(this.projectView.getId());
		projectView = objectArrayToViewService.parseToObject(ProjectView.class, objList);
		ActionContext.getContext().put("projectView", projectView);
		
		// ��¼���Ƿ���������,�� ��ת��ֻ��ҳ�� consulationUIReadOnly.jsp
		User u = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		if(u.getUserId().equals(this.projectView.getAccepter_id())){
			return "goDetail_success";
		}else{
			return "goDetail_readyOnly";
		}
		
	}
	
    /**
     * 
     * ���������ѯ
     */
	public String findchildrenBanks(){
		String whereStatement = "o.visible=?1 and parentId=?2";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		whereParam.add(this.projectView.getBankId());
		ActionContext.getContext().put("bankchildrenlist", bankService.getScrollData(whereStatement, whereParam, null).getResultList());
		ActionContext.getContext().put("nameFlag", projectView.getNameFlag());
		return "havefindchildrenBanks_success";
	}
	
	/**
	 * 
	 * ����Ʒ�������ѯ
	 */
    public String findchildrenLoanType(){
    	// ��������
		String whereStatement = "o.visible=?1 and parentId is ?2";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		whereParam.add(this.projectView.getLoanTypeId());
		ActionContext.getContext().put("loanTypechildrenlist", loanTypeService.getScrollData(whereStatement, whereParam, null).getResultList());
			return "haveloanTypechildren_success";
    }
    /**
     * 
     * ����Googleģ����ѯ
     */
    public String findabstractName(){
    	List<Enterprise> list = null;
    	try {
    		String name=URLDecoder.decode(projectView.getLikename(), "UTF-8");
    		//��������,������ģ����ѯ
    		if(name.isEmpty()){
    			return null;
    		}
    		list = enterpriseService.findName(name);
    		if(list.isEmpty()){
    		    return null;
        	}
    		else{
    			StringBuffer sb = new StringBuffer();
    			for (Iterator<Enterprise> iterator = list.iterator(); iterator.hasNext();) {
					Enterprise enterprise = (Enterprise) iterator.next();
					sb.append(enterprise.getName());
					sb.append(",");
				}
    			sb.deleteCharAt(sb.length()-1);
    			response.setCharacterEncoding("UTF-8");
    			response.getWriter().write(sb.toString());
    		}
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e.getMessage(), e);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
    }
    /**
     * 
     *  ������ҵ������ģ����ѯ������������
     */
    public String findEnterprise(){
    	try {
			String name=URLDecoder.decode(projectView.getEnterprisename(), "UTF-8");
			Enterprise en = enterpriseService.findEnterpriseName(name);
			// ��ȡ����ҵ����Ŀ���
			if(en!=null){
		        String enObject = en.getEnterpriseType_id() + ","+ en.getRegistAddress() + "," + en.getRegistTime() + ","+ en.getRegistType_id()+","+ en.getLegalPersonName()+","+ en.getContacterName()+","+ en.getContactPhone()+","+ en.getRegistrationCapital()+","+en.getId();
		        response.setCharacterEncoding("UTF-8");
		        response.getWriter().write(enObject);
			} 
			return null;
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
    }
    
    /**
     * ���ž���ָ��AB��ɫ
     * @return	consulationAction.action
     */
    public String departManagerTOAB() {
    	return "goList_success";
    }

	public ProjectView getProjectView() {
		return projectView;
	}

	public void setProjectView(ProjectView projectView) {
		this.projectView = projectView;
	}

	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	public QueryConditionView getQueryConditionView() {
		return queryConditionView;
	}

	public void setQueryConditionView(QueryConditionView queryConditionView) {
		this.queryConditionView = queryConditionView;
	}
	
	 /**
     * ��ҵ��ѯ�ۺϼ���
     */
    public String search() {
    	Map<String,Object> map = new HashMap<String,Object>();
    	//ģ����ѯ
    	map.put("enterprise.name", queryConditionView.getEnterpriseName());
    	//��ȷ��ѯ
    	map.put("enterpriseType.id", queryConditionView.getIndustryType());
    	map.put("project.accepter_id", queryConditionView.getAccepter());
    	map.put("source.id", queryConditionView.getSource());
    	map.put("organization.orgNo", queryConditionView.getOrg());
    	map.put("project.confirmationDate", queryConditionView.getBeginDate());
    	map.put("project.confirmationDate", queryConditionView.getEndDate());
    	
    	List<Object> objs = consulationService.queryByConditions(map);
    	ActionContext.getContext().put("projectViews", objectArrayToViewService.parseToList(ProjectView.class, objs));
    	
    	ActionContext.getContext().put("projectManagerList", usersRolesService.findProjectManager());
		ActionContext.getContext().put("orgList", organizationService.getScrollData(null).getResultList());
		
		//��ҵ����
		String whereStatement = "o.consCD=?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(DECG_cons.INDUSTRYTYPE);
		ActionContext.getContext().put("industryTypes", enterpriseCDService.getScrollData(whereStatement, whereParam, null).getResultList());
		
		//��Ŀ��Դ
		String whereStatement1 = "o.consCD=?1";
		List<Object> whereParam1 = new ArrayList<Object>();
		whereParam1.add(DECG_cons.SOURCETYPE);
		ActionContext.getContext().put("sources", enterpriseCDService.getScrollData(whereStatement1, whereParam1, null).getResultList());
		
		//��������
		String whereStatement2 = "(o.parentId=null or o.parentId=0)";
		ActionContext.getContext().put("banks", bankService.getScrollData(whereStatement2, null, null).getResultList());
		
		//��ѯ���غ����Ϣ
		ActionContext.getContext().put("enterpriseName", queryConditionView.getEnterpriseName());
		ActionContext.getContext().put("industryType", queryConditionView.getIndustryType());
		ActionContext.getContext().put("accepter", queryConditionView.getAccepter());
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		ActionContext.getContext().put("beginDate", ((queryConditionView.getBeginDate()==null)?(""):(format.format(queryConditionView.getBeginDate()))));
		ActionContext.getContext().put("endDate", ((queryConditionView.getEndDate()==null)?(""):(format.format(queryConditionView.getEndDate()))));
		ActionContext.getContext().put("source", queryConditionView.getSource());
		ActionContext.getContext().put("Org", queryConditionView.getOrg());
		
		
    	return "consulation_success";
    }

	/**
	 * suggestion
	 *
	 * @return the suggestion
	 */
	
	public Suggestion getSuggestion() {
		return suggestion;
	}

	/**
	 * @param suggestion the suggestion to set
	 */
	public void setSuggestion(Suggestion suggestion) {
		this.suggestion = suggestion;
	}
}
