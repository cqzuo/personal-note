package com.decg.consulation.action;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.QueryResult;
import com.decg.base.common.Choose;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.StepEnum;
import com.decg.base.common.util.EmptyStringFilterService;
import com.decg.base.common.util.ObjectArrayToViewService;
import com.decg.consulation.Enterprise;
import com.decg.consulation.EnterpriseCD;
import com.decg.consulation.Suggestion;
import com.decg.consulation.service.ApprovalService;
import com.decg.consulation.service.BankService;
import com.decg.consulation.service.ConsulationService;
import com.decg.consulation.service.EnterpriseCDService;
import com.decg.consulation.service.EnterpriseService;
import com.decg.consulation.service.LoanTypeService;
import com.decg.consulation.view.ProjectView;
import com.decg.consulation.view.QueryConditionView;
import com.decg.user.Organization;
import com.decg.user.User;
import com.decg.user.service.OrganizationService;
import com.decg.user.service.UsersRolesService;
import com.opensymphony.xwork2.ActionContext;


/**
 * 
		*
		* ��Ŀ���ƣ�decgNew
		* �����ƣ�ApprovalAction
		* �������������׼
		* �����ˣ�������
		* ����ʱ�䣺2011-5-4 ����10:48:51
		* �޸��ˣ�������
		* �޸�ʱ�䣺2011-5-4 ����10:48:51
		* �޸ı�ע��
		* @version
		*
 */
@Controller
@Scope("prototype")
public class ApprovalAction implements ServletResponseAware {
	@Resource(name="usersRolesServiceBean")
	private UsersRolesService usersRolesService;
	@Resource(name="organizationServiceBean")
	private OrganizationService organizationService;
	@Resource(name="loanTypeServiceBean")
	private LoanTypeService loanTypeService;
	@Resource(name="bankServiceBean")
	private BankService bankService;
	@Resource(name = "enterpriseServiceBean")
	private EnterpriseService enterpriseService;
	@Resource(name = "enterpriseCDServiceBean")
	private EnterpriseCDService enterpriseCDService;
	@Resource(name = "approvalServiceBean")
	private ApprovalService approvalService;
	@Resource(name = "objectArrayToViewServiceBean")
	private ObjectArrayToViewService objectArrayToViewService;
	@Resource(name = "consulationServiceBean")
	private ConsulationService consulationService;
	@Resource(name = "emptyStringFilterServiceBean")
	private EmptyStringFilterService<ProjectView> emptyStringFilterService;

	//�������view
	private ProjectView projectView = new ProjectView();
	//session
	private HttpServletResponse response;
	private QueryConditionView queryConditionView = new QueryConditionView();
	//��Ŀ�����Ϣ
	private Suggestion suggestion;
	

	/**
	 *  ����������Ŀһ����
	 * @return	/WEB-INF/page/consultation/consultationList.jsp
	 */
	public String execute(){
		User u = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		Organization org = (Organization)ActionContext.getContext().getSession().get(DECG_cons.ORG);
		List<Object> resultList = approvalService.getApprovals(u,StepEnum.bmjlfpAB.getValue());
		List<ProjectView> projectViews = objectArrayToViewService.parseToList(ProjectView.class, resultList);
		ActionContext.getContext().put("projectViews", projectViews);
		ActionContext.getContext().put("step_id", StepEnum.bmjlfpAB.getValue());
		//ҳ�����ݵĳ�ʼ��
		ActionContext.getContext().put("projectManagerList", usersRolesService.findProjectManager());
		ActionContext.getContext().put("orgList", organizationService.getScrollData(null).getResultList());
		ActionContext.getContext().put("accepter", u.getUserId());
		ActionContext.getContext().put("Org", org.getOrgNo());
		//��ҵ����
		String whereStatement = "o.consCD=?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(DECG_cons.INDUSTRYTYPE);
		ActionContext.getContext().put("industryTypes", enterpriseCDService.getScrollData(whereStatement, whereParam, null).getResultList());
		//��Ŀ��Դ
		String whereStatement1 = "o.consCD=?1";
		List<Object> whereParam1 = new ArrayList<Object>();
		whereParam1.add(DECG_cons.SOURCETYPE);
		ActionContext.getContext().put("sources", enterpriseCDService.getScrollData(whereStatement1, whereParam1, null).getResultList());
		
		return "approval_success";
	}
	/**
	 * ������ҵ��ѯ
	 * @return	ConsultationAction.action
	 */
	public String submit() {
		this.projectView = emptyStringFilterService.process(this.projectView);
		User u = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		approvalService.submit(this.projectView, this.suggestion, u);
    	return "save_success";
    }
	
    /**
     * 
     * ���������ѯ
     */
	public String findchildrenBanks(){
		String whereStatement = "o.visible=?1 and parentId=?2";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		whereParam.add(this.projectView.getBankId());
		ActionContext.getContext().put("bankchildrenlist", bankService.getScrollData(whereStatement, whereParam, null).getResultList());
		return "havefindchildrenBanks_success";
	}
	
	/**
	 * 
	 * ����Ʒ�������ѯ
	 */
    public String findchildrenLoanType(){
    	// ��������
		String whereStatement = "o.visible=?1 and parentId is ?2";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		whereParam.add(this.projectView.getLoanTypeId());
		ActionContext.getContext().put("loanTypechildrenlist", loanTypeService.getScrollData(whereStatement, whereParam, null).getResultList());
			return "haveloanTypechildren_success";
    }
    /**
     * 
     * ����Googleģ����ѯ
     */
    public String findabstractName(){
    	List<Enterprise> list = null;
    	try {
    		String name=URLDecoder.decode(projectView.getLikename(), "UTF-8");
    		//��������,������ģ����ѯ
    		if(name.isEmpty()){
    			return null;
    		}
    		list = enterpriseService.findName(name);
    		if(list.isEmpty()){
    		    return null;
        	}
    		else{
    			ActionContext.getContext().put("resultname", list);
    	    	return "findabstractname";
    		}
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
    }
    /**
     * 
     *  ������ҵ������ģ����ѯ������������
     */
    public String findEnterprise(){
    	try {
			String name=URLDecoder.decode(projectView.getEnterprisename(), "UTF-8");
			Enterprise en = enterpriseService.findEnterpriseName(name);
			if(en!=null){
		        String enObject = en.getEnterpriseType_id() + ","+ en.getRegistAddress() + "," + en.getRegistTime() + ","+ en.getRegistType_id()+","+ en.getLegalPersonName()+","+ en.getContacterName()+","+ en.getContactPhone()+","+ en.getRegistrationCapital();
		        response.setCharacterEncoding("UTF-8");
		        response.getWriter().write(enObject);
			} 
			return null;
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
    }
    
    /**
     * ��Ŀ�����ۺϼ���
     */
    public String search() {
    	Map<String,Object> map = new HashMap<String,Object>();
    	//����ģ����ѯ������
    	map.put("enterprise.name", queryConditionView.getEnterpriseName());
    	//���뾫ȷ��ѯ������
    	map.put("enterpriseType.id", queryConditionView.getIndustryType());
    	map.put("project.accepter_id", queryConditionView.getAccepter());
    	map.put("source.id", queryConditionView.getSource());
    	map.put("organization.orgNo", queryConditionView.getOrg());
    	//������ʼ�Ĳ�ѯ����
    	map.put("project.confirmationDate", queryConditionView.getBeginDate());
    	map.put("project.confirmationDate", queryConditionView.getEndDate());
    	
    	List<Object> objs = approvalService.queryByConditions(map);
    	ActionContext.getContext().put("projectViews", objectArrayToViewService.parseToList(ProjectView.class, objs));
    	
    	ActionContext.getContext().put("projectManagerList", usersRolesService.findProjectManager());
		ActionContext.getContext().put("orgList", organizationService.getScrollData(null).getResultList());
		
		//��ҵ����
		String whereStatement = "o.consCD=?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(DECG_cons.INDUSTRYTYPE);
		ActionContext.getContext().put("industryTypes", enterpriseCDService.getScrollData(whereStatement, whereParam, null).getResultList());
		
		//��Ŀ��Դ
		String whereStatement1 = "o.consCD=?1";
		List<Object> whereParam1 = new ArrayList<Object>();
		whereParam1.add(DECG_cons.SOURCETYPE);
		ActionContext.getContext().put("sources", enterpriseCDService.getScrollData(whereStatement1, whereParam1, null).getResultList());
		
		//��������
		String whereStatement2 = "(o.parentId=null or o.parentId=0)";
		ActionContext.getContext().put("banks", bankService.getScrollData(whereStatement2, null, null).getResultList());
		
		//��ѯ���غ����Ϣ
		ActionContext.getContext().put("enterpriseName", queryConditionView.getEnterpriseName());
		ActionContext.getContext().put("industryType", queryConditionView.getIndustryType());
		ActionContext.getContext().put("accepter", queryConditionView.getAccepter());
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		ActionContext.getContext().put("beginDate", ((queryConditionView.getBeginDate()==null)?(""):(format.format(queryConditionView.getBeginDate()))));
		ActionContext.getContext().put("endDate", ((queryConditionView.getEndDate()==null)?(""):(format.format(queryConditionView.getEndDate()))));
		ActionContext.getContext().put("source", queryConditionView.getSource());
		ActionContext.getContext().put("Org", queryConditionView.getOrg());
    	return "approval_success";
    }
   
    /**
	 * ������Ŀ�Ų�ѯ����ҵ ��Ŀ ������ ��Ϣ,����װ��projectView���ݵ�ǰ̨
	 * �����¼�߷�������,��ת��ֻ��ҳ��
	 * @return
	 */
	public String view() {
		// ҳ�����ݳ�ʼ��
		//�����ҵ����,ע������,��Ŀ��Դ������
		List<EnterpriseCD> enterpriseTypes = new ArrayList<EnterpriseCD>();
		List<EnterpriseCD> sources = new ArrayList<EnterpriseCD>();
		List<EnterpriseCD> registTypes = new ArrayList<EnterpriseCD>();
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("id", "asc");
		QueryResult<EnterpriseCD> qr = enterpriseCDService.getScrollData(orderBy);
		List<EnterpriseCD> enterpriseCDs = qr.getResultList();
		for (EnterpriseCD enterpriseCD : enterpriseCDs) {
			String type = enterpriseCD.getConsCD();
			//�����ҵ����������
			if(DECG_cons.INDUSTRYTYPE.equals(type)) {
				enterpriseTypes.add(enterpriseCD);
			}
			//���ע������������
			if(DECG_cons.REGISTRATIONTYPE.equals(type)) {
				registTypes.add(enterpriseCD);
			}
			//�����Ŀ��Դ������
			if(DECG_cons.SOURCETYPE.equals(type)) {
				sources.add(enterpriseCD);
			}
		}
		//��ҵ����������
		ActionContext.getContext().put("professionTypeList", enterpriseTypes);
		//ע������������
		ActionContext.getContext().put("companyTypeList", registTypes);
		//��Ŀ��Դ������
		ActionContext.getContext().put("sourceProjectTypeList", sources);
		
		
		
		// ��������
		String whereStatement = "o.visible=?1 and (o.parentId is null or o.parentId = '')";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		ActionContext.getContext().put("loanTypelist", loanTypeService.getScrollData(whereStatement, whereParam, null).getResultList());
		//����
		String whereStatement2 = "o.visible=?1 and (o.parentId is null or o.parentId = '')";
		List<Object> whereParam2 = new ArrayList<Object>();
		whereParam2.add(Choose.YES);
		bankService.getScrollData(whereStatement2, whereParam2, null);
		ActionContext.getContext().put("banklist",bankService.getScrollData(whereStatement2, whereParam2, null).getResultList());
		
		//����projectView
		Integer task_id = this.projectView.getTask_id();
		List<Object> objList = consulationService.getProjectViewById(this.projectView.getId());
		this.projectView = objectArrayToViewService.parseToObject(ProjectView.class, objList);
		this.projectView.setTask_id(task_id);
		this.projectView.setIsUpate(true);
		
		//��ʼ��A,B��ɫ������--���������ŵ�������Ŀ����
		ActionContext.getContext().put("projectManagerList", usersRolesService.findProjectManagerByOrg(projectView.getOrgNo()));
		
		ActionContext.getContext().put("taskId", projectView.getTask_id());
		Suggestion suggestion = consulationService.getSuggestionByProject(this.projectView.getId());
		ActionContext.getContext().put("suggestion", suggestion);
		
		//��������
		if(this.projectView.getLoanTypeChildren_id()!=null){
			ActionContext.getContext().put("loanTypeChildren", loanTypeService.getLoanTypeById(this.projectView.getLoanTypeChildren_id()));
		}
		
		//������1����
		if(this.projectView.getBank1Children_id()!=null){
			ActionContext.getContext().put("bank1children", bankService.getBankById(this.projectView.getBank1Children_id()));
		}
		//������2����
		if(this.projectView.getBank2Children_id()!=null){
			ActionContext.getContext().put("bank2children", bankService.getBankById(this.projectView.getBank2Children_id()));
		}
		
		// ��¼���Ƿ���������,�� ��ת��ֻ��ҳ�� consulationUIReadOnly.jsp
		User u = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		String autitorId = consulationService.getAuditorId(this.projectView.getId());
		
		if(u.getUserId().equals(autitorId)){
			return "goDetail_success";
		}else{
			return "goDetail_readyOnly";
		}
		
	}

	public ProjectView getProjectView() {
		return projectView;
	}

	public void setProjectView(ProjectView projectView) {
		this.projectView = projectView;
	}

	public void setServletResponse(HttpServletResponse response) {
		this.response = response;
		
	}

	public Suggestion getSuggestion() {
		return suggestion;
	}

	public void setSuggestion(Suggestion suggestion) {
		this.suggestion = suggestion;
	}
	
	public QueryConditionView getQueryConditionView() {
		return queryConditionView;
	}

	public void setQueryConditionView(QueryConditionView queryConditionView) {
		this.queryConditionView = queryConditionView;
	}
	
}
