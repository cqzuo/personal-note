/**
		* �ļ�����BankAction.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-24
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.consulation.action;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.QueryResult;
import com.decg.base.common.Choose;
import com.decg.base.common.DECG_cons;
import com.decg.consulation.Bank;
import com.decg.consulation.BankCD;
import com.decg.consulation.BankFile;
import com.decg.consulation.service.BankCDService;
import com.decg.consulation.service.BankFileService;
import com.decg.consulation.service.BankService;
import com.opensymphony.xwork2.ActionContext;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�BankAction
 * �����������еĲ���
 * �����ˣ�������
 * ����ʱ�䣺2011-3-24 ����09:05:42
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-24 ����09:05:42
 * �޸ı�ע��
 * @version
 *
 */

@Controller
@Scope("prototype")
public class BankAction {
	@Resource(name = "bankServiceBean")
	private BankService bankService;
	@Resource(name = "bankFileServiceBean")
	private BankFileService bankFileService;
	@Resource(name = "bankCDServiceBean")
	private BankCDService bankCDService;
	
	private Bank bank = new Bank();
	private BankFile bankFile = new BankFile();
	private Boolean saveOrUpdateFlag = false;
	private List<String> ids = new ArrayList<String>();
	private List<String> arrayChecks = new ArrayList<String>();
	private List<String> businessTypes = new ArrayList<String>();
	private List<String> fileTypes = new ArrayList<String>();
	private List<String> fileNames = new ArrayList<String>();
	
	/**
	 * ��ѯ���������б�
	 * return	WEB-INF/page/bank/bankList.jsp
	 */
	public String execute() {
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("bankId", "asc");
		QueryResult<Bank> qr = bankService.getScrollData("o.visible = '"+Choose.YES+"'", null, orderBy);
		List<Bank> bankList = qr.getResultList();
		
		if(bank.getParentId() == null) {
			//���ж�������
			List<Bank> parentBanks = new ArrayList<Bank>();
			for(Bank bank : bankList) {
				if(bank.getParentId() == null) {
					parentBanks.add(bank);
				}
			}
			ActionContext.getContext().put("banklist", parentBanks);
		} else {
			List<Object> whereParam = new ArrayList<Object>();
			whereParam.add(bank.getParentId());
			qr = bankService.getScrollData("o.visible = '"+Choose.YES+"' and o.parentId = ?1", whereParam, orderBy);
			ActionContext.getContext().put("banklist", qr.getResultList());
		}
		
		//��������
		ActionContext.getContext().put("allBanklist", bankList);
		return "bankList_success";
	}
	
	/**
	 * ת��ά�����н���
	 * return	/WEB-INF/page/bank/addBankUI.jsp
	 */
	public String manageBankUI() {
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("id", "asc");
		
		//��������Ӷ�������,����������ļ�CD����,���򲻼���
		if(this.bank.getParentId() == null || "".equals(this.bank.getParentId())) {
			//����ҵ��������ļ�����,���洢��request��Χ
			//����ҵ�����༯��
			List<BankCD> businessTypeList = new ArrayList<BankCD>();
			//�����ļ����༯��
			List<BankCD> fileTypeList = new ArrayList<BankCD>();
			
			//�������е�BankCD
			QueryResult<BankCD> qr = bankCDService.getScrollData(orderBy);
			List<BankCD> bankCDs = qr.getResultList();
			for(BankCD bankCD : bankCDs) {
				//����ҵ������ʵ�嵽ҵ�����༯��
				if(DECG_cons.BUSINESSTYPE.equals(bankCD.getConsCD())) {
					businessTypeList.add(bankCD);
				}
				//�����ļ�����ʵ�嵽�ļ����༯��
				if(DECG_cons.FILETYPE.equals(bankCD.getConsCD())) {
					fileTypeList.add(bankCD);
				}
			}
			//��ҵ��������ļ����ʹ洢��request��Χ
			ActionContext.getContext().put("businessTypeList", businessTypeList);
			ActionContext.getContext().put("fileTypeList", fileTypeList);
		}
		
		
		//�������ӽ���
		if(!saveOrUpdateFlag) {
			//��������ID,���洢��request��Χ
			this.bank.setBankId(bankService.getBankId(this.bank.getParentId()));
			ActionContext.getContext().put("entity", this.bank);
		} else {	//������½���
			this.setBank(bankService.find(bank.getBankId()));
			//����Ƕ�������,����Ҫ���������������ļ�
			if(this.bank.getParentId() == null || "".equals(this.bank.getParentId())) {
				orderBy.clear();
				orderBy.put("bankFileId", "asc");
				List<Object> whereParam = new ArrayList<Object>();
				whereParam.add(bank.getBankId());
				QueryResult<BankFile> qrBankFile = bankFileService.getScrollData("o.bankId = ?1", whereParam, orderBy);
				ActionContext.getContext().put("bankFileList", qrBankFile.getResultList());
			}
			ActionContext.getContext().put("saveOrUpdateFlag", true);
		}
		return "addUIBank_success";
	}
	
	/**
	 * ����ά��
	 * return	BankAction.action?bank.parentId=${bank.parentId}
	 */
	public String manageBank() {
		if(!saveOrUpdateFlag) {
			bankService.save(bank, arrayChecks, businessTypes, fileTypes, fileNames);
		} else {
			bankService.update(bank, arrayChecks, businessTypes, fileTypes, fileNames);
		}
		return "goList_success";
	}
	
	/**
	 * �������ֲ�ѯ�����б�
	 * return	/WEB-INF/page/bank/bankList.jsp
	 */
	public String queryByCondition() {
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("bankId", "asc");
		
		//�������е�����
		QueryResult<Bank> qr = bankService.getScrollData("o.visible = '"+Choose.YES+"'", null, orderBy);
		ActionContext.getContext().put("allBanklist", qr.getResultList());
		
		List<Object> whereParam = new ArrayList<Object>();
		StringBuilder sb = new StringBuilder(50);
		sb.append(" o.visible = '"+Choose.YES+"' ");
		if(bank.getBankId() != null && !"".equals(bank.getBankId().trim())) {
			whereParam.add(bank.getBankId());
			sb.append(" and o.bankId = ?").append(whereParam.size()).append(" ");
		}
		if (bank.getAddress() != null && !"".equals(bank.getAddress().trim())) {
			whereParam.add("%" + bank.getAddress().trim() + "%");
			sb.append(" and o.address like ?").append(whereParam.size()).append(" ");
		}
		if(whereParam.size() == 0) {
			sb.append(" and o.parentId is null ");
			//���ж�������
			List<Bank> parentBanks = new ArrayList<Bank>();
			List<Bank> bankList = qr.getResultList();
			for(Bank bank : bankList) {
				if(bank.getParentId() == null) {
					parentBanks.add(bank);
				}
			}
			ActionContext.getContext().put("banklist", parentBanks);
		} else {
			qr = bankService.getScrollData(sb.toString(), whereParam, orderBy);
			ActionContext.getContext().put("banklist", qr.getResultList());
		}
		return "bankList_success";
	}
	
	/**
	 * ɾ������
	 * return	BankAction.action?bank.parentId=${bank.parentId}
	 */
	public String delete() {
		if(ids.size() > 0) {
			StringBuilder sb = new StringBuilder(50);
			sb.append(" o.bankId in ( ");
			for(int i=0; i<ids.size(); i++) {
				sb.append("?").append(i+2).append(",");
			}
			sb.deleteCharAt(sb.length() - 1).append(" ) ");
			List<Object> param = new ArrayList<Object>();
			param.add(Choose.NO);
			param.add(ids);
			bankService.update(" o.visible = ?1 ", sb.toString(), param);
		}
		return "goList_success";
	}
	

	
	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public List<String> getIds() {
		return ids;
	}

	public void setIds(List<String> ids) {
		this.ids = ids;
	}

	public BankFile getBankFile() {
		return bankFile;
	}

	public void setBankFile(BankFile bankFile) {
		this.bankFile = bankFile;
	}

	public List<String> getArrayChecks() {
		return arrayChecks;
	}

	public void setArrayChecks(List<String> arrayChecks) {
		this.arrayChecks = arrayChecks;
	}

	public List<String> getBusinessTypes() {
		return businessTypes;
	}

	public void setBusinessTypes(List<String> businessTypes) {
		this.businessTypes = businessTypes;
	}

	public List<String> getFileTypes() {
		return fileTypes;
	}

	public void setFileTypes(List<String> fileTypes) {
		this.fileTypes = fileTypes;
	}

	public List<String> getFileNames() {
		return fileNames;
	}

	public void setFileNames(List<String> fileNames) {
		this.fileNames = fileNames;
	}

	public Boolean getSaveOrUpdateFlag() {
		return saveOrUpdateFlag;
	}

	public void setSaveOrUpdateFlag(Boolean saveOrUpdateFlag) {
		this.saveOrUpdateFlag = saveOrUpdateFlag;
	}
	
}
