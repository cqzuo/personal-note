/**
		* �ļ�����BankFile.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-24
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.consulation;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�BankFile
 * �������������ļ�ʵ��
 * �����ˣ�������
 * ����ʱ�䣺2011-3-24 ����02:00:18
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-24 ����02:00:18
 * �޸ı�ע��
 * @version
 *
 */

@Entity
@Table(name = "BankFile")
public class BankFile implements Serializable {
	private static final long serialVersionUID = -4994810218422710334L;
	
	/**
	 * Id
	 * 
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer bankFileId = null;
	
	/**
	 * ҵ������
	 * @Column(length = 2)
	 */
	@Column(length = 2)
	private String businessTypeId = null;
	/**
	 * ����id
	 * @Column(length = 2)
	 */
	@Column(length = 2)
	private String bankId = null;
	/**
	 * �ļ�����
	 * @Column(length = 16)
	 */
	@Column(length = 16)
	private String fileTypeId = null;
	/**
	 * �ļ���
	 * @Column(length = 32)
	 */
	@Column(length = 32)
	private String fileName = null;
	/**
	 * Id
	 * 
	 */
	public Integer getBankFileId() {
		return bankFileId;
	}
	/**
	 * Id
	 * 
	 */
	public void setBankFileId(Integer bankFileId) {
		this.bankFileId = bankFileId;
	}
	/**
	 * ҵ������
	 * @Column(length = 2)
	 */
	public String getBusinessTypeId() {
		return businessTypeId;
	}
	/**
	 * ҵ������
	 * @Column(length = 2)
	 */
	public void setBusinessTypeId(String businessTypeId) {
		this.businessTypeId = businessTypeId;
	}
	/**
	 * ����id
	 * @Column(length = 2)
	 */
	public String getBankId() {
		return bankId;
	}
	/**
	 * ����id
	 * @Column(length = 2)
	 */
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}
	/**
	 * �ļ�����
	 * @Column(length = 16)
	 */
	public String getFileTypeId() {
		return fileTypeId;
	}
	/**
	 * �ļ�����
	 * @Column(length = 16)
	 */
	public void setFileTypeId(String fileTypeId) {
		this.fileTypeId = fileTypeId;
	}
	/**
	 * �ļ���
	 * @Column(length = 32)
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * �ļ���
	 * @Column(length = 32)
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/*
			(non-Javadoc)
			* @see java.lang.Object#hashCode()
			*/
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((bankFileId == null) ? 0 : bankFileId.hashCode());
		return result;
	}
	/*
			(non-Javadoc)
			* @see java.lang.Object#equals(java.lang.Object)
			*/
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankFile other = (BankFile) obj;
		if (bankFileId == null) {
			if (other.bankFileId != null)
				return false;
		} else if (!bankFileId.equals(other.bankFileId))
			return false;
		return true;
	}

	
}
