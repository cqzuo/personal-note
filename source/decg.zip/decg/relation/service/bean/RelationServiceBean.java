/**
		* �ļ�����RelationServiceBean.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-23
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.relation.service.bean;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.base.DaoSupport;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.StepEnum;
import com.decg.base.common.annotation.StepMapping;
import com.decg.relation.ManyProcesser;
import com.decg.relation.Relation;
import com.decg.relation.StepsProcessers;
import com.decg.relation.service.RelationService;
import com.decg.step.Step;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�RelationServiceBean
 * ����������Ա��ϵ�ӿ�ʵ��
 * �����ˣ�������
 * ����ʱ�䣺2011-3-23 ����01:19:16
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-23 ����01:19:16
 * �޸ı�ע��
 * @version
 *
 */
@SuppressWarnings("unchecked")
@Service
public class RelationServiceBean extends DaoSupport<Relation> implements
		RelationService {

	
	@Override
	@Transactional
	public void save(Relation relation) {
		em.persist(relation);
		//��ȡ���в���
		Query qr = em.createQuery("select step from Step step order by step.stepId asc");
		List<Step> steps = qr.getResultList();
		saveStepProcesser(steps, relation);
		
	}
	
	
	

	@Override
	@Transactional
	public void delete(Serializable... entityIds) {
		StringBuilder relationSb = new StringBuilder(100);
		StringBuilder stepsProcessersSb = new StringBuilder(100);
		StringBuilder manyProcesserSb = new StringBuilder(100);
		StringBuilder sb1 = new StringBuilder(50);
		List<Object> ids = new ArrayList<Object>();
		relationSb.append("delete from Relation o where o.projectManagerId in (");
		for (int i = 0; i < entityIds.length; i++) {
			sb1.append("?").append(i+1).append(",");
			ids.add(entityIds[i]);
		}
		sb1.deleteCharAt(sb1.length() - 1);
		relationSb.append(sb1);
		relationSb.append(")");
		Query relationQr = em.createQuery(relationSb.toString());
		setWhereParam(relationQr, ids);
		relationQr.executeUpdate();
		
		stepsProcessersSb.append("delete from StepsProcessers o where o.relationId in (").append(sb1).append(")");
		Query stepsProcessersQr = em.createQuery(stepsProcessersSb.toString());
		setWhereParam(stepsProcessersQr, ids);
		stepsProcessersQr.executeUpdate();
		
		manyProcesserSb.append("delete from ManyProcesser o where o.relationId in (").append(sb1).append(")");
		Query manyProcesserQr = em.createQuery(manyProcesserSb.toString());
		setWhereParam(manyProcesserQr, ids);
		manyProcesserQr.executeUpdate();
	}
	
	
	@Override
	@Transactional
	public void update(Relation relation) {
		em.merge(relation);
		Query qr = em.createQuery("delete from StepsProcessers sp where sp.relationId = ?1");
		qr.setParameter(1, relation.getProjectManagerId());
		qr.executeUpdate();
		qr = em.createQuery("delete from ManyProcesser mp where mp.relationId = ?1");
		qr.setParameter(1, relation.getProjectManagerId());
		qr.executeUpdate();
		//��ȡ���в���
		qr = em.createQuery("select step from Step step order by step.stepId asc");
		List<Step> steps = qr.getResultList();
		saveStepProcesser(steps, relation);
	}




	/**
	 * �����������账����
	 */
	private void saveStepProcesser(List<Step> steps, Relation relation) {
		try {
			//�������в���
			for (Step step : steps) {
				
				//��ȡ����ID
				String stepId = step.getStepId();
				//��ȡ��������id
				String stepTypeId = step.getStepTypeId();
					
				//��ȡRealtion����,����ȡֵ
				Class<?> clazz = relation.getClass();
				Field[] fields = clazz.getDeclaredFields();
				for (int i = 0; i < fields.length; i++) {
					Field field = fields[i];
					//��ȡStepMappingע��,���Ϊ��,�����.�����Ϊ��,���ȡ����ֵ
					StepMapping stepMapping = field.getAnnotation(StepMapping.class);
					if(stepMapping != null) {
						StepEnum[] stepEnums = stepMapping.step();
						for (int j = 0; j < stepEnums.length; j++) {
							StepEnum stepEnum = stepEnums[j];
							//��ȡ�����Զ�Ӧ�Ĳ���ID
							String userStepId = stepEnum.getValue();
							//�����ȣ����ȡԱ��ID
							if(stepId.equals(userStepId)) {
								boolean flag = field.isAccessible();
								field.setAccessible(true);
								if(DECG_cons.single.equals(stepTypeId)) {	
									StepsProcessers sp = new StepsProcessers();
									sp.setStepsProcessers_id(UUID.randomUUID().toString().replace("-", ""));
									sp.setUserId(field.get(relation).toString());
									sp.setRelationId(relation.getProjectManagerId());
									sp.setStepId(stepId);
									em.persist(sp);
								} else {
									ManyProcesser mp = new ManyProcesser();
									mp.setStepsProcessers_id(UUID.randomUUID().toString().replace("-", ""));
									mp.setUserId(field.get(relation).toString());
									mp.setRelationId(relation.getProjectManagerId());
									mp.setStepId(stepId);
									em.persist(mp);
								}
								field.setAccessible(flag);
							}
						}
							
					}
				}
					
			}
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(),e);
		}
	}


	public List<Relation> querys(String sql) {
		List<Relation> relationList = em.createQuery(sql).getResultList();
		return relationList;
	}
	
	

}
