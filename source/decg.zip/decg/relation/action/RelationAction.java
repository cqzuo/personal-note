/**
		* �ļ�����RelationAction.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-23
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.relation.action;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Resource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import com.decg.base.QueryResult;
import com.decg.base.common.DECG_cons;
import com.decg.relation.Relation;
import com.decg.relation.service.RelationService;
import com.decg.user.service.OrganizationService;
import com.decg.user.service.UserService;
import com.opensymphony.xwork2.ActionContext;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�RelationAction
 * ��������--------��Ա��ϵ����
 * �����ˣ�������
 * ����ʱ�䣺2011-3-23 ����01:21:05
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-23 ����01:21:05
 * �޸ı�ע��
 * @version
 *
 */

@Controller
@Scope("prototype")
public class RelationAction {
	@Resource(name = "relationServiceBean")
	private RelationService relationService;
	@Resource(name = "userServiceBean")
	private UserService userService;
	private Relation relation;
	@Resource(name = "organizationServiceBean")
	private OrganizationService organizationService;
	/**
	 * ��ѯ������Ա��ϵ��
	 * return	
	 */
	public String execute() {
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("projectManagerId", "asc");
		QueryResult<Relation> qr = relationService.getScrollData(orderBy);
		ActionContext.getContext().put("relationList", qr.getResultList());
		//����������Ŀ����
		ActionContext.getContext().put("managerList", userService.getUsersById(DECG_cons.projectManager));
		//�������и���
		ActionContext.getContext().put("reviewList", userService.getUsersById(DECG_cons.review));
		//�������з���
		ActionContext.getContext().put("lawerList", userService.getUsersById(DECG_cons.lawer));
		return "relationList_success";
	}
	
	/**
	 * ת�����ӹ�ϵ����
	 * return	
	 */
	public String addRelationUI() {
		//����������Ŀ����
		ActionContext.getContext().put("projectManagerList", userService.getUsersById(DECG_cons.projectManager));
		return "addRelationUI_success";
	}
	
	public String addRelation() {
		String orgName = organizationService.find(this.relation.getOrgId()).getOrgName();
		this.relation.setOrgName(orgName);
		relationService.save(this.relation);
		return "goRelationList_success";
	}
	
	/**
	 * ������Ա�б�
	 * 
	 * @return RelationAction.action
	 */
	public String showOtherUsers() {
		//���ž���
		ActionContext.getContext().put("departmentManagerList",userService.getDepartmentManagerList(this.relation.getOrgId()));
		//����
		ActionContext.getContext().put("reviewList",userService.getUsersById(DECG_cons.review));
		//����
		ActionContext.getContext().put("lawerList",userService.getUsersById(DECG_cons.lawer));
		//��ͬ����(��)
		ActionContext.getContext().put("contactManagerList",userService.getUsersById(DECG_cons.contactManager));
		//ѺƷ������
		ActionContext.getContext().put("CollateralManagerList",userService.getUsersById(DECG_cons.collateralManager));
		//�ſ���
		ActionContext.getContext().put("extendLoanerList",userService.getUsersById(DECG_cons.extendLoaner));
		//��ͬ����(��)
		ActionContext.getContext().put("contactManager_ZList",userService.getUsersById(DECG_cons.contactManager_Z));
		//�칫������
		ActionContext.getContext().put("officeSecretaryList",userService.getUsersById(DECG_cons.officeSecretary));
		//��������
		ActionContext.getContext().put("securitySupervisionList",userService.getUsersById(DECG_cons.securitySupervision));
		//׷����Ա
		ActionContext.getContext().put("recoveryStaffList",userService.getUsersById(DECG_cons.recoveryStaff));
		//����
		ActionContext.getContext().put("cashierList",userService.getUsersById(DECG_cons.cashier));
		//������
		ActionContext.getContext().put("securitySecretaryList",userService.getUsersById(DECG_cons.securitySecretary));
		//�ֹ��쵼(ҵ)
		ActionContext.getContext().put("departLeaderList",userService.getUsersById(DECG_cons.departLeader));
		//��ؾ���
		ActionContext.getContext().put("windControlManagerList",userService.getUsersById(DECG_cons.windControlManager));
		//�󱣻�����
		ActionContext.getContext().put("securityDirectorList",userService.getUsersById(DECG_cons.securityDirector));
		//�ֹ��쵼(��)
		ActionContext.getContext().put("windLeaderList",userService.getUsersById(DECG_cons.windLeader));
		//�ܾ���
		ActionContext.getContext().put("generalManagerList",userService.getUsersById(DECG_cons.generalManager));
		return "showOtherUsers_success";
	}

	/**
	 * ɾ������Ա��ϵ
	 * @return RelationAction.action
	 */
	public String deleteRelation(){
		relationService.delete(this.relation.getProjectManagerId());
		return "delete_success";
	}
	
	/**
	 * �޸�ǰ����
	 * @return
	 */
	public String updateRelationUI(){
		//��ǰ��Ա��ϵ
		this.relation = relationService.find(this.relation.getProjectManagerId());
		//���ž���
		ActionContext.getContext().put("departManagers",userService.getUsersById(DECG_cons.departManager));
		//��ͬ����(��)
		ActionContext.getContext().put("contactManagerList",userService.getUsersById(DECG_cons.contactManager));
		//�����б�
		ActionContext.getContext().put("reviewList",userService.getUsersById(DECG_cons.review));
		//�����б�
		ActionContext.getContext().put("lawerList",userService.getUsersById(DECG_cons.lawer));
		//ѺƷ������
		ActionContext.getContext().put("CollateralManagerList",userService.getUsersById(DECG_cons.collateralManager));
		//�ſ���
		ActionContext.getContext().put("extendLoanerList",userService.getUsersById(DECG_cons.extendLoaner));
		//��ͬ����(��) 
		ActionContext.getContext().put("contactManager_ZList",userService.getUsersById(DECG_cons.contactManager_Z));
		///�칫������
		ActionContext.getContext().put("officeSecretaryList",userService.getUsersById(DECG_cons.officeSecretary));
		//��������
		ActionContext.getContext().put("securitySupervisionList",userService.getUsersById(DECG_cons.securitySupervision));
		//׷����Ա
		ActionContext.getContext().put("recoveryStaffList",userService.getUsersById(DECG_cons.recoveryStaff));
		//����
		ActionContext.getContext().put("cashierList",userService.getUsersById(DECG_cons.cashier));
		//������
		ActionContext.getContext().put("securitySecretaryList",userService.getUsersById(DECG_cons.securitySecretary));
		// �ֹ��쵼(ҵ)
		ActionContext.getContext().put("departLeaderList",userService.getUsersById(DECG_cons.departLeader));
		//��ز�����
		ActionContext.getContext().put("windControlManagerList",userService.getUsersById(DECG_cons.windControlManager));
		//�󱣻�����
		ActionContext.getContext().put("securityDirectorList",userService.getUsersById(DECG_cons.securityDirector));
		//�ֹ��쵼(��)
		ActionContext.getContext().put("windLeaderList",userService.getUsersById(DECG_cons.windLeader));
		//�ܾ���
		ActionContext.getContext().put("generalManagerList",userService.getUsersById(DECG_cons.generalManager));
		return "updateUI_success";
	}
	
	public String updateRelation(){
		relationService.update(this.relation);
		return "update_success";
	}
	
	@SuppressWarnings("rawtypes")
	public String queryByRoles(){
		Map<String,Object> map = new HashMap<String,Object>();
		Boolean isBegin=true;
		StringBuffer sql =  new StringBuffer();
		sql.append("select r from Relation r ");
		map.put("projectManagerId", this.relation.getProjectManagerId());
		map.put("reviewId", this.relation.getReviewId());
		map.put("lawerId", this.relation.getLawerId());
		Iterator iter = map.entrySet().iterator();
		while(iter.hasNext()){
			 Map.Entry entry = (Map.Entry) iter.next(); 
			    Object key = entry.getKey(); 
			    Object val = entry.getValue(); 
			    if(!("".equals(val))){
			    	if(isBegin){
			    		sql.append("where r."+key+" = '"+val+"'");
			    		isBegin = false;
			    	}else{
			    		sql.append(" and r."+key+" = '"+val+"'");
			    	}
			    }
		}
		if(sql.length()==0)
		{
			//����������Ŀ����
			ActionContext.getContext().put("managerList", userService.getUsersById(DECG_cons.projectManager));
			//�������и���
			ActionContext.getContext().put("reviewList", userService.getUsersById(DECG_cons.review));
			//�������з���
			ActionContext.getContext().put("lawerList", userService.getUsersById(DECG_cons.lawer));
			ActionContext.getContext().put("relationList", relationService.getScrollData(null).getResultList());
			return "query_success";
		}else{
			//����������Ŀ����
			ActionContext.getContext().put("managerList", userService.getUsersById(DECG_cons.projectManager));
			//�������и���
			ActionContext.getContext().put("reviewList", userService.getUsersById(DECG_cons.review));
			//�������з���
			ActionContext.getContext().put("lawerList", userService.getUsersById(DECG_cons.lawer));
			ActionContext.getContext().put("relationList", relationService.querys(sql.toString()));
			//���ز�ѯʱ��ѡ��
			ActionContext.getContext().put("projectManagerId", this.relation.getProjectManagerId());
			ActionContext.getContext().put("reviewId", this.relation.getReviewId());
			ActionContext.getContext().put("lawerId", this.relation.getLawerId());
		}
		return "query_success";
	}
	
	public Relation getRelation() {
		return relation;
	}
	public void setRelation(Relation relation) {
		this.relation = relation;
	}
}
