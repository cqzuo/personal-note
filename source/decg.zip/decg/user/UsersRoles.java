/**
		* �ļ�����UsersRoles.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-18
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.user;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * ��Ŀ���ƣ�DECG
 * �����ƣ�UsersRoles
 * ���������û�ӵ�еĽ�ɫʵ��
 * �����ˣ�������
 * ����ʱ�䣺2011-3-18 ����12:22:21
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-18 ����12:22:21
 * �޸ı�ע��
 * @version
 *
 */
@Entity
@Table(name = "UsersRoles")
public class UsersRoles implements Serializable {
	private static final long serialVersionUID = 2986146460591712062L;
	
	/**
	 * id
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer usersRoles_id ;
	
	/**
	 * Ա��id
	 * 
	 * @Column(nullable = false, length = 5)
	 */
	@Column(nullable = false, length = 5)
	private String user_Id = null;

	/**
	 * ��ɫid
	 * 
	 * @Column(nullable = false)
	 */
	@Column(nullable = false)
	private String role_id = null;
	
	/**
	 * Ա��id
	 * 
	 * @Column(nullable = false, length = 5)
	 */
	public String getUser_Id() {
		return user_Id;
	}

	/**
	 * Ա��id
	 * 
	 * @Column(nullable = false, length = 5)
	 */
	public void setUser_Id(String user_Id) {
		this.user_Id = user_Id;
	}

	/**
	 * ��ɫid
	 * 
	 * @Column(nullable = false)
	 */
	public String getRole_id() {
		return role_id;
	}

	/**
	 * ��ɫid
	 * 
	 * @Column(nullable = false)
	 */
	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}

	public UsersRoles() {
	}


	
	public UsersRoles(String user_Id, String role_id) {
		this.user_Id = user_Id;
		this.role_id = role_id;
	}

	/**
	 * id
	 */
	public Integer getUsersRoles_id() {
		return usersRoles_id;
	}

	/**
	 * id
	 */
	public void setUsersRoles_id(Integer usersRoles_id) {
		this.usersRoles_id = usersRoles_id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((usersRoles_id == null) ? 0 : usersRoles_id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UsersRoles other = (UsersRoles) obj;
		if (usersRoles_id == null) {
			if (other.usersRoles_id != null)
				return false;
		} else if (!usersRoles_id.equals(other.usersRoles_id))
			return false;
		return true;
	}
	
}
