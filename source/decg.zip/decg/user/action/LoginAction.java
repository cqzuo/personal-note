/**
		* �ļ�����LoginAction.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-19
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.user.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.common.Choose;
import com.decg.base.common.DECG_cons;
import com.decg.menu.Menu;
import com.decg.user.Organization;
import com.decg.user.User;
import com.decg.user.service.LoginService;
import com.decg.user.service.OrganizationService;
import com.decg.user.service.UserService;
import com.opensymphony.xwork2.ActionContext;

/**
 *
 * ��Ŀ���ƣ�DECG_NEW
 * �����ƣ�LoginAction
 * �������������˵�¼����ҳ��ͷ�����˵�������Ϣ�����ת��
 * �����ˣ�������
 * ����ʱ�䣺2011-3-19 ����05:50:59
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-19 ����05:50:59
 * �޸ı�ע��
 * @version
 *
 */

@Controller
@Scope("prototype")
public class LoginAction {
	
	@Resource(name = "userServiceBean")
	private UserService userService;
	@Resource(name = "loginServiceBean")
	private LoginService loginService;
	@Resource(name = "organizationServiceBean")
	private OrganizationService organizationService;
	
	private User user = new User();
	
	/**
	 * execute(�û���¼)
	 * return 	/WEB-INF/page/index.jsp
	 */
	public String execute() {
		String result = "login_success";
		String whereStatement = "o.username = ?1 and o.password = ?2";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(user.getUsername());
		whereParam.add(user.getPassword());
		boolean isExsit = userService.exist(whereStatement, whereParam);
		if(isExsit) {
			User userInfo = loginService.login(user);
			
			if(userInfo.getVisible().toString().equals(Choose.NO)) {
				ActionContext.getContext().put("message", DECG_cons.unVisible);
				return "login_error";
			}
			
			ActionContext.getContext().getSession().put(DECG_cons.USER, userInfo);
			//������ɫ��Ϣ,������session��Χ
			ActionContext.getContext().getSession().put(DECG_cons.ROLE ,loginService.getRoles(userInfo.getUserId()));
			//����Ա�����ڲ���,������session��Χ
			ActionContext.getContext().getSession().put(DECG_cons.ORG, organizationService.find(userInfo.getOrgNo()));
			Date time = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss E");
			String times = sdf.format(time);
			ActionContext.getContext().getSession().put(DECG_cons.TIME, times);
		} else {
			result = "login_error";
		}
		return result;
	}
	
	/**
	 * frameHead(ת����ҳͷ��)
	 * return	/WEB-INF/page/FrameHeader.jsp
	 */
	public String frameHead() {
		User userInfo = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		Organization orgInfo = (Organization) ActionContext.getContext().getSession().get(DECG_cons.ORG);
		ActionContext.getContext().put("userInfo", userInfo);
		ActionContext.getContext().put("orgInfo", orgInfo);
		return "frameHead_success";
	}
	
	/**
	 * frameMenu(ת��˵�)
	 * return	/WEB-INF/page/FrameMenu.jsp
	 */
	public String frameMenu() {
		User userInfo = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		List<Menu> menuList = loginService.getPermitMenus(userInfo.getUserId());
		ActionContext.getContext().getSession().put("permitMenuList", menuList);
		return "frameMenu_success";
	}
	
	/**
	 * 
	 * frameMain(ת����Ϣ����)
	 * return	/WEB-INF/page/FrameMain.jsp
	 */
	public String frameMain() {
		return "frameMain_success";
	}

	public String logout(){
		@SuppressWarnings("rawtypes")
		Map session=ActionContext.getContext().getSession();
		session.remove(DECG_cons.USER);
		session.remove(DECG_cons.ROLE);
		session.remove(DECG_cons.ORG);
		session.remove(DECG_cons.TIME);
		session.remove("permitMenuList");
		session.remove("orgInfo");
		session.remove("permitMenuList");
		return "lougout_success";
	}
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
}
