/**
		* �ļ�����UserAction.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-19
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.user.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.QueryResult;
import com.decg.base.common.Choose;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.SaveOrUpdate;
import com.decg.base.common.StartupOrShutdown;
import com.decg.base.common.util.ObjectArrayToViewService;
import com.decg.user.Employee;
import com.decg.user.Organization;
import com.decg.user.Role;
import com.decg.user.User;
import com.decg.user.UsersRoles;
import com.decg.user.service.LoginService;
import com.decg.user.service.OrganizationService;
import com.decg.user.service.RoleService;
import com.decg.user.service.UserService;
import com.decg.user.service.UserViewService;
import com.decg.user.view.UserView;
import com.opensymphony.xwork2.ActionContext;

/**
 *
 * ��Ŀ���ƣ�DECG_NEW
 * �����ƣ�UserAction
 * �����������й���User�Ĳ�ѯ�Ĳ��������ڴ�Action�н���
 * �����ˣ�������
 * ����ʱ�䣺2011-3-19 ����12:57:47
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-19 ����12:57:47
 * �޸ı�ע��
 * @version
 *
 */

@Controller
@Scope("prototype")
public class UserAction {
	
	@Resource(name = "userServiceBean")
	private UserService userService;
	@Resource(name = "userViewServiceBean")
	private UserViewService userViewService;
	@Resource(name = "organizationServiceBean")
	private OrganizationService organizationService;
	@Resource(name = "objectArrayToViewServiceBean")
	private ObjectArrayToViewService objectArrayToViewService;
	@Resource(name="roleServiceBean")
	private RoleService roleService;
	@Resource(name="loginServiceBean")
	private LoginService loginService;
	@Resource(name = "startupOrShutdownImpl")
	private StartupOrShutdown startupOrShutdown;

	private User user = new User();
	private Employee employee = new Employee();
	
	private Role role = new Role();
	
	private UserView userView = new UserView();
	
	private UsersRoles usersRoles = new UsersRoles();
	
	private List<Object> ids = new ArrayList<Object>();
	
	private String roleIds = "";

    /**
     * �����û��Ľ�ɫ
     * return ת��
     */
    public String showUserRoles(){
    	List<Role> allRole = new ArrayList<Role>();
    	List<Role> userRole = new ArrayList<Role>();
    	userRole = loginService.getRoles(this.user.getUserId());
    	/** ���û��Ľ�ɫ�б� **/
		ActionContext.getContext().put("roleUlist",userRole);
    	
    	/** ���н�ɫ��Ϣ **/
		LinkedHashMap<String, String> orderBy_rol = new LinkedHashMap<String, String>();
		orderBy_rol.put("roleId", "asc");
		String whereStatement = "o.visible=?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		QueryResult<Role> gr_rol = roleService.getScrollData(whereStatement, whereParam, orderBy_rol);
		allRole = gr_rol.getResultList();
		for (Role role1 : userRole) {
			allRole.remove(role1);
		}
		ActionContext.getContext().put("roleList",allRole);
		ActionContext.getContext().put("userId",this.user.getUserId());
    	return "showUserRoles_success";
    }
    /**
	 * execute(��������User, ����userId��������)
	 * return /WEB-INF/page/user/userList.jsp
	 */
	public String execute() {
		//������Ϣ 
		LinkedHashMap<String, String> orderBy_org = new LinkedHashMap<String, String>();
		orderBy_org.put("orgNo", "asc");
		String whereStatement = "o.visible = ?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		QueryResult<Organization> qr_org = organizationService.getScrollData(whereStatement, whereParam, orderBy_org);
		ActionContext.getContext().put("orgList", qr_org.getResultList());
		//��ɫ��Ϣ
		LinkedHashMap<String, String> orderBy_rol = new LinkedHashMap<String, String>();
		orderBy_rol.put("roleId", "asc");
		QueryResult<Role> gr_rol = roleService.getScrollData(whereStatement, whereParam, orderBy_rol);
		ActionContext.getContext().put("roleList", gr_rol.getResultList());
		// Ĭ�ϲ�ѯ��������״̬�û���Ϣ 
		List<Object> resultList = userViewService.getUserViewList();
		List<UserView> userViewList = objectArrayToViewService.parseToList(UserView.class, resultList);
		ActionContext.getContext().put("userViewList", userViewList);
		
		
		return "userList_success";
	}
	
	/**
	 * ת�������û�����
	 * return	/WEB-INF/page/user/addUserUI.jsp
	 */
	public String addUserUI() {
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("orgNo", "asc");
		String whereStatement = "o.visible = ?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		QueryResult<Organization> qr = organizationService.getScrollData(whereStatement, whereParam, orderBy);
		ActionContext.getContext().put("orgList", qr.getResultList());
		
		//��ɫ��Ϣ 
		LinkedHashMap<String, String> orderBy_rol = new LinkedHashMap<String, String>();
		orderBy_rol.put("roleId", "asc");
		QueryResult<Role> gr_rol = roleService.getScrollData(whereStatement, whereParam, orderBy_rol);
		ActionContext.getContext().put("roleList", gr_rol.getResultList());
		
		//�����û����
		ActionContext.getContext().put("newUserId",userViewService.getNewUserId());
		ActionContext.getContext().put("updateOrNot",false);
		ActionContext.getContext().put("flag",false);
		return "addUserUI_success";
	}
	
	/**
	 * �����û�
	 * return	UserAction.action
	 */
	public String addUser() {
		this.user.setUserId(this.employee.getEmployeeId());
		this.employee.setAupEmpcode(((User)ActionContext.getContext().getSession().get(DECG_cons.USER)).getUserId());
		this.employee.setAupEmpDate(new Date());
		StringBuilder sb = new StringBuilder(roleIds);
		sb.deleteCharAt(sb.length() - 1);
		String[] rolesIdArray = sb.toString().split(",");
		List<String> selectedRoleIds = new ArrayList<String>();
		for (int i = 0; i < rolesIdArray.length; i++) {
			selectedRoleIds.add(rolesIdArray[i]);
		}
		userService.saveOrUpdate(user, employee, getSelectedRoleIds(roleIds), SaveOrUpdate.SAVE);
		return "goUserList_success";
	}
	
	/**
	 * �����û�
	 * return	UserAction.action
	 */
	public String updateUser() {
		this.user.setUserId(this.employee.getEmployeeId());
		userService.saveOrUpdate(user,employee, getSelectedRoleIds(roleIds), SaveOrUpdate.UPDATE);
		return "goUserList_success";
	}
	
	/**
	 * ���ݲ�ѯ������ѯ��Ӧ�û���Ϣ
	 * return	UserAction.action
	 */
	public String query(){
		List<Object> resultList = userViewService.getUserViewList(true, userView);
		List<UserView> userViewList = objectArrayToViewService.parseToList(UserView.class, resultList);
		ActionContext.getContext().put("userViewList", userViewList);
		
		String whereStatement = "o.visible = ?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		
		//������Ϣ
		LinkedHashMap<String, String> orderBy_org = new LinkedHashMap<String, String>();
		orderBy_org.put("orgNo", "asc");
		QueryResult<Organization> qr_org = organizationService.getScrollData(whereStatement, whereParam, orderBy_org);
		ActionContext.getContext().put("orgList", qr_org.getResultList());
		//��ɫ��Ϣ
		LinkedHashMap<String, String> orderBy_rol = new LinkedHashMap<String, String>();
		orderBy_rol.put("roleId", "asc");
		QueryResult<Role> gr_rol = roleService.getScrollData(whereStatement, whereParam, orderBy_rol);
		ActionContext.getContext().put("roleList", gr_rol.getResultList());
		
		return "userList_success";
	}
	
	/**
	 * �����û�idɾ�����û�,ʵ���Ͻ�visiable��������ΪChoose.NO,���䲻�ɼ�.��ζ����ְ
	 * ת�� UserAction.action
	 */
	public String deleteUser(){
		startupOrShutdown.shutdown(User.class, "visible", ids);
		return "goList_success";
	}
	
	/**
	 * �����û�id����ɾ�����û�����ɾ����Ӧ��Employee���е���Ϣ
	 * ת�� UserAction.action
	 */
	public String delUserAndEmployee(){
		userService.delUserAndEmployee(user.getUserId());
		return "goList_success";
	}
	
	/**
	 * ��ϸ��Ϣ
	 */
	public String userDetail(){
		String whereStatement = "o.visible = ?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(Choose.YES);
		// �����б�
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("orgNo", "asc");
		QueryResult<Organization> qr = organizationService.getScrollData(whereStatement, whereParam, orderBy);
		ActionContext.getContext().put("orgList", qr.getResultList());
		// userView
		List<Object> uvList = userViewService.getUserView(this.user.getUserId());
		UserView uv = objectArrayToViewService.parseToObject(UserView.class, uvList);
		this.userView = uv;
		ActionContext.getContext().put("flag", true);
		//Ա����ɫ�б�
		List<Role> userRoles = userService.getUserRoles(this.user.getUserId());
		ActionContext.getContext().put("roleUlist", userRoles);
		//���н�ɫ�б�
		orderBy.clear();
		orderBy.put("roleId", "asc");
		QueryResult<Role> qrRole = roleService.getScrollData(orderBy);
		List<Role> roles = qrRole.getResultList();
		roles.removeAll(userRoles);
		ActionContext.getContext().put("roleList", roles);
		return "userDetail_success";
	}
	
	/**
	 * �����û�
	 */
	public String startUp() {
		ids.add(user.getUserId());
		startupOrShutdown.startup(User.class, "visible", ids);
		return "goList_success";
	}
	
	/**
	 * �����û�ѡ��Ľ�ɫ�ַ��������ؽ�ɫid�ļ���
	 */
	private List<String> getSelectedRoleIds(String roleIds) {
		StringBuilder sb = new StringBuilder(roleIds);
		sb.deleteCharAt(sb.length() - 1);
		String[] rolesIdArray = sb.toString().split(",");
		List<String> selectedRoleIds = new ArrayList<String>();
		for (int i = 0; i < rolesIdArray.length; i++) {
			selectedRoleIds.add(rolesIdArray[i]);
		}
		return selectedRoleIds;
	}

	public UserView getUserView() {
		return userView;
	}

	public void setUserView(UserView userView) {
		this.userView = userView;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	
	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}
	
	public List<Object> getIds() {
		return ids;
	}
	public void setIds(List<Object> ids) {
		this.ids = ids;
	}
	
	public UsersRoles getUsersRoles() {
		return usersRoles;
	}
	public void setUsersRoles(UsersRoles usersRoles) {
		this.usersRoles = usersRoles;
	}
	
	public String getRoleIds() {
		return roleIds;
	}
	public void setRoleIds(String roleIds) {
		this.roleIds = roleIds;
	}
	
}
   