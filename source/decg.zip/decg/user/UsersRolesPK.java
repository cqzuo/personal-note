/**
 * �ļ�����UsersRolesPK.java
 *
 * �汾��Ϣ��
 * ���ڣ�2011-3-18
 * Copyright HengTong Corporation 2011
 * ��Ȩ����
 *
 */
package com.decg.user;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * 
 * ��Ŀ���ƣ�DECG 
 * �����ƣ�UsersRolesPK 
 * ���������û�ӵ�еĽ�ɫʵ������� 
 * �����ˣ������� 
 * ����ʱ�䣺2011-3-18 ����12:28:14
 * �޸��ˣ������� 
 * �޸�ʱ�䣺2011-3-18 ����12:28:14 
 * �޸ı�ע��
 * 
 * @version
 * 
 */

@Embeddable
public class UsersRolesPK implements Serializable {
	private static final long serialVersionUID = -4948167486267469908L;
	/**
	 * Ա��id
	 * 
	 * @Column(nullable = false, length = 5)
	 */
	@Column(nullable = false, length = 5)
	private String user_Id = null;

	/**
	 * ��ɫid
	 * 
	 * @Column(nullable = false)
	 */
	@Column(nullable = false)
	private String role_id = null;

	/**
	 * ����һ���µ�ʵ�� UsersRolesPK.
	 */
	public UsersRolesPK() {
	}

	
	public UsersRolesPK(String user_Id, String role_id) {
		this.user_Id = user_Id;
		this.role_id = role_id;
	}





	/**
	 * Ա��id
	 * 
	 * @Column(nullable = false, length = 5)
	 */
	public String getUser_Id() {
		return user_Id;
	}

	/**
	 * Ա��id
	 * 
	 * @Column(nullable = false, length = 5)
	 */
	public void setUser_Id(String user_Id) {
		this.user_Id = user_Id;
	}

	/**
	 * ��ɫid
	 * 
	 * @Column(nullable = false)
	 */
	public String getRole_id() {
		return role_id;
	}


	/**
	 * ��ɫid
	 * 
	 * @Column(nullable = false)
	 */
	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((role_id == null) ? 0 : role_id.hashCode());
		result = prime * result + ((user_Id == null) ? 0 : user_Id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UsersRolesPK other = (UsersRolesPK) obj;
		if (role_id == null) {
			if (other.role_id != null)
				return false;
		} else if (!role_id.equals(other.role_id))
			return false;
		if (user_Id == null) {
			if (other.user_Id != null)
				return false;
		} else if (!user_Id.equals(other.user_Id))
			return false;
		return true;
	}


}
