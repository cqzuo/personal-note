/**
 * �ļ�����Role.java
 *
 * �汾��Ϣ��
 * ���ڣ�2011-3-18
 * Copyright HengTong Corporation 2011
 * ��Ȩ����
 *
 */
package com.decg.user;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import com.decg.base.common.Choose;

/**
 * 
 * ��Ŀ���ƣ�DECG 
 * �����ƣ�Role 
 * ����������ɫ��Ϣʵ�� 
 * �����ˣ������� 
 * ����ʱ�䣺2011-3-18 ����11:18:36 
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-18 ����11:18:36 
 * �޸ı�ע��
 * 
 * @version
 * 
 */

@Entity
@Table(name = "Role")
public class Role implements Serializable {
	private static final long serialVersionUID = 3696953526628493427L;
	/**
	 * ��ɫid
	 * 
	 * @Id
	 * @Column(nullable = false, length = 2, unique = true)
	 */
	@Id
	@Column(nullable = false, length = 2, unique = true)
	private String roleId = null;

	/**
	 * ��ɫ����
	 * 
	 * @Column(length = 16, nullable = false, unique = true)
	 */
	@Column(length = 16, nullable = false, unique = true)
	private String roleName = null;
	
	/**
	 * �Ƿ�����---Ĭ������
	 * @Column(length = 3, nullable = false, updatable = false)
	 * @Enumerated(EnumType.STRING)
	 */
	@Column(length = 3, nullable = false, updatable = false)
	@Enumerated(EnumType.STRING)
	private Choose visible = Choose.YES;
	

	/*------------------------------------------------------------������ʼ-----------------------------------------------------*/
	

	/**
	 * ��ɫ����
	 * 
	 * @Column(length = 16, nullable = false, unique = true)
	 */
	public String getRoleName() {
		return roleName;
	}


	/**
	 * ��ɫid
	 * 
	 * @Id
	 * @Column(nullable = false, length = 2, unique = true)
	 */
	public String getRoleId() {
		return roleId;
	}


	/**
	 * ��ɫid
	 * 
	 * @Id
	 * @Column(nullable = false, length = 2, unique = true)
	 */
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}


	/**
	 * ��ɫ����
	 * 
	 * @Column(length = 16, nullable = false, unique = true)
	 */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
	/**
	 * �Ƿ�����---Ĭ������
	 * @Column(length = 3, nullable = false, updatable = false)
	 * @Enumerated(EnumType.STRING)
	 */
	public Choose getVisible() {
		return visible;
	}

	/**
	 * �Ƿ�����---Ĭ������
	 * @Column(length = 3, nullable = false, updatable = false)
	 * @Enumerated(EnumType.STRING)
	 */
	public void setVisible(Choose visible) {
		this.visible = visible;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((roleId == null) ? 0 : roleId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Role other = (Role) obj;
		if (roleId == null) {
			if (other.roleId != null)
				return false;
		} else if (!roleId.equals(other.roleId))
			return false;
		return true;
	}

}
