/**
		* �ļ�����UsersRolesServiceBean.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-20
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.user.service.bean;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.decg.base.DaoSupport;
import com.decg.base.common.DECG_cons;
import com.decg.consulation.EnterpriseCD;
import com.decg.user.User;
import com.decg.user.UsersRoles;
import com.decg.user.service.UsersRolesService;

/**
 *
 * ��Ŀ���ƣ�DECG_NEW
 * �����ƣ�UsersRolesServiceBean
 * ���������û���ɫ�ӿ�
 * �����ˣ�������
 * ����ʱ�䣺2011-3-20 ����07:21:26
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-20 ����07:21:26
 * �޸ı�ע��
 * @version
 *
 */

@Service
@SuppressWarnings("unchecked")
public class UsersRolesServiceBean extends DaoSupport<UsersRoles> implements UsersRolesService {
	
	public List<User> findProjectManager(){
		String jpql = "select u from User u ,Role r,UsersRoles ur where ur.role_id = r.roleId and ur.user_Id = u.userId and r.roleId=?1";
		Query query = em.createQuery(jpql);
		query.setParameter(1, DECG_cons.projectManager);
		List<User> projectManagerList = query.getResultList();
		return projectManagerList;
	}
	
	
	
	public List<EnterpriseCD> findEnterpriseCDType(String type){
		String jpql = "select cd from EnterpriseCD cd where cd.consCD=?1";
		Query query = em.createQuery(jpql);
		query.setParameter(1, type);
		List<EnterpriseCD> projectManagerList = query.getResultList();
		return projectManagerList;
	}



	public List<User> findProjectManagerByOrg(String orgNo) {
		String jpql = "select u from User u ,Role r,UsersRoles ur where ur.role_id = r.roleId and ur.user_Id = u.userId and r.roleId=?1 and u.orgNo = ?2";
		Query query = em.createQuery(jpql);
		query.setParameter(1, DECG_cons.projectManager);
		query.setParameter(2, orgNo);
		List<User> projectManagerList = query.getResultList();
		return projectManagerList;
	}
}
