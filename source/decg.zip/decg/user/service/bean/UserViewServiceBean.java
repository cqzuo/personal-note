/**
		* �ļ�����UserViewServiceBean.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-18
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.user.service.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.decg.base.DaoSupport;
import com.decg.user.service.UserViewService;
import com.decg.user.view.UserView;

/**
 *
 * ��Ŀ���ƣ�DECG_NEW
 * �����ƣ�UserViewServiceBean
 * �����������UserViewҵ���߼��ӿڵ�ʵ��
 * �����ˣ�������
 * ����ʱ�䣺2011-3-18 ����10:50:18
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-18 ����10:50:18
 * �޸ı�ע��
 * @version
 *
 */

@Service
public class UserViewServiceBean extends DaoSupport<UserView> implements
		UserViewService {

	@SuppressWarnings("unchecked")
	public List<Object> getUserView(String userId) {
		String jpql = "select user, employee, organization from User user, Employee employee, Organization organization where user.userId = employee.employeeId and user.orgNo = organization.orgNo and user.userId = ?1";
		Query query = em.createQuery(jpql);
		query.setParameter(1, userId);
		List<Object> objs = query.getResultList();
		objs.add(jpql);
		return objs;
	}

	@SuppressWarnings("unchecked")
	public List<Object> getUserViewList() {
		String jpql = "select user, employee, organization from User user, Employee employee, Organization organization where user.userId = employee.employeeId and user.orgNo = organization.orgNo";
		Query query = em.createQuery(jpql);
		List<Object> objs = query.getResultList();
		objs.add(jpql);
		return objs;
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> getUserViewList(Boolean visiable, UserView userView) {
		List<Object> whereParam = new ArrayList<Object>();
		StringBuilder sb = new StringBuilder(300);
		sb.append(" select user, employee, organization ");
		sb.append(" from User user, Employee employee, Organization organization ");
		sb.append(" where user.userId = employee.employeeId and user.orgNo = organization.orgNo and 1 = 1 ");
		if(userView.getRealName() != null && !"".equals(userView.getRealName().trim())) {
			whereParam.add(userView.getRealName().trim());
			sb.append(" and user.realName = ?").append(whereParam.size()).append(" ");
		}
		if(userView.getUserId() != null && !"".equals(userView.getUserId().trim())) {
			whereParam.add(userView.getUserId().trim());
			sb.append(" and user.userId = ?").append(whereParam.size()).append(" ");
		}
		if(userView.getGender() != null) {
			whereParam.add(userView.getGender());
			sb.append(" and employee.gender = ?").append(whereParam.size()).append(" ");
		}
		if(userView.getVisible() != null) {
			whereParam.add(userView.getVisible());
			sb.append(" and user.visible =?").append(whereParam.size()).append(" ");
		}
		if(userView.getOrgNo() != null && !"".equals(userView.getOrgNo().trim())) {
			whereParam.add(userView.getOrgNo().trim());
			sb.append(" and organization.orgNo =?").append(whereParam.size()).append(" ");
		}
		if(userView.getRoleId() != null) {
			whereParam.add(userView.getRoleId());
			sb.append(" and user.userId in (select ur.usersRolesId.user_Id from UsersRoles ur where ur.usersRolesId.role_id=?").append(whereParam.size()).append(") ");
		}
		if(userView.getShenBaoHuiMumber() != null) {
			whereParam.add(userView.getShenBaoHuiMumber());
			sb.append(" and user.shenBaoHuiMumber =?").append(whereParam.size()).append(" ");
		}
		if(userView.getOfficeMumber() != null) {
			whereParam.add(userView.getOfficeMumber());
			sb.append(" and user.officeMumber =?").append(whereParam.size()).append(" ");
		}
		Query query = em.createQuery(sb.toString());
		
		for (int i = 0; i < whereParam.size(); i++) {
			query.setParameter(i+1, whereParam.get(i));
		}
		
		List<Object> objs = query.getResultList();
		objs.add(sb.toString());
		return objs;
	}

	public  String getNewUserId() {
		String jpql = "select u.userId from User u order by u.userId desc";
		Query query = em.createQuery(jpql);
		String userId = (String)query.getResultList().get(0);
		Integer temp = Integer.parseInt(userId)+1;
		String newUserId = temp.toString();
		int length = newUserId.length();
		if(length!=5)
		{
			for (int i = 0; i < 5-length; i++) {
				newUserId = "0"+newUserId;
			}
		}
		return newUserId;
	}
	
}
