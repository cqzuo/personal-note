/**
		* �ļ�����UserServiceBean.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-18
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.user.service.bean;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.base.DaoSupport;
import com.decg.base.common.Choose;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.SaveOrUpdate;
import com.decg.user.Employee;
import com.decg.user.Role;
import com.decg.user.User;
import com.decg.user.UsersRoles;
import com.decg.user.service.UserService;

/**
 *
 * ��Ŀ���ƣ�DECG_NEW
 * �����ƣ�UserServiceBean
 * �����������Userҵ���߼��ӿڵ�ʵ��
 * �����ˣ�������
 * ����ʱ�䣺2011-3-18 ����10:24:33
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-18 ����10:24:33
 * �޸ı�ע��
 * @version
 *
 */
@SuppressWarnings("unchecked")
@Service
public class UserServiceBean extends DaoSupport<User> implements UserService {

	@Transactional
	public void saveOrUpdate(User user, Employee employee, List<String> roleIds, SaveOrUpdate saveOrUpdate) {
		
		if(SaveOrUpdate.SAVE.toString().equals(saveOrUpdate.toString())) {
			//�����û���ɫ��Ϣ
			for (String roleId : roleIds) {
				UsersRoles ur = new UsersRoles(user.getUserId(), roleId);
				em.persist(ur);
			}
			em.persist(user);
			em.persist(employee);
		}
		
		if(SaveOrUpdate.UPDATE.toString().equals(saveOrUpdate.toString())) {
			//ɾ��ԭ�н�ɫ
			Query qr = em.createQuery("delete from UsersRoles ur where ur.user_Id = ?1");
			qr.setParameter(1, user.getUserId());
			qr.executeUpdate();
			//�����µ��û���ɫ
			for (String roleId : roleIds) {
				UsersRoles ur = new UsersRoles(user.getUserId(), roleId);
				em.persist(ur);
			}
			em.merge(user);
			em.merge(employee);
		}
		
		
	}

	public List<User> getUsersById(String roleId) {
		Query qr = em.createQuery("select user from User user, UsersRoles ur where user.userId = ur.user_Id and ur.role_id = ?1 and user.visible = ?2");
		qr.setParameter(1, roleId);
		qr.setParameter(2, Choose.YES);
		return qr.getResultList();
	}

	
	public List<User> getDepartmentManagerList(String orgNo) {
		Query qr = em.createQuery("select user from User user, UsersRoles ur where user.userId = ur.user_Id and user.orgNo = ?1 and ur.role_id = ?2 and user.visible=?3 order by user.userId asc");
		qr.setParameter(1, orgNo);
		if(DECG_cons.windControlDepart.equals(orgNo)) {
			qr.setParameter(2, DECG_cons.windControlManager);
		} else {
			qr.setParameter(2, DECG_cons.departManager);
		}
		qr.setParameter(3, Choose.YES);
		return qr.getResultList();
	}

	public List<Role> getUserRoles(String userId) {
		Query qr = em.createQuery("select role from Role role, UsersRoles ur where ur.role_id = role.roleId and ur.user_Id = ?1 and role.visible = ?2 order by role.roleId asc");
		qr.setParameter(1, userId);
		qr.setParameter(2, Choose.YES);
		return qr.getResultList();
	}

	public void delUserAndEmployee(String userId) {
		Query user = em.createQuery("delete from User u where u.userId = ?1");
		user.setParameter(1, userId);
		user.executeUpdate();
		
		Query employee = em.createQuery("delete from Employee e where e.employeeId = ?1");
		employee.setParameter(1, userId);
		employee.executeUpdate();
		
	}

}
