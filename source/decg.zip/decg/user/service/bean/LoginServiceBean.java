/**
		* �ļ�����LoginServiceBean.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-20
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.user.service.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.decg.base.DaoSupport;
import com.decg.menu.Menu;
import com.decg.user.Role;
import com.decg.user.User;
import com.decg.user.service.LoginService;

/**
 *
 * ��Ŀ���ƣ�DECG_NEW
 * �����ƣ�LoginServiceBean
 * ���������û���¼�����ӿ�
 * �����ˣ�������
 * ����ʱ�䣺2011-3-20 ����09:26:36
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-20 ����09:26:36
 * �޸ı�ע��
 * @version
 *
 */

@Service
public class LoginServiceBean extends DaoSupport<User> implements LoginService {

	@SuppressWarnings("unchecked")
	public List<Menu> getPermitMenus(String userId) {
		Query query = em.createQuery("select r.roleId from UsersRoles ur, Role r where ur.role_id = r.roleId and ur.user_Id = ?1");
		query.setParameter(1, userId);
		List<String> roleIds = query.getResultList();
		
		if(roleIds != null && roleIds.size() > 0) {
			Map<Integer, Menu> menuMap = new HashMap<Integer, Menu>();
			List<Menu> menuList = new ArrayList<Menu>();
			for(String roleId : roleIds) {
				query = em.createQuery("select m from Permission p , Menu m where p.role_id = ?1 and p.menu_id = m.menuId");
				query.setParameter(1, roleId);
				List<Menu> menus = query.getResultList();
				for(Menu menu : menus) {
					menuMap.put(menu.getMenuId(), menu);
				}
			}
			
			Set<Integer> ids = new TreeSet<Integer>(menuMap.keySet());
			
			for(Integer key : ids) {
				menuList.add(menuMap.get(key));
			}
			return menuList;
		} else {
			return null;
		}
	}
	
	public User login(User user) {
		Query query = em.createQuery("select o from User o where o.username = ?1 and o.password = ?2");
		query.setParameter(1, user.getUsername());
		query.setParameter(2, user.getPassword());
		return (User) query.getSingleResult();
	}
	
	@SuppressWarnings("unchecked")
	public List<Role> getRoles(String userId) {
		Query query = em.createQuery("select r from UsersRoles ur, Role r where ur.role_id = r.roleId and ur.user_Id = ?1");
		query.setParameter(1, userId);
		return query.getResultList();
	}

}
