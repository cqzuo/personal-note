package com.decg.step.service.bean;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.decg.base.DaoSupport;
import com.decg.step.FlowsSteps;
import com.decg.step.Step;
import com.decg.step.service.FlowsStepsService;
/**
 * 
		*
		* ��Ŀ���ƣ�decgnew
		* �����ƣ�FlowsStepsServiceBean
		* �����������̲���ӿ�ʵ��
		* �����ˣ�Administrator
		* ����ʱ�䣺2011-5-20 ����09:15:17
		* �޸��ˣ�Administrator
		* �޸�ʱ�䣺2011-5-20 ����09:15:17
		* �޸ı�ע��
		* @version
		*
 */
@Service
public class FlowsStepsServiceBean extends DaoSupport<FlowsSteps> implements FlowsStepsService {
	
	public Step nextStep(Integer flowId, String currentStepId) {
		Query q = em.createQuery("select o from FlowsSteps o where o.step_id = ?1 and o.flow_id = ?2");
		q.setParameter(1, currentStepId);
		q.setParameter(2, flowId);
		FlowsSteps fs = (FlowsSteps) q.getSingleResult();
		
		String jpql = "select step from FlowsSteps o, Step step  where o.step_id = step.stepId and o.flow_id= ?1 and o.stepIndex > ?2 order by o.stepIndex asc ";
		Query query=em.createQuery(jpql);
		query.setParameter(1, flowId);
		query.setParameter(2, fs.getStepIndex());
		query.setFirstResult(0);
		query.setMaxResults(1);
		return (Step)query.getResultList().get(0);
	}
	
	public Step firstStep(Integer flowId){
	   String jpql = "";
	   jpql = "select step from FlowsSteps o, Step step where o.step_id = step.stepId and o.flow_id = ?1 order by o.stepIndex asc";
	   Query query = em.createQuery(jpql);
	   query.setParameter(1, flowId);
	   query.setFirstResult(0);
	   query.setMaxResults(1);
	   return (Step)query.getResultList().get(0);
   }

	@SuppressWarnings("unchecked")
	public List<FlowsSteps> getAllByFlowId(Integer flowId) {
		Query qr = em.createQuery(" select o from FlowsSteps o where o.flow_id = ?1 order by o.stepIndex asc ");
		qr.setParameter(1, flowId);
		return qr.getResultList();
	}
}
