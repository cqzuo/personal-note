package com.decg.step.service.bean;

import java.util.List;
import org.springframework.stereotype.Service;
import com.decg.base.DaoSupport;
import com.decg.step.StepManyProcessers;
import com.decg.step.StepsProcessers;
import com.decg.step.service.StepsProcessersService;
import com.decg.user.User;

@Service
public class  StepsProcessersServiceBean extends DaoSupport<StepsProcessers> implements StepsProcessersService {

	public void addStepsProcessers(Integer stepId, Integer userId,
			Integer relationId) {
		// TODO Auto-generated method stub
		
	}

	public void deleteStepsProcessers(Integer stepId, Integer relationId) {
		// TODO Auto-generated method stub
		
	}

	public void updateStepsProcessers(Integer stepId, Integer userId,
			Integer relationId) {
		// TODO Auto-generated method stub
		
	}

	public User getProcesser(Integer stepId, Integer relationId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<StepsProcessers> stepsProcesserslist(Integer relationId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<StepsProcessers> stepsProcesserscheck(Integer stepId,
			Integer relationId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void addStepsProcessers(Integer stepId, Integer relationId,
			List<Integer> userIds) {
		// TODO Auto-generated method stub
		
	}

	public void addStepsProcessersByUserId(Integer stepId, Integer relationId,
			Integer userId, Boolean flag) {
		// TODO Auto-generated method stub
		
	}

	public List<StepManyProcessers> searchStepManyProcessers(
			Integer stepsProcessersId) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
