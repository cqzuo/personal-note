package com.decg.step;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class FlowsStepsPK {

	/** ����id **/
	@Column(nullable=false)
	private Integer flow_id;
	/** ����id **/
	@Column(nullable=false)
	private String step_id;
	/** ����id **/
	public Integer getFlow_id() {
		return flow_id;
	}
	/** ����id **/
	public void setFlow_id(Integer flow_id) {
		this.flow_id = flow_id;
	}
	/** ����id **/
	public String getStep_id() {
		return step_id;
	}
	/** ����id **/
	public void setStep_id(String step_id) {
		this.step_id = step_id;
	}
}
