/**
		* �ļ�����StepType.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-23
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.step;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�StepTypeAndCondition
 * ���������������ͺ�����ʵ����
 * �����ˣ�������
 * ����ʱ�䣺2011-3-23 ����10:00:34
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-23 ����10:00:34
 * �޸ı�ע��
 * @version
 *
 */

@Entity
@Table(name = "StepTypeAndCondition")
public class StepTypeAndCondition {
	/**
	 * id
	 * @Id
	 * @Column(length = 2, nullable = false, unique = true)
	 */
	@Id
	@Column(length = 2, nullable = false, unique = true)
	private String id = null;
	/**
	 * ����
	 * @Column(length = 20, nullable = false, unique = true)
	 */
	@Column(length = 20, nullable = false, unique = true)
	private String name = null;
	/**
	 * ��ID
	 * @Column(length = 2)
	 */
	@Column(length = 2)
	private String parentId = null;

	
	
	/**
	 * id
	 * @Id
	 * @Column(length = 2, nullable = false, unique = true)
	 */
	public String getId() {
		return id;
	}
	/**
	 * id
	 * @Id
	 * @Column(length = 2, nullable = false, unique = true)
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * ��ID
	 * @Column(length = 2)
	 */
	public String getParentId() {
		return parentId;
	}
	/**
	 * ��ID
	 * @Column(length = 2)
	 */
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	/**
	 * ����
	 * @Column(length = 20, nullable = false, unique = true)
	 */
	public String getName() {
		return name;
	}
	/**
	 * ����
	 * @Column(length = 20, nullable = false, unique = true)
	 */
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StepTypeAndCondition other = (StepTypeAndCondition) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
}
