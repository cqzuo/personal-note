package com.decg.step;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.decg.relation.Relation;
import com.decg.user.User;

/**
 * ���账����ά����
 */
@Entity
public class StepsProcessers implements Serializable {
	private static final long serialVersionUID = 5285918983657516307L;
	/** id **/
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	/** ��Ӧ�Ĳ��� **/
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "step_id")
	private Step step;
	/** ��Ӧ�Ĵ����� **/
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id")
	private User user;
	/** ��Ӧ��Ա����ϵ **/
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "relation_id")
	private Relation relation;
	/** ���˴���ʵ�壬����ɾ�� **/
	@OneToMany(cascade = CascadeType.REMOVE, mappedBy = "stepsProcessers")
	private Set<StepManyProcessers> stepManyProcesserses = new HashSet<StepManyProcessers>();

	/** id **/
	public Integer getId() {
		return id;
	}

	/** id **/
	public void setId(Integer id) {
		this.id = id;
	}

	/** ��Ӧ�Ĳ��� **/
	public Step getStep() {
		return step;
	}

	/** ��Ӧ�Ĳ��� **/
	public void setStep(Step step) {
		this.step = step;
	}

	/** ��Ӧ�Ĵ����� **/
	public User getUser() {
		return user;
	}

	/** ��Ӧ�Ĵ����� **/
	public void setUser(User user) {
		this.user = user;
	}

	/** ��Ӧ��Ա����ϵ **/
	public Relation getRelation() {
		return relation;
	}

	/** ��Ӧ��Ա����ϵ **/
	public void setRelation(Relation relation) {
		this.relation = relation;
	}

	/** ���˴���ʵ�壬����ɾ�� **/
	public Set<StepManyProcessers> getStepManyProcesserses() {
		return stepManyProcesserses;
	}

	/** ���˴���ʵ�壬����ɾ�� **/
	public void setStepManyProcesserses(
			Set<StepManyProcessers> stepManyProcesserses) {
		this.stepManyProcesserses = stepManyProcesserses;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StepsProcessers other = (StepsProcessers) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
