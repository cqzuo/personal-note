package com.decg.step.action;

import java.util.LinkedHashMap;
import javax.annotation.Resource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import com.decg.base.common.util.ObjectArrayToViewService;
import com.decg.step.Flow;
import com.decg.step.FlowsSteps;
import com.decg.step.Step;
import com.decg.step.service.FlowsStepsService;
import com.decg.step.service.FlowsStepsViewService;
import com.decg.step.service.StepService;
import com.decg.step.view.FlowStepView;
import com.opensymphony.xwork2.ActionContext;
/**
 * 
		*
		* ��Ŀ���ƣ�decgnew
		* �����ƣ�FlowsStepsAction
		* �����������̲������
		* �����ˣ�Administrator
		* ����ʱ�䣺2011-5-20 ����09:09:11
		* �޸��ˣ�Administrator
		* �޸�ʱ�䣺2011-5-20 ����09:09:11
		* �޸ı�ע��
		* @version
		*
 */
@Controller
@Scope("prototype")
public class FlowsStepsAction {

	@Resource(name = "flowsStepsViewServiceBean")
	private FlowsStepsViewService flowsStepsViewService;
	@Resource(name = "flowsStepsServiceBean")
	private FlowsStepsService flowsStepsService;
	@Resource(name = "stepServiceBean")
	private StepService stepService;
	@Resource(name = "objectArrayToViewServiceBean")
	private ObjectArrayToViewService objectArrayToViewService;
	private Step step = new Step();
	private Flow flow = new Flow();
	private FlowsSteps flowsSteps = new FlowsSteps();
	private Boolean updateOrNot;

	/**
	 * ͨ�����̺ż�����������еģ����ʣ����裬����
	 * 
	 */
	public String execute() {
		ActionContext.getContext().put("flowStepViewList",objectArrayToViewService.parseToList(FlowStepView.class, flowsStepsViewService.getFlowSteps(this.flow.getFlowId())));
		ActionContext.getContext().put("flowId", this.flowsSteps.getFlow_id());
		return "flowssteps_success";
	}

	/**
	 * ���Ӳ���
	 * 
	 */
	public String addUI() {
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("stepId", "asc");
		ActionContext.getContext().put("stepAllList",stepService.getScrollData(orderBy).getResultList());
		return "addFlowUIssteps_success";
	}

	/**
	 * �������̲���
	 */
	public String save() {
		this.flow.setFlowId(this.flowsSteps.getFlow_id());

		flowsStepsService.save(this.flowsSteps);
		ActionContext.getContext().put("flowId", this.flowsSteps.getFlow_id());
		return "saveflowssteps_success";
	}

	/**
	 * �õ��޸�ǰ��Ҫ�Ĳ��������ݵȣ� �޸ġ�ɾ���������ֻ���м������
	 */
	public String updateUI() {
		FlowsSteps fs = flowsStepsService.find(this.flowsSteps.getFlowsSteps_Id());
		this.flow.setFlowId(fs.getFlow_id());
		ActionContext.getContext().put("updateOrNot", true);
		LinkedHashMap<String, String> orderBy1 = new LinkedHashMap<String, String>();
		orderBy1.put("stepId", "asc");
		ActionContext.getContext().put("stepAllList",stepService.getScrollData(orderBy1).getResultList());
		
		ActionContext.getContext().put("entity",fs);
		return "updateUI_success";
	}
	
	/**
	 * �����ݽ����޸�
	 */
	public String update() {
		this.flow.setFlowId(this.flowsSteps.getFlow_id());
		flowsStepsService.update(this.flowsSteps);
		return "update_success";
	}

	/**
	 * ɾ�����̲����¼
	 * @return FlowsStepsAction.action?flowsSteps.flow_id=${flowId}
	 */
	public String delete(){
		flowsSteps = flowsStepsService.find(this.flowsSteps.getFlowsSteps_Id());
		this.flow.setFlowId(flowsSteps.getFlow_id());
		flowsStepsService.delete("o.flowsSteps_Id = ?1", flowsSteps.getFlowsSteps_Id());
		return "delete_success";
	}
	/**
	 * step
	 *
	 * @return the step
	 */
	
	public Step getStep() {
		return step;
	}

	/**
	 * @param step the step to set
	 */
	public void setStep(Step step) {
		this.step = step;
	}

	/**
	 * flowsSteps
	 *
	 * @return the flowsSteps
	 */
	
	public FlowsSteps getFlowsSteps() {
		return flowsSteps;
	}

	/**
	 * @param flowsSteps the flowsSteps to set
	 */
	public void setFlowsSteps(FlowsSteps flowsSteps) {
		this.flowsSteps = flowsSteps;
	}

	/**
	 * flow
	 *
	 * @return the flow
	 */
	
	public Flow getFlow() {
		return flow;
	}

	/**
	 * @param flow the flow to set
	 */
	public void setFlow(Flow flow) {
		this.flow = flow;
	}

	/**
	 * updateOrNot
	 *
	 * @return the updateOrNot
	 */
	
	public Boolean getUpdateOrNot() {
		return updateOrNot;
	}

	/**
	 * @param updateOrNot the updateOrNot to set
	 */
	public void setUpdateOrNot(Boolean updateOrNot) {
		this.updateOrNot = updateOrNot;
	}
	
	
}
