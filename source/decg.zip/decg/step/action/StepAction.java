/**
		* �ļ�����StepAction.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-3-22
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.step.action;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.QueryResult;
import com.decg.step.Stage;
import com.decg.step.Step;
import com.decg.step.StepTypeAndCondition;
import com.decg.step.service.StageService;
import com.decg.step.service.StepService;
import com.decg.step.service.StepTypeAndConditionService;
import com.opensymphony.xwork2.ActionContext;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�StepAction
 * ���������������
 * �����ˣ�������
 * ����ʱ�䣺2011-3-22 ����11:02:35
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-3-22 ����11:02:35
 * �޸ı�ע��
 * @version
 *
 */

@Controller
@Scope("prototype")
public class StepAction {

	@Resource(name = "stepServiceBean")
	private StepService stepService;
	@Resource(name = "stageServiceBean")
	private StageService stageService;
	@Resource(name = "stepTypeAndConditionServiceBean")
	private StepTypeAndConditionService stepTypeAndConditionService;
	
	private Step step = new Step();
	
	/**
	 * �����б�
	 * return	/WEB-INF/page/step/stepList.jsp
	 */
	public String execute() {
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("stepId", "asc");
		QueryResult<Step> qr = stepService.getScrollData(orderBy);
		ActionContext.getContext().put("stepList", qr.getResultList());
		return "stepList_success";
	}
	
	/**
	 * ת�����ӽ���
	 * return	/WEB-INF/page/step/addStepUI.jsp
	 */
	public String addStepUI() {
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("stageId", "asc");
		QueryResult<Stage> qr = stageService.getScrollData(orderBy);
		ActionContext.getContext().put("stagelist", qr.getResultList());
		
		//������������
		orderBy.clear();
		orderBy.put("id", "asc");
		QueryResult<StepTypeAndCondition> queryResult = stepTypeAndConditionService.getScrollData("o.parentId is null", null, orderBy);
		ActionContext.getContext().put("stepTypeList", queryResult.getResultList());
		return "addStepUI_success";
	}
	
	/**
	 * ajax���ݲ�������id��ѯ���������б�
	 * return	/WEB-INF/page/step/includechild.jsp
	 */
	public String findChildren() {
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("id", "asc");
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(step.getStepTypeId());
		QueryResult<StepTypeAndCondition> qr = stepTypeAndConditionService.getScrollData("o.parentId = ?1", whereParam, orderBy);
		ActionContext.getContext().put("typeConditionList", qr.getResultList());
		return "findChildren_success";
	}
	
	/**
	 * ���沽��
	 * return	StepAction.action
	 */
	public String addStep() {
		stepService.save(step);
		return "goList_success";
	}
	
	/**
	 * ɾ������
	 * return	StepAction.action
	 */
	public String deleteStep() {
		stepService.delete("o.stepId = ?1", step.getStepId());
		return "goList_success";
	}
	
	/**
	 * ������½���
	 * return	/WEB-INF/page/step/updateStepUI.jsp
	 */
	public String updateStepUI() {
		Step stepInfo = stepService.find(step.getStepId());
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("stageId", "asc");
		QueryResult<Stage> qr = stageService.getScrollData(orderBy);
		ActionContext.getContext().put("stagelist", qr.getResultList());
		ActionContext.getContext().put("stepEntity", stepInfo);
		orderBy.clear();
		orderBy.put("id", "asc");
		QueryResult<StepTypeAndCondition> queryResult = stepTypeAndConditionService.getScrollData("o.parentId is null", null, orderBy);
		ActionContext.getContext().put("stepTypeList", queryResult.getResultList());
		
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(stepInfo.getStepTypeId());
		queryResult = stepTypeAndConditionService.getScrollData("o.parentId = ?1", whereParam, orderBy);
		ActionContext.getContext().put("typeConditionList", queryResult.getResultList());
		
		ActionContext.getContext().put("updateOrNot", true);
		return "updateStepUI_success";
	}
	
	/**
	 * ���²�����Ϣ
	 * return	StepAction.action
	 */
	public String updateStep() {
		stepService.update(step);
		return "goList_success";
	}

	public Step getStep() {
		return step;
	}

	public void setStep(Step step) {
		this.step = step;
	}
	
}
