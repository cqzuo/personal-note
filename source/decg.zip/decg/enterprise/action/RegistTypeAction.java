package com.decg.enterprise.action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.enterprise.RegistType;
import com.decg.enterprise.service.RegistTypeService;
import com.opensymphony.xwork2.ActionContext;

@Controller
@Scope("prototype")
public class RegistTypeAction {
	@Resource(name = "registTypeServiceBean")
	private RegistTypeService registTypeService;
	private RegistType registType;

	/**
	 * ע�������б�
	 * @return	/WEB-INF/page/registType/registTypeList.jsp
	 */
	public String execute() {
		ActionContext.getContext().put("registTypeList", registTypeService.getScrollData(null));
		return "registTypeList_success";
	}
	
	/**
	 * ת�����ӽ���
	 * @return	/WEB-INF/page/registType/addRegistUI.jsp
	 */
	public String addUI() {
		return "addUI_success";
	}
	
	/**
	 * ����ע������
	 * @return	RegistTypeAction.action
	 */
	public String add() {
		registTypeService.save(registType);
		return "goList_success";
	}
	
	/**
	 * ɾ��ע������
	 * @return	RegistTypeAction.action
	 */
	public String delete() {
		registTypeService.delete(RegistType.class, registType.getId());
		return "goList_success";
	}
	
	/**
	 * ������½���
	 * @return	/WEB-INF/page/registType/updateRegistTypeUI.jsp
	 */
	public String updateUI() {
		ActionContext.getContext().put("registTypeEntity", registTypeService.find(registType.getId()));
		return "updateUI_success";
	}
	
	/**
	 * ����ע������
	 * @return	RegistTypeAction.action
	 */
	public String update() {
		registTypeService.update(registType);
		return "goList_success";
	}
	
	public RegistType getRegistType() {
		return registType;
	}

	public void setRegistType(RegistType registType) {
		this.registType = registType;
	}
}
