package com.decg.enterprise.action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.enterprise.EnterpriseType;
import com.decg.enterprise.service.EnterpriseTypeService;
import com.opensymphony.xwork2.ActionContext;

@Controller
@Scope("prototype")
public class EnterpriseTypeAction {
	@Resource(name="enterpriseTypeServiceBean")
	private EnterpriseTypeService enterpriseTypeService;
	
	private EnterpriseType enterpriseType;

	/**
	 * ��ȡ������ҵ��ҵ����
	 * @return	���ؽ��棺/WEB-INF/page/enterpriseType/enterpriseTypeList.jsp
	 */
	public String execute() {
		ActionContext.getContext().put("enterpriseTypeList", enterpriseTypeService.getScrollData(null));
		return "enterpriseTypeList_success";
	}
	
	/**
	 * ת��������ҵ���ͽ���
	 * @return	���ؽ��棺/WEB-INF/page/enterpriseType/addEnterpriseTypeUI.jsp
	 */
	public String addUI() {
		return "addUI_success";
	}
	
	/**
	 * ������ҵ����
	 * @return ���ؽ��棺EnterpriseTypeAction.action
	 */
	public String add() {
		enterpriseTypeService.save(enterpriseType);
		return "goList_success";
	}
	
	/**
	 * ɾ����ҵ����
	 * @return ���ؽ��棺EnterpriseTypeAction.action
	 */
	public String delete() {
		String whereStatement = "o.id = ?1";
		enterpriseTypeService.delete(EnterpriseType.class, whereStatement, this.enterpriseType.getId());
		return "goList_success";
	}
	
	/**
	 * ������½���
	 * @return	���ؽ��棺/WEB-INF/page/enterpriseType/updateEnterpriseTypeUI.jsp
	 */
	public String updateUI() {
		ActionContext.getContext().put("enterpriseTypeEntity", enterpriseTypeService.find(this.enterpriseType.getId()));
		return "updateUI_success";
	}
	
	/**
	 * ������ҵ��ҵ����
	 * @return
	 */
	public String update() {
		enterpriseTypeService.update(enterpriseType);
		return "goList_success";
	}
	
	public EnterpriseType getEnterpriseType() {
		return enterpriseType;
	}

	public void setEnterpriseType(EnterpriseType enterpriseType) {
		this.enterpriseType = enterpriseType;
	}
}
