package com.decg.enterprise.service;

import com.decg.base.DAO;
import com.decg.enterprise.EnterpriseCD;

public interface EnterpriseCDService extends DAO<EnterpriseCD> {
}
