package com.decg.enterprise.service.bean;

import org.springframework.stereotype.Service;
import com.decg.base.DaoSupport;
import com.decg.enterprise.EnterpriseCD;
import com.decg.enterprise.service.EnterpriseCDService;

@Service
public class EnterpriseCDServiceBean extends DaoSupport<EnterpriseCD> implements EnterpriseCDService{

}
