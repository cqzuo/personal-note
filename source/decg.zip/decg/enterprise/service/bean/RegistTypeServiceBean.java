package com.decg.enterprise.service.bean;

import org.springframework.stereotype.Service;
import com.decg.base.DaoSupport;
import com.decg.enterprise.RegistType;
import com.decg.enterprise.service.RegistTypeService;

/**
 *	ע������ҵ���߼��ӿڵ�ʵ��
 */
@Service
public class RegistTypeServiceBean extends DaoSupport<RegistType> implements
		RegistTypeService {

}
