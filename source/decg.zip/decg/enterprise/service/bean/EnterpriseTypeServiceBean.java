package com.decg.enterprise.service.bean;

import org.springframework.stereotype.Service;

import com.decg.base.DaoSupport;
import com.decg.enterprise.EnterpriseType;
import com.decg.enterprise.service.EnterpriseTypeService;

@Service
public class EnterpriseTypeServiceBean extends DaoSupport<EnterpriseType> implements
		EnterpriseTypeService {

}
