package com.decg.enterprise.service.bean;

import org.springframework.stereotype.Service;
import com.decg.base.DaoSupport;
import com.decg.enterprise.Enterprise;
import com.decg.enterprise.service.EnterpriseService;

@Service
public class EnterpriseServiceBean extends DaoSupport<Enterprise> implements EnterpriseService {

}
