package com.decg.enterprise;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * ע������ʵ��
 */
@Entity
public class RegistType implements Serializable {
	private static final long serialVersionUID = -1329702065003141462L;
	/** id **/
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	/** ע���������� **/
	@Column(length = 32, nullable = false, unique = true)
	private String name;

	/** id **/
	public Integer getId() {
		return id;
	}

	/** id **/
	public void setId(Integer id) {
		this.id = id;
	}

	/** ע���������� **/
	public String getName() {
		return name;
	}

	/** ע���������� **/
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RegistType other = (RegistType) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
