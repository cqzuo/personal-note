package com.decg.enterprise;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.decg.project.Project;


/**
 * ��ҵ��Ϣʵ��
 */
@Entity
public class Enterprise implements Serializable {
	private static final long serialVersionUID = 2408984761217775963L;
	/** id **/
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	/** ��ҵ��� **/
	@Column(length = 10)
	private String enterpriseNo;
	/** ��ҵȫ�� **/
	@Column(length = 60, nullable = false, unique = true)
	private String name;
	/** ������ҵ���� **/
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
	@JoinColumn(name = "enterpriseType_id")
	private EnterpriseType enterpriseType;
	/** ע������ **/
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
	@JoinColumn(name = "registType_id")
	private RegistType registType;
	/** ע���ַ **/
	@Column
	private String registAddress;
	/** ע��ʱ�� **/
	@Column(length = 20)
	private String registTime;
	/** �������� **/
	@Column
	private String legalPersonName;
	/** ��ϵ�� **/
	@Column
	private String contacterName;
	/** ��ϵ�绰 **/
	@Column
	private String contactPhone;
	/** ע���ʱ� **/
	@Column
	private Double registrationCapital;

	/** ��Ӧ����Ŀ�б� **/
	@OneToMany(cascade = CascadeType.REFRESH, mappedBy = "enterprise")
	private Set<Project> projects = new HashSet<Project>();

	/** id **/
	public Integer getId() {
		return id;
	}

	/** id **/
	public void setId(Integer id) {
		this.id = id;
	}

	/** ��ҵ��� **/
	public String getEnterpriseNo() {
		return enterpriseNo;
	}

	/** ��ҵ��� **/
	public void setEnterpriseNo(String enterpriseNo) {
		this.enterpriseNo = enterpriseNo;
	}

	/** ��ҵȫ�� **/
	public String getName() {
		return name;
	}

	/** ��ҵȫ�� **/
	public void setName(String name) {
		this.name = name;
	}

	/** ������ҵ���� **/
	public EnterpriseType getEnterpriseType() {
		return enterpriseType;
	}

	/** ������ҵ���� **/
	public void setEnterpriseType(EnterpriseType enterpriseType) {
		this.enterpriseType = enterpriseType;
	}

	/** ע������ **/
	public RegistType getRegistType() {
		return registType;
	}

	/** ע������ **/
	public void setRegistType(RegistType registType) {
		this.registType = registType;
	}

	/** ע���ַ **/
	public String getRegistAddress() {
		return registAddress;
	}

	/** ע���ַ **/
	public void setRegistAddress(String registAddress) {
		this.registAddress = registAddress;
	}

	/** ע��ʱ�� **/
	public String getRegistTime() {
		return registTime;
	}

	/** ע��ʱ�� **/
	public void setRegistTime(String registTime) {
		this.registTime = registTime;
	}

	/** �������� **/
	public String getLegalPersonName() {
		return legalPersonName;
	}

	/** �������� **/
	public void setLegalPersonName(String legalPersonName) {
		this.legalPersonName = legalPersonName;
	}

	/** ��ϵ�� **/
	public String getContacterName() {
		return contacterName;
	}

	/** ��ϵ�� **/
	public void setContacterName(String contacterName) {
		this.contacterName = contacterName;
	}

	/** ��ϵ�绰 **/
	public String getContactPhone() {
		return contactPhone;
	}

	/** ��ϵ�绰 **/
	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	/** ע���ʱ� **/
	public Double getRegistrationCapital() {
		return registrationCapital;
	}

	/** ע���ʱ� **/
	public void setRegistrationCapital(Double registrationCapital) {
		this.registrationCapital = registrationCapital;
	}

	/** ��Ӧ����Ŀ�б� **/
	public Set<Project> getProjects() {
		return projects;
	}

	/** ��Ӧ����Ŀ�б� **/
	public void setProjects(Set<Project> projects) {
		this.projects = projects;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Enterprise other = (Enterprise) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
