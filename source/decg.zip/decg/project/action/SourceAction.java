package com.decg.project.action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.project.Source;
import com.decg.project.service.SourceService;
import com.opensymphony.xwork2.ActionContext;

/**
 * ��Ŀ��ԴAction
 */
@Controller
@Scope("prototype")
public class SourceAction {
	@Resource(name = "sourceServiceBean")
	private SourceService sourceService;
	private Source source;
	
	/**
	 * ��ȡ������Ŀ��Դ
	 * @return	/WEB-INF/page/source/sourceList.jsp
	 */
	public String execute() {
		ActionContext.getContext().put("sourceList", sourceService.getScrollData(null));
		return "sourceList_success";
	}
	
	/**
	 * ������������
	 * @return	/WEB-INF/page/source/addSourceUI.jsp
	 */
	public String addUI () {
		return "addUI_success";
	}
	
	/**
	 * ������Ŀ��Դ
	 * @return	SourceAction.action
	 */
	public String add() {
		sourceService.save(source);
		return "goList_success";
	}
	
	/**
	 * ɾ����Ŀ��Դ
	 * @return	SourceAction.action
	 */
	public String delete() {
		sourceService.delete(Source.class, source.getId());
		return "goList_success";
	}
	
	/**
	 * ������½���
	 * @return	/WEB-INF/page/source/updateSourceUI.jsp
	 */
	public String updateUI() {
		ActionContext.getContext().put("sourceEntity", sourceService.find(source.getId()));
		return "updateUI_success";
	}
	
	/**
	 * ������Ŀ��Դ
	 * @return	SourceAction.action
	 */
	public String update() {
		sourceService.update(source);
		return "goList_success";
	}
	
	public Source getSource() {
		return source;
	}
	public void setSource(Source source) {
		this.source = source;
	}
	
}
