package com.decg.project.service;

import com.decg.base.DAO;
import com.decg.project.Source;

/**
 *	��Ŀ��Դ�߼��ӿ�
 */
public interface SourceService extends DAO<Source>{
}
