package com.decg.project.service;

import com.decg.base.DAO;
import com.decg.project.Project;

public interface ProjectService extends DAO<Project> {
}
