package com.decg.project.service.bean;

import org.springframework.stereotype.Service;
import com.decg.base.DaoSupport;
import com.decg.project.Project;
import com.decg.project.service.ProjectService;

@Service
public class ProjectServiceBean extends DaoSupport<Project> implements ProjectService {
}
