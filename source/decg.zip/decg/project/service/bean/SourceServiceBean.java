package com.decg.project.service.bean;

import org.springframework.stereotype.Service;
import com.decg.base.DaoSupport;
import com.decg.project.Source;
import com.decg.project.service.SourceService;

@Service
public class SourceServiceBean extends DaoSupport<Source> implements SourceService {

}
