/**
		* �ļ�����LeaderCheckService.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-5-19
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.assessment.service.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.decg.assessment.OfficeSchedule;
import com.decg.assessment.service.ApproveService;
import com.decg.base.DaoSupport;
import com.decg.base.common.DECG_cons;
import com.decg.consulation.SBHSuggestion;
import com.decg.consulation.Suggestion;
import com.decg.consulation.view.ProjectView;
import com.decg.step.Step;
import com.decg.step.service.FlowsStepsService;
import com.decg.task.Task;
import com.decg.user.User;
import com.opensymphony.xwork2.ActionContext;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�OfficeScheduleServiceBean
 * ���������󱣻��������������ύ�ӿ�ʵ����
 * �����ˣ�
 * ����ʱ�䣺2011-5-19 ����02:01:48
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-5-19 ����02:01:48
 * �޸ı�ע��
 * @version
 *
 */

@Service
public class ApproveServiceBean extends DaoSupport<ProjectView>implements
ApproveService {
	@Resource(name = "flowsStepsServiceBean")
	private FlowsStepsService flowsStepsService;
	
	@Transactional
	public void submit() {
	}

	@SuppressWarnings("unchecked")
	public List<User> getAllSBHMembers(){
		List<User> users = new ArrayList<User>();
		Query query = em.createQuery("select u from User u where u.shenBaoHuiMumber = 'YES'");
		users = query.getResultList();
		if(users.size()>0){
			return users;
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public OfficeSchedule getOfficeScheduleByProjectNO(String projectNo){
		OfficeSchedule officeSchedule = new OfficeSchedule();
		Query query = em.createQuery("select o from OfficeSchedule o where o.projectNo =?1");
		query.setParameter(1, projectNo);
		List<Object> lists = query.getResultList();
		if(lists.size()>0){
			officeSchedule = (OfficeSchedule)lists.get(0);
		}else{
			officeSchedule = null;
		}
		return officeSchedule;
	}
	
	@SuppressWarnings("unchecked")
	public Suggestion getSuggestionByProjectNo(String projectNo){
		Suggestion suggestion = new Suggestion();
		Query query = em.createQuery("select s from Suggestion s,Project p where s.project_id = p.id  and p.projectNo=?1");
		query.setParameter(1, projectNo);
		List<Object> lists = query.getResultList();
		if(lists.size()>0){
			suggestion = (Suggestion)lists.get(0);
		}else{
			suggestion = null;
		}
		return suggestion;
	}
	
	@SuppressWarnings("unchecked")
	public Task getTaskByProjectNo(String projectNo){
		Task task = new Task();
		Query query = em.createQuery("select t from Project p,Task t where p.id = t.project_id and p.projectNo=?1");
		query.setParameter(1, projectNo);
		List<Object> lists = query.getResultList();
		if(lists.size()>0){
			task = (Task)lists.get(0);
		}else{
			task = null;
		}
		return task;
	}
	
	public List<SBHSuggestion> createSBHSuggestion(Map<String,String> map,Integer suggestion_id){
		List<SBHSuggestion> sBHSuggestions = new ArrayList<SBHSuggestion>();
		String stats = map.get("stats");
		String userIds = map.get("userIds");
		String suggestions = map.get("suggestions");
		String  stat[] = stats.split(",");
		String  userId[] = userIds.split(",");
		String  suggestion[] = suggestions.split(",");
		Integer length = stat.length;
		for (int i = 0; i < length; i++) {
			SBHSuggestion sBHSuggestion = new SBHSuggestion();
			sBHSuggestion.setSuggestion_id(suggestion_id);
			sBHSuggestion.setSecurityMemberDateTime(new Date());
			sBHSuggestion.setSecurityMemberName(userId[i]);
			sBHSuggestion.setSecurityMemberState(stat[i]);
			sBHSuggestion.setSecurityMemberSuggestion(suggestion[i]);
			em.persist(sBHSuggestion);
			sBHSuggestions.add(sBHSuggestion);
		}
		return sBHSuggestions;
	}
	
	public void submit(Suggestion suggestion, Task task,List<SBHSuggestion> suggestions,ProjectView projectView){
		// ����suggestion����������SBHSuggestion
		for (Iterator<SBHSuggestion> iterator = suggestions.iterator(); iterator.hasNext();) {
			SBHSuggestion sBHSuggestion = (SBHSuggestion) iterator.next();
			sBHSuggestion.setSuggestion(suggestion);
		}
		em.merge(suggestion);
		//��������task
		User user = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		Step nextStep = flowsStepsService.nextStep(Integer.parseInt(DECG_cons.zcshlc), task.getStep_id());
		task.setContent("��Ŀ[" + projectView.getProjectNo() + " " + projectView.getEnterpriseName() + "]���󱣻���������������ɣ���������" + nextStep.getStepName());
		task.setFromWho(user.getRealName());
		String ApproveAction = DECG_cons.ApproveAction.replace("#1", projectView.getProjectNo());
		task.setProcessURL(ApproveAction);
		task.setSubmitTime(new Date());
		task.setStep_id(nextStep.getStepId());
	}
}
