/**
		* �ļ�����LeaderCheckService.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-5-19
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.assessment.service.bean;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.decg.assessment.OfficeSchedule;
import com.decg.assessment.service.OfficeScheduleService;
import com.decg.base.DaoSupport;
import com.decg.base.common.DECG_cons;
import com.decg.consulation.view.ProjectView;
import com.decg.step.Step;
import com.decg.step.service.FlowsStepsService;
import com.decg.task.Task;
import com.decg.user.User;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�OfficeScheduleServiceBean
 * ���������󱣻����鰲���ϻ��ύ�ӿ�ʵ����
 * �����ˣ�
 * ����ʱ�䣺2011-5-19 ����02:01:48
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-5-19 ����02:01:48
 * �޸ı�ע��
 * @version
 *
 */

@Service
public class OfficeScheduleServiceBean extends DaoSupport<ProjectView>implements
OfficeScheduleService {
	@Resource(name = "flowsStepsServiceBean")
	private FlowsStepsService flowsStepsService;
	
	@SuppressWarnings("unchecked")
	@Transactional
	public void submit(List<ProjectView> projectViews,User user,OfficeSchedule officeSchedule) {
		Integer indexNo = 0;
		for (Iterator iterator = projectViews.iterator(); iterator.hasNext();) {
			ProjectView projectView= (ProjectView) iterator.next();
			Task task = em.find(Task.class, projectView.getTask_id());
			Step nextStep = flowsStepsService.nextStep(Integer.parseInt(DECG_cons.zcshlc), task.getStep_id());
			task.setContent("��Ŀ[" + projectView.getProjectNo() + " " + projectView.getEnterpriseName() + "]���󱣻������ϻᰲ����ɣ���������" + nextStep.getStepName());
			task.setFromWho(user.getRealName());
			String ApproveAction = DECG_cons.ApproveAction.replace("#1", projectView.getProjectNo());
			task.setProcessURL(ApproveAction);
			task.setSubmitTime(new Date());
			task.setStep_id(nextStep.getStepId());
			officeSchedule.setProjectNo(projectView.getProjectNo());
			officeSchedule.setOperatorId(user.getUserId());
			officeSchedule.setItemType(DECG_cons.zcshlx.toString());
			officeSchedule.setEntipriseName(projectView.getEnterpriseName());
			officeSchedule.setIndexNo(String.valueOf(++indexNo));
		}
		em.persist(officeSchedule);
	}

	@SuppressWarnings("unchecked")
	public Integer	getOfficenumber(){
		Integer officeNumber;
	    Query query = em.createQuery("select o.officenumber from OfficeSchedule o order by o.officenumber desc");
	    List<Object> lists = query.getResultList();
	    if(lists.size()>0){
	    	officeNumber = (Integer)lists.get(0);
	    }else{
	    	officeNumber = 0;
	    }
		return officeNumber+1;
	}
}
