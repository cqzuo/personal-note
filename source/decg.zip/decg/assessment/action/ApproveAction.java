package com.decg.assessment.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import com.decg.assessment.service.ApproveService;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.util.ObjectArrayToViewService;
import com.decg.consulation.SBHSuggestion;
import com.decg.consulation.Suggestion;
import com.decg.consulation.service.ProjectCommonService;
import com.decg.consulation.view.ProjectView;
import com.decg.task.Task;
import com.decg.user.User;
import com.opensymphony.xwork2.ActionContext;

/**
 * ��������
 */
@Controller
@Scope("prototype")
public class ApproveAction {
	@Resource(name = "objectArrayToViewServiceBean")
	private ObjectArrayToViewService objectArrayToViewService;
	@Resource(name = "projectCommonServiceBean")
	private ProjectCommonService projectCommonService;
	@Resource(name = "approveServiceBean")
	private ApproveService approveService;
	
	
	private ProjectView projectView = new ProjectView();
	private String  stats = "";
	private String  userIds = "";
	private String  suggestions = "";
	/**
	 * ���������ύ
	 * @return
	 */
	public String submit(){
		Suggestion suggestion = approveService.getSuggestionByProjectNo(this.projectView.getProjectNo());
		Task task = approveService.getTaskByProjectNo(this.projectView.getProjectNo());
		List<SBHSuggestion> sBHSuggestions = new ArrayList<SBHSuggestion>();
		Map<String,String> sbhs = new HashMap<String,String>();
		sbhs.put("stats", stats);
		sbhs.put("userIds", userIds);
		sbhs.put("suggestions", suggestions);
		sBHSuggestions = approveService.createSBHSuggestion(sbhs,suggestion.getId());
		approveService.submit(suggestion,task,sBHSuggestions,projectView);
		return "approveSubmit";
	}
	
	/**
	 * ����������Ŀ ��ض������
	 * @param condition 
	 * @return 
	 */
	public String execute(){
		User user = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		List<Object> resultList = projectCommonService.getProjectCommons(user.getUserId(), DECG_cons.mstb, this.projectView.getFlow_id());
		List<ProjectView> projectViews =  objectArrayToViewService.parseToList(ProjectView.class, resultList);
		ActionContext.getContext().put("approveList", projectViews);
		return "approveList";
	}
	
	/**
	 * ��ʾ����������ϸҳ��
	 * @return
	 */
	public String detail(){
		//��ѯ��˻���Ϣ
		ActionContext.getContext().put("officeschedule", approveService.getOfficeScheduleByProjectNO(this.projectView.getProjectNo()));
		//��ѯ���е��󱣻��Ա����
		ActionContext.getContext().put("shbMemberList", approveService.getAllSBHMembers());
		return "approvedeTail";
	}

	/**
	 * projectView
	 *
	 * @return the projectView
	 */
	
	public ProjectView getProjectView() {
		return projectView;
	}

	/**
	 * @param projectView the projectView to set
	 */
	public void setProjectView(ProjectView projectView) {
		this.projectView = projectView;
	}

	/**
	 * stats
	 *
	 * @return the stats
	 */
	
	public String getStats() {
		return stats;
	}

	/**
	 * userIds
	 *
	 * @return the userIds
	 */
	
	public String getUserIds() {
		return userIds;
	}

	/**
	 * suggestions
	 *
	 * @return the suggestions
	 */
	
	public String getSuggestions() {
		return suggestions;
	}

	/**
	 * @param stats the stats to set
	 */
	public void setStats(String stats) {
		this.stats = stats;
	}

	/**
	 * @param userIds the userIds to set
	 */
	public void setUserIds(String userIds) {
		this.userIds = userIds;
	}

	/**
	 * @param suggestions the suggestions to set
	 */
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}
}
