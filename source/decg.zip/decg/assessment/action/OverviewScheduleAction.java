package com.decg.assessment.action;

import java.util.List;
import javax.annotation.Resource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.util.ObjectArrayToViewService;
import com.decg.consulation.Suggestion;
import com.decg.consulation.service.ProjectCommonService;
import com.decg.consulation.view.ProjectView;
import com.decg.user.User;
import com.opensymphony.xwork2.ActionContext;
/**
 * 
		*
		* ��Ŀ���ƣ�decgnew
		* �����ƣ�OverviewScheduleAction
		* ���������󱣻��ճ̰���
		* �����ˣ�Administrator
		* ����ʱ�䣺2011-5-19 ����01:26:54
		* �޸��ˣ�Administrator
		* �޸�ʱ�䣺2011-5-19 ����01:26:54
		* �޸ı�ע��
		* @version
		*
 */
@Controller
@Scope("prototype")
public class OverviewScheduleAction {
	@Resource(name = "objectArrayToViewServiceBean")
	private ObjectArrayToViewService objectArrayToViewService;
	@Resource(name = "projectCommonServiceBean")
	private ProjectCommonService projectCommonService;
	
	private ProjectView projectView = new ProjectView();
	private Suggestion suggestion = new Suggestion();
	/**
	 * �󱣻��ճ̰����ύ
	 * @return
	 */
	public String submitOverviewSchedule(){
		return "overviewScheduleSubmit";
	}
	
	/**
	 * �󱣻��ճ̰��� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String execute(){
		User user = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		List<Object> resultList = projectCommonService.getProjectCommons(user.getUserId(), DECG_cons.msshrcap, this.projectView.getFlow_id());
		List<ProjectView> projectViews =  objectArrayToViewService.parseToList(ProjectView.class, resultList);
		ActionContext.getContext().put("overviewScheduleList", projectViews);
		return "overviewScheduleList";
	}
	
	/**
	 * ��ʾ�󱣻��ճ̰�����ϸҳ��
	 * @return
	 */
	public String submit(){
		
		return "officeScheduleSubmit";
	}

	/**
	 * projectView
	 *
	 * @return the projectView
	 */
	
	public ProjectView getProjectView() {
		return projectView;
	}

	/**
	 * suggestion
	 *
	 * @return the suggestion
	 */
	
	public Suggestion getSuggestion() {
		return suggestion;
	}

	/**
	 * @param projectView the projectView to set
	 */
	public void setProjectView(ProjectView projectView) {
		this.projectView = projectView;
	}

	/**
	 * @param suggestion the suggestion to set
	 */
	public void setSuggestion(Suggestion suggestion) {
		this.suggestion = suggestion;
	}
}
