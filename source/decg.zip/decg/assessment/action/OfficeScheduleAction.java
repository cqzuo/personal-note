package com.decg.assessment.action;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.assessment.OfficeSchedule;
import com.decg.assessment.service.OfficeScheduleService;
import com.decg.base.common.DECG_cons;
import com.decg.base.common.util.ObjectArrayToViewService;
import com.decg.consulation.Suggestion;
import com.decg.consulation.service.ProjectCommonService;
import com.decg.consulation.view.ProjectView;
import com.decg.user.User;
import com.opensymphony.xwork2.ActionContext;
/**
 * 
		*
		* ��Ŀ���ƣ�decgnew
		* �����ƣ�OfficeScheduleAction
		* ���������ϻ��ճ̰���
		* �����ˣ�Administrator
		* ����ʱ�䣺2011-5-19 ����01:20:02
		* �޸��ˣ�Administrator
		* �޸�ʱ�䣺2011-5-19 ����01:20:02
		* �޸ı�ע��
		* @version
		*
 */
@Controller
@Scope("prototype")
public class OfficeScheduleAction {
	@Resource(name = "objectArrayToViewServiceBean")
	private ObjectArrayToViewService objectArrayToViewService;
	@Resource(name = "projectCommonServiceBean")
	private ProjectCommonService projectCommonService;
	@Resource(name = "officeScheduleServiceBean")
	private OfficeScheduleService officeScheduleService;
	
	private ProjectView projectView = new ProjectView();
	private Suggestion suggestion = new Suggestion();
	private List<String> projectNoList = new ArrayList<String>();
	private List<String> taskIddList = new ArrayList<String>();
	private List<String> enterpriseNameList = new ArrayList<String>();
	private OfficeSchedule officeSchedule = new OfficeSchedule();
	/**
	 * ��ʾ�ϻ��ճ̰�����ϸҳ��
	 * @return
	 */
	public String detail(){
		return "officeScheduledeTail";
	}
	
	/**
	 * �ϻ��ճ̰��� ��ض������
	 * @param condition 
	 * @return 
	 */
	public String execute(){
		User user = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		List<Object> resultList = projectCommonService.getProjectCommons(user.getUserId(), DECG_cons.msshrcap, this.projectView.getFlow_id());
		List<ProjectView> projectViews =  objectArrayToViewService.parseToList(ProjectView.class, resultList);
		ActionContext.getContext().put("officescheduleList", projectViews);
		
		//ȡ���󱣻�Ĵ���
		officeSchedule.setOfficenumber(officeScheduleService.getOfficenumber());
		return "officescheduleList";
	}
	
	/**
	 * �ϻ��ճ̰����ύ
	 * @return
	 */
	public String submit(){
		User user = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		List<ProjectView> projectViews = new ArrayList<ProjectView>();
		for (int i = 0; i < this.projectNoList.size(); i++) {
			String projectNo = this.projectNoList.get(i);
			String task_id = this.taskIddList.get(i);
			String enterpriseName = this.enterpriseNameList.get(i);
			this.projectView.setProjectNo(projectNo);
			this.projectView.setTask_id(Integer.parseInt(task_id));
			this.projectView.setEnterpriseName(enterpriseName);
			projectViews.add(projectView);
		}
		officeScheduleService.submit(projectViews,user,officeSchedule);
		return "officeScheduleSubmit";
	}

	/**
	 * projectView
	 *
	 * @return the projectView
	 */
	
	public ProjectView getProjectView() {
		return projectView;
	}

	/**
	 * suggestion
	 *
	 * @return the suggestion
	 */
	
	public Suggestion getSuggestion() {
		return suggestion;
	}

	/**
	 * @param projectView the projectView to set
	 */
	public void setProjectView(ProjectView projectView) {
		this.projectView = projectView;
	}

	/**
	 * @param suggestion the suggestion to set
	 */
	public void setSuggestion(Suggestion suggestion) {
		this.suggestion = suggestion;
	}

	/**
	 * projectNoList
	 *
	 * @return the projectNoList
	 */
	
	public List<String> getProjectNoList() {
		return projectNoList;
	}

	/**
	 * taskIddList
	 *
	 * @return the taskIddList
	 */
	
	public List<String> getTaskIddList() {
		return taskIddList;
	}

	/**
	 * @param projectNoList the projectNoList to set
	 */
	public void setProjectNoList(List<String> projectNoList) {
		this.projectNoList = projectNoList;
	}

	/**
	 * @param taskIddList the taskIddList to set
	 */
	public void setTaskIddList(List<String> taskIddList) {
		this.taskIddList = taskIddList;
	}

	/**
	 * officeSchedule
	 *
	 * @return the officeSchedule
	 */
	
	public OfficeSchedule getOfficeSchedule() {
		return officeSchedule;
	}

	/**
	 * @param officeSchedule the officeSchedule to set
	 */
	public void setOfficeSchedule(OfficeSchedule officeSchedule) {
		this.officeSchedule = officeSchedule;
	}

	/**
	 * enterpriseNameList
	 *
	 * @return the enterpriseNameList
	 */
	
	public List<String> getEnterpriseNameList() {
		return enterpriseNameList;
	}

	/**
	 * @param enterpriseNameList the enterpriseNameList to set
	 */
	public void setEnterpriseNameList(List<String> enterpriseNameList) {
		this.enterpriseNameList = enterpriseNameList;
	}
}
