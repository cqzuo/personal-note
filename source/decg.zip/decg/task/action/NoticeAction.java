package com.decg.task.action;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.decg.base.QueryResult;
import com.decg.base.common.DECG_cons;
import com.decg.task.Notice;
import com.decg.task.UploadFiles;
import com.decg.task.service.NoticeService;
import com.decg.user.User;
import com.decg.user.service.UserService;
import com.opensymphony.xwork2.ActionContext;
/**
 * 
		*
		* ��Ŀ���ƣ�decgnew
		* �����ƣ�NoticeAction
		* ��������ϵͳ֪ͨ
		* �����ˣ�Administrator
		* ����ʱ�䣺2011-5-20 ����09:19:44
		* �޸��ˣ�Administrator
		* �޸�ʱ�䣺2011-5-20 ����09:19:44
		* �޸ı�ע��
		* @version
		*
 */
@Controller
@Scope("prototype")
public class NoticeAction {
	@Resource(name="noticeServiceBean")
	private NoticeService noticeService;
	@Resource(name = "userServiceBean")
	private UserService userService;
	
	private Notice notice = new Notice();
	private UploadFiles uploadFiles = new UploadFiles();
	
	private String userIds = "";
	private List<File> files = new ArrayList<File>();
	private List<String> filesFileName = new ArrayList<String>();
	
	/**
	 * ��������ϵͳ��Ϣ�б�
	 */
	public String execute() {
		noticeService.deletePastNotices();
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("id", "asc");
		QueryResult<Notice> qr = noticeService.getScrollData(orderBy);
		ActionContext.getContext().put("noticesList", qr.getResultList());
		return "noticeList_success";
	}
	
	/**
	 * ����ϵͳ��Ϣ����
	 */
	public String addNoticeUI(){
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("userId", "asc");
		QueryResult<User> users = userService.getScrollData(orderBy);
		ActionContext.getContext().put("usersList", users.getResultList());
		User u = (User) ActionContext.getContext().getSession().get(DECG_cons.USER);
		notice.setMsgMan(u.getRealName());
		return "addNoticeUI_success";
	}
	
	/**
	 * ʹ�� ajax�ж��û���������Ϣ�Ƿ����
	 */
	public void checkMsgIndate(){
		try {
			String result = "";
			long msgDate = notice.getMsgDate().getTime();
			long sysDate = new Date().getTime();
			int inDate = (int)((sysDate- msgDate) / (1000 * 60 * 60 *24));
			int msgInDate = notice.getMsgInDate();
			if (msgInDate <= inDate) {
				result = "����д�ķ�����Ϣ�Ѿ����ڣ���������д�������ڻ���Ч��!";
			}
			HttpServletResponse response = ServletActionContext.getResponse();
			response.setCharacterEncoding("utf-8");
			// ʹ��response �����Ӧ��Ϣ ��������Ŀͻ���
			response.getWriter().write(result);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}
	
	/**
	 * ����ϵͳ��Ϣ
	 * �ɹ��󷵻ص���ʾ������Ϣ�б�����
	 * @throws Exception 
	 */
	public String addNotice(){
		String rootPath = ServletActionContext.getServletContext().getRealPath("/upload");
		List<String> userIdList = new ArrayList<String>();
		if(userIds != null && !"".equals(userIds)) {
			StringBuilder sb = new StringBuilder(userIds);
			sb.deleteCharAt(userIds.length() - 1);
			String[] userIdArray = sb.toString().split(",");
			for (int i = 0; i < userIdArray.length; i++) {
				userIdList.add(userIdArray[i]);
			}
		}
		noticeService.saveUploadFiles(notice, files, filesFileName, userIdList, rootPath);
		return "addNotice_success";
	}
	
	/**
	 * �޸�ϵͳ��Ϣ����
	 */
	public String updateNoticeUI(){
		String whereStatement = "o.id=?1";
		List<Object> whereParam = new ArrayList<Object>();
		whereParam.add(notice.getId());
		//��ȡ�ϴ����ļ�
		List<UploadFiles> uploadFiles = noticeService.getUploadFile(notice.getId());
		ActionContext.getContext().put("updateOrNot", true);
		ActionContext.getContext().put("uploadFilesList", uploadFiles);
		//��ȡ������
		List<User> noticeUsers = noticeService.getNoticeUsers(notice.getId());
		ActionContext.getContext().put("noticeUsers", noticeUsers);
		//��ȡ������
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("userId", "asc");
		QueryResult<User> users = userService.getScrollData(orderBy);
		List<User> usersList = users.getResultList();
		usersList.removeAll(noticeUsers);
		ActionContext.getContext().put("usersList", usersList);
		
		ActionContext.getContext().put("noticeEntity", noticeService.getScrollData(whereStatement, whereParam, null).getResultList().get(0));
		return "updateNoticeUI_success";
	}
	
	/**
	 * ����ϵͳ��Ϣ����Ӧ���ϴ��ļ�
	 */
	public String downloadFile(){
		return "downloadFile_success";
	}
	/**
	 * ��ȡ�����ļ���������
	 * @throws Exception 
	 */
	public InputStream getDownloadFile(){
		String uploadFileId = uploadFiles.getId();
		String uploadFileName = uploadFiles.getRealFileName();
		String path = uploadFileId.replace("-", "/");
		try {
			uploadFileName = new String(uploadFileName.getBytes("ISO8859-1"), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		String realPath = "/upload/" + path + "/" + uploadFileName;
		return ServletActionContext.getServletContext().getResourceAsStream(realPath);
	}
	
	/**
	 * ��ȡ�����ļ�������
	 * @throws Exception 
	 */
	public String getDownFileName(){
		String downFileName = uploadFiles.getRealFileName();
		try {
			downFileName = new String(downFileName.getBytes("ISO8859-1"), "UTF-8");
			downFileName = new String(downFileName.getBytes(), "ISO8859-1");
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		return downFileName;
	}
	
	/**
	 * �����ϴ��ļ�idɾ����Ӧ���ϴ��ļ�
	 */
	public String delUploadFile(){
		noticeService.delUploadFile(uploadFiles.getId(), notice.getId());
		return "delUploadFile_success";
	}
	
	/**
	 * �޸�ϵͳ��Ϣ,�ɹ�����ת����ʾ����ϵͳ��Ϣ�б�����
	 */
	public String updateNotice(){
		String rootPath = ServletActionContext.getServletContext().getRealPath("/upload");
		List<String> userIdList = new ArrayList<String>();
		if(userIds != null && !"".equals(userIds)){
			StringBuilder sb = new StringBuilder(userIds);
			sb.deleteCharAt(userIds.length() - 1);
			String [] userIdArray = sb.toString().split(",");
			for (int i = 0; i < userIdArray.length; i++) {
				userIdList.add(userIdArray[i]);
			}
		}
		noticeService.updateNotice(notice, files, filesFileName, userIdList, rootPath);
		return "updateNotice_success";
	}
	
	/**
	 * ɾ��ϵͳ��Ϣ,�ɹ�����ת����ʾ����ϵͳ��Ϣ�б�����
	 */
	public String deleteNotice(){
		noticeService.deleteNotice(notice.getId());
		return "deleteNotice_success";
	}
	
	/**
	 * ����������ѯϵͳ��Ϣ
	 * �ɹ��󷵻ص���ʾ������Ϣ�б�����
	 */
	public String query(){
		LinkedHashMap<String, String> orderBy = new LinkedHashMap<String, String>();
		orderBy.put("id", "asc");
		List<Object> whereParam = new ArrayList<Object>();
		StringBuilder sb = new StringBuilder(200);
		sb.append(" 1=1 ");
		if(notice.getId() != null && !"".equals(notice.getId().toString().trim())){
			whereParam.add(notice.getId());
			sb.append(" and o.id = ?").append(whereParam.size()).append(" ");
		}
		if(notice.getTitle() != null && !"".equals(notice.getTitle().trim())){
			whereParam.add(notice.getTitle());
			sb.append(" and o.title = ?").append(whereParam.size()).append(" ");
		}
		if(notice.getIsImportent() != null && !"".equals(notice.getIsImportent())){
			whereParam.add(notice.getIsImportent());
			sb.append(" and o.isImportent = ?").append(whereParam.size()).append(" ");
		}
		if(notice.getIsNew() != null && !"".equals(notice.getIsNew())){
			whereParam.add(notice.getIsNew());
			sb.append(" and o.isNew = ?").append(whereParam.size()).append(" ");
		}
		if(notice.getMsgMan() != null && !"".equals(notice.getMsgMan())){
			whereParam.add(notice.getMsgMan());
			sb.append(" and o.msgMan= ?").append(whereParam.size()).append(" ");
		}
		if(notice.getMsgDate() != null && !"".equals(notice.getMsgDate())){
			whereParam.add(notice.getMsgDate());
			sb.append(" and o.msgDate= ?").append(whereParam.size()).append(" ");
		}
		QueryResult<Notice>	qr = noticeService.getScrollData(sb.toString(), whereParam, orderBy);
		ActionContext.getContext().put("noticesList", qr.getResultList());
		return "noticeList_success";
	}

	public NoticeService getNoticeService() {
		return noticeService;
	}

	public void setNoticeService(NoticeService noticeService) {
		this.noticeService = noticeService;
	}

	public Notice getNotice() {
		return notice;
	}

	public void setNotice(Notice notice) {
		this.notice = notice;
	}

	public UploadFiles getUploadFiles() {
		return uploadFiles;
	}

	public void setUploadFiles(UploadFiles uploadFiles) {
		this.uploadFiles = uploadFiles;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public List<File> getFiles() {
		return files;
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}

	public List<String> getFilesFileName() {
		return filesFileName;
	}

	public void setFilesFileName(List<String> filesFileName) {
		this.filesFileName = filesFileName;
	}

	public String getUserIds() {
		return userIds;
	}

	public void setUserIds(String userIds) {
		this.userIds = userIds;
	}

}
