/**
		* �ļ�����NoticesUsers.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-4-27
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.task;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.decg.base.common.Choose;
import com.decg.user.User;

/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�NoticesUsers
 * ��������֪ͨ������ʵ����
 * �����ˣ�������
 * ����ʱ�䣺2011-4-27 ����03:48:10
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-4-27 ����03:48:10
 * �޸ı�ע��
 * @version
 *
 */

@Entity
@Table(name = "NoticesUsers")
public class NoticesUsers implements Serializable {
	private static final long serialVersionUID = -7019071423770187909L;

	/** id **/
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id = null;
	
	/** ϵͳ֪ͨid **/
	@Column(length = 11)
	private Integer noticeId = null;
	/** ϵͳ֪ͨ��� **/
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
	@JoinColumn(name = "noticeId", insertable = false, updatable = false)
	private Notice notice = null;
	
	/** ����֪ͨ���˵�id **/
	@Column(length = 5)
	private String userId = null;
	/** ����֪ͨ������� **/
	@ManyToOne(cascade = CascadeType.REFRESH, fetch = FetchType.LAZY)
	@JoinColumn(name = "userId", insertable = false, updatable = false)
	private User user = null;
	
	/** �Ƿ��Ѷ� **/
	@Enumerated(EnumType.STRING)
	@Column(length = 3)
	private Choose isRead = null;

	/** id **/
	public Integer getId() {
		return id;
	}

	/** id **/
	public void setId(Integer id) {
		this.id = id;
	}

	/** ϵͳ֪ͨid **/
	public Integer getNoticeId() {
		return noticeId;
	}

	/** ϵͳ֪ͨid **/
	public void setNoticeId(Integer noticeId) {
		this.noticeId = noticeId;
	}

	/** ϵͳ֪ͨ��� **/
	public Notice getNotice() {
		return notice;
	}

	/** ϵͳ֪ͨ��� **/
	public void setNotice(Notice notice) {
		this.notice = notice;
	}

	/** ����֪ͨ���˵�id **/
	public String getUserId() {
		return userId;
	}

	/** ����֪ͨ���˵�id **/
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/** ����֪ͨ������� **/
	public User getUser() {
		return user;
	}

	/** ����֪ͨ������� **/
	public void setUser(User user) {
		this.user = user;
	}

	/** �Ƿ��Ѷ� **/
	public Choose getIsRead() {
		return isRead;
	}

	/** �Ƿ��Ѷ� **/
	public void setIsRead(Choose isRead) {
		this.isRead = isRead;
	}

	/*
			(non-Javadoc)
			* @see java.lang.Object#hashCode()
			*/
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/*
			(non-Javadoc)
			* @see java.lang.Object#equals(java.lang.Object)
			*/
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NoticesUsers other = (NoticesUsers) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	
	
}
