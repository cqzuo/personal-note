/**
		* �ļ�����NoticeServiceBean.java
		*
		* �汾��Ϣ��
		* ���ڣ�2011-4-27
		* Copyright HengTong Corporation 2011
		* ��Ȩ����
		*
		*/
package com.decg.task.service.bean;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.persistence.Query;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.decg.base.DaoSupport;
import com.decg.base.common.Choose;
import com.decg.task.Notice;
import com.decg.task.NoticesUsers;
import com.decg.task.UploadFiles;
import com.decg.task.service.NoticeService;
import com.decg.user.User;
/**
 *
 * ��Ŀ���ƣ�decgNew
 * �����ƣ�NoticeServiceBean
 * ��������
 * �����ˣ�������
 * ����ʱ�䣺2011-4-27 ����04:20:08
 * �޸��ˣ�������
 * �޸�ʱ�䣺2011-4-27 ����04:20:08
 * �޸ı�ע��
 * @version
 *
 */

@Service
public class NoticeServiceBean extends DaoSupport<Notice> implements NoticeService {

	@SuppressWarnings("unchecked")
	public List<Object> getNoticeView(String userId) {
		StringBuilder sb = new StringBuilder(200);
		sb.append(" select notice, noticesUsers");
		sb.append(" from Notice notice, NoticesUsers noticesUsers ");
		sb.append(" where notice.id = noticesUsers.noticeId and noticesUsers.userId = ?1 ");
		sb.append(" order by notice.msgDate desc ");
		String jpql = sb.toString();
		Query query = em.createQuery(jpql);
		query.setParameter(1, userId);
		List<Object> objs = query.getResultList();
		objs.add(jpql);
		return objs;
	}

	@Transactional
	public void saveUploadFiles(Notice notice, List<File> files, List<String> filesFileName, List<String> userIds, String rootPath) {
		//����ϵͳ֪ͨ
		if(files != null && files.size() > 0) {
			notice.setCountFiles(files.size());
		} else {
			notice.setCountFiles(0);
		}
		em.persist(notice);
		//�ϴ������渽��
		if(files != null && files.size() > 0) {
			for (int i = 0; i < files.size(); i++) {
				//��ȡÿ���������ļ���
				String fileName = filesFileName.get(i);
				UploadFiles uf = new UploadFiles();
				uf.setId(UUID.randomUUID().toString());
				uf.setNoticeId(notice.getId());
				uf.setRealFileName(fileName);
				//���渽��
				em.persist(uf);
				//�ϴ�����
				File file = files.get(i);
				String uuid = uf.getId();
				String[] uuids = uuid.split("-");
				String uploadPath = "";
				for (int j = 0; j < uuids.length; j++) {
					uploadPath = uploadPath + File.separator + uuids[j];
				}
				File savedFile = new File(new File(rootPath + uploadPath) , fileName);
				if(!savedFile.getParentFile().exists()) {
					savedFile.getParentFile().mkdirs();
					try {
						FileUtils.copyFile(file, savedFile);
					} catch (IOException e) {
						throw new RuntimeException(e.getMessage(), e);
					}
				}
			}
		}
		//����֪ͨ�ķ�����
		if(userIds != null && userIds.size() > 0) {
			for (int i = 0; i < userIds.size(); i++) {
				NoticesUsers nu = new NoticesUsers();
				nu.setNoticeId(notice.getId());
				nu.setUserId(userIds.get(i));
				nu.setIsRead(Choose.NO);
				em.persist(nu);
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<UploadFiles> getUploadFile(int noticeId) {
		StringBuilder sb = new StringBuilder(100);
		sb.append(" select u ");
		sb.append(" from UploadFiles u, Notice n ");
		sb.append(" where n.id = u.noticeId and n.id = ?1 order by u.id asc");
		Query query = em.createQuery(sb.toString());
		query.setParameter(1, noticeId);
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<User> getNoticeUsers(int noticeId) {
		StringBuilder sb = new StringBuilder(100);
		sb.append(" select u ");
		sb.append(" from NoticesUsers nu, Notice n, User u ");
		sb.append(" where n.id = nu.noticeId and u.id = nu.userId and n.id = ?1 ");
		Query query = em.createQuery(sb.toString());
		query.setParameter(1, noticeId);
		return query.getResultList();
	}
	
	@Transactional
	public void delUploadFile(String uploadFlieId, int noticeId) {
		UploadFiles uf = new UploadFiles();
		uf.setId(uploadFlieId);
		em.remove(em.merge(uf));
		StringBuilder sb = new StringBuilder(100);
		sb.append(" update Notice n set n.countFiles=n.countFiles-1 ");
		sb.append(" where n.id = ?1 ");
		Query query = em.createQuery(sb.toString());
		query.setParameter(1, noticeId);
		query.executeUpdate();
	}
	
	@Transactional
	public void deleteNotice(int noticeId) {
		StringBuilder uploadFile = new StringBuilder(100);
		uploadFile.append(" delete from UploadFiles nf where nf.noticeId=?1 ");
		Query queryUF = em.createQuery(uploadFile.toString());
		queryUF.setParameter(1, noticeId);
		queryUF.executeUpdate();
		
		StringBuilder noticesUser = new StringBuilder(100);
		noticesUser.append(" delete from NoticesUsers nu where nu.noticeId=?1 ");
		Query queryNU = em.createQuery(noticesUser.toString());
		queryNU.setParameter(1, noticeId);
		queryNU.executeUpdate();
		
		StringBuilder notice = new StringBuilder(100);
		notice.append(" delete from Notice n where n.id=?1 ");
		Query queryN = em.createQuery(notice.toString());
		queryN.setParameter(1, noticeId);
		queryN.executeUpdate();
	}
	
	@Transactional
	public void updateNotice(Notice notice, List<File> files, List<String> filesFileName, List<String> userIdList, String rootPath) {
		//����ϵͳ֪ͨ
		if(files != null && files.size() > 0) {
			notice.setCountFiles(notice.getCountFiles() + files.size());
		}
		em.merge(notice);
		//����֪ͨ������
		StringBuilder noticesUser = new StringBuilder(200);
		noticesUser.append(" delete from NoticesUsers nu where nu.noticeId=?1 ");
		Query queryNU = em.createQuery(noticesUser.toString());
		queryNU.setParameter(1, notice.getId());
		queryNU.executeUpdate();
		if(userIdList != null && userIdList.size() > 0) {
			for (int i = 0; i < userIdList.size(); i++) {
				NoticesUsers nu = new NoticesUsers();
				nu.setNoticeId(notice.getId());
				nu.setUserId(userIdList.get(i));
				nu.setIsRead(Choose.NO);
				em.persist(nu);
			}
		}
		//�������ӵĸ���
		if(files != null && files.size() > 0) {
			for (int i = 0; i < files.size(); i++) {
				//��ȡÿ���������ļ���
				String fileName = filesFileName.get(i);
				UploadFiles uf = new UploadFiles();
				uf.setId(UUID.randomUUID().toString());
				uf.setNoticeId(notice.getId());
				uf.setRealFileName(fileName);
				//���渽��
				em.persist(uf);
				//�ϴ�����
				File file = files.get(i);
				String uuid = uf.getId();
				String[] uuids = uuid.split("-");
				String uploadPath = "";
				for (int j = 0; j < uuids.length; j++) {
					uploadPath = uploadPath + File.separator + uuids[j];
				}
				File savedFile = new File(new File(rootPath + uploadPath) , fileName);
				if(!savedFile.getParentFile().exists()) {
					savedFile.getParentFile().mkdirs();
					try {
						FileUtils.copyFile(file, savedFile);
					} catch (IOException e) {
						throw new RuntimeException(e.getMessage(), e);
					}
				}
			}
		}
	}

	public void updateNoticeRead(int noticeId, String userId) {
		StringBuilder sb = new StringBuilder(100);
		sb.append(" update NoticesUsers nu set nu.isRead='YES' ");
		sb.append(" where nu.noticeId = ?1 and nu.userId = ?2 ");
		Query query = em.createQuery(sb.toString());
		query.setParameter(1, noticeId);
		query.setParameter(2, userId);
		query.executeUpdate();
	}

	@SuppressWarnings("unchecked")
	public void deletePastNotices() {
		StringBuilder sb = new StringBuilder(100);
		sb.append(" select n.id from Notice n where n.msgInDate<datediff(CURRENT_TIMESTAMP(), n.msgDate) ");
		Query query = em.createQuery(sb.toString());
		List<Integer> noticeIdList = query.getResultList();
		if(noticeIdList != null && noticeIdList.size()>0){
			for (int i = 0; i < noticeIdList.size(); i++) {
				StringBuilder uploadFile = new StringBuilder(100);
				uploadFile.append(" delete from UploadFiles nf where nf.noticeId=?1 ");
				Query queryUF = em.createQuery(uploadFile.toString());
				queryUF.setParameter(1, noticeIdList.get(i));
				queryUF.executeUpdate();
				
				StringBuilder noticesUser = new StringBuilder(100);
				noticesUser.append(" delete from NoticesUsers nu where nu.noticeId=?1 ");
				Query queryNU = em.createQuery(noticesUser.toString());
				queryNU.setParameter(1, noticeIdList.get(i));
				queryNU.executeUpdate();
			}
			StringBuilder notice = new StringBuilder(100);
			notice.append(" delete from Notice n where n.msgInDate<datediff(CURRENT_TIMESTAMP(), n.msgDate) ");
			Query queryN = em.createQuery(notice.toString());
			queryN.executeUpdate();
		}
	}
	
	public int getSurplusDay(int noticeId) {
		StringBuilder sb = new StringBuilder(100);
		sb.append(" select (n.msgInDate - datediff(CURRENT_TIMESTAMP(), n.msgDate)) from Notice n where n.id = ?1 ");
		Query query = em.createQuery(sb.toString());
		query.setParameter(1, noticeId);
		return (Integer)query.getSingleResult();
	}
	
}
