package com.decg.task.service.bean;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.decg.base.DaoSupport;
import com.decg.task.Task;
import com.decg.task.service.TaskService;

@Service
public class TaskServiceBean extends DaoSupport<Task> implements TaskService {

	@SuppressWarnings("unchecked")
	public List<Object> getTaskViews(String userId) {
		StringBuilder sb = new StringBuilder(300);
		sb.append(" select task, project, enterprise, stage, step, user ");
		sb.append(" from Task task, Project project, Enterprise enterprise, Stage stage, Step step, User user, StepsProcessers s ");
		sb.append(" where project.relation_id = s.relationId and project.accepter_id = user.userId ");
		sb.append(" and task.project_id = project.id and task.step_id = s.stepId and task.step_id = step.stepId and project.enterprise_id = enterprise.id ");
		sb.append(" and step.stageId = stage.stageId ");
		sb.append(" and s.userId =?1 and (s.taskId is null or s.taskId = task.id) ");
		String jpql = sb.toString();
		Query query = em.createQuery(jpql);
		query.setParameter(1, userId);
		List<Object> objs = query.getResultList();
		objs.add(jpql);
		return objs;
	}
	
	@SuppressWarnings("unchecked")
	public List<Object> getUnderstands(String userId) {
		StringBuilder sb = new StringBuilder(300);
		sb.append(" select task, project, enterprise, stage, step, user ");
		sb.append(" from Task task, Project project, Enterprise enterprise, Stage stage, Step step, User user, StepsProcessers s ");
		sb.append(" where project.relation_id = s.relationId and project.accepter_id = user.userId ");
		sb.append(" and task.project_id = project.id and task.step_id = s.stepId and task.step_id = step.stepId and project.enterprise_id = enterprise.id ");
		sb.append(" and step.stageId = stage.stageId ");
		sb.append(" and s.userId =?1 and (s.taskId is null or s.taskId = task.id) ");
		String jpql = sb.toString();
		Query query = em.createQuery(jpql);
		query.setParameter(1, userId);
		List<Object> objs = query.getResultList();
		objs.add(jpql);
		return objs;
	}
	
}
