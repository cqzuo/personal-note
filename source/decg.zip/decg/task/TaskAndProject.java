package com.decg.task;

import com.decg.consulation.Enterprise;
import com.decg.consulation.Project;
import com.decg.user.User;

public class TaskAndProject {
	private Task task;
	private Project project;
	private Enterprise enterprise;
	private User user;

	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Enterprise getEnterprise() {
		return enterprise;
	}

	public void setEnterprise(Enterprise enterprise) {
		this.enterprise = enterprise;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
