#ifndef MY_SYSTEM_H
#define MY_SYSTEM_H
unsigned int my_system(const char *cmd,char *result,int maxLen);
#endif
